<?php
session_start();
require_once "db.php";
require_once 'business_helpers.php';
require_once "simulation_helpers.php";

requireLogin();
// Membership/role is resolved below using the existing business_helpers.php functions.
verifyAppCsrfPost();
if (!columnExists('employees', 'worker_id')) $conn->query("ALTER TABLE employees ADD COLUMN worker_id VARCHAR(24) NULL");
// Each employee receives a stable, unique Employee ID. Keep the existing Worker ID
// for compatibility with project assignments and other features.
if (!columnExists('employees', 'employee_id')) $conn->query("ALTER TABLE employees ADD COLUMN employee_id VARCHAR(24) NULL");
$existingWorkerRows = $conn->query("SELECT id, worker_id, employee_id FROM employees WHERE worker_id IS NULL OR worker_id='' OR employee_id IS NULL OR employee_id=''");
if ($existingWorkerRows) while ($workerRow = $existingWorkerRows->fetch_assoc()) {
    $workerPk = (int)$workerRow['id'];
    $workerCode = 'WRK-' . str_pad((string)$workerPk, 5, '0', STR_PAD_LEFT);
    $employeeCode = 'EMP-' . str_pad((string)$workerPk, 5, '0', STR_PAD_LEFT);
    $workerUpdate = $conn->prepare("UPDATE employees SET worker_id=IF(worker_id IS NULL OR worker_id='', ?, worker_id), employee_id=IF(employee_id IS NULL OR employee_id='', ?, employee_id) WHERE id=?");
    if ($workerUpdate) { $workerUpdate->bind_param('ssi', $workerCode, $employeeCode, $workerPk); $workerUpdate->execute(); $workerUpdate->close(); }
}

$__me = currentUser();
$__roleCheck = $__me;
$__businessRole = businessRoleForUser($conn, $__roleCheck);
$__isManager = in_array($__businessRole, ['owner', 'manager'], true);
// Resolve the active business owner before handling POST actions. Candidate approval
// needs this ID to validate the application and write the employee to the correct roster.
$__ownerId = (int)(function_exists('currentBusinessOwnerId') ? (currentBusinessOwnerId() ?? 0) : 0);

/* ============================
   TEAM MANAGEMENT
============================ */

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $__isManager) {

    if (isset($_POST['hire'])) {

        $hireName = trim($_POST['name']);
        $hireRole = trim($_POST['role']);
        $hireSalary = intval($_POST['salary']);
        $result = hireEmployee($hireName, $hireRole, $hireSalary);
        $_SESSION['flash'] = $result;

        header("Location: team.php");
        exit;
    }

    if (isset($_POST['approve_candidate'])) {
        $applicationId = (int)($_POST['application_id'] ?? 0);
        $candidateRole = trim((string)($_POST['candidate_role'] ?? 'worker'));
        $candidateSalary = (int)($_POST['candidate_salary'] ?? 0);
        if (!in_array($candidateRole, ['worker', 'manager'], true)) $candidateRole = 'worker';
        if ($applicationId < 1 || $candidateSalary < 1) {
            $_SESSION['flash'] = ['error' => 'Choose a valid role and enter a monthly salary greater than zero.'];
        } else {
            $applicationStmt = $conn->prepare("SELECT be.id, be.worker_id, u.username FROM business_employment be JOIN users u ON u.id=be.worker_id WHERE be.id=? AND be.owner_id=? AND be.status='pending' LIMIT 1");
            if ($applicationStmt) {
                $applicationStmt->bind_param('ii', $applicationId, $__ownerId);
                $applicationStmt->execute();
                $applicant = $applicationStmt->get_result()->fetch_assoc();
                $applicationStmt->close();
            } else $applicant = null;

            if (!$applicant) {
                $_SESSION['flash'] = ['error' => 'This application is no longer pending. Refresh the page and try again.'];
            } else {
                $conn->begin_transaction();
                try {
                    $approveStmt = $conn->prepare("UPDATE business_employment SET status='hired', employment_role=?, updated_at=CURRENT_TIMESTAMP WHERE id=? AND owner_id=? AND status='pending'");
                    if (!$approveStmt) throw new RuntimeException('Could not prepare the application approval.');
                    $approveStmt->bind_param('sii', $candidateRole, $applicationId, $__ownerId);
                    if (!$approveStmt->execute() || $approveStmt->affected_rows !== 1) throw new RuntimeException('This application has already been processed.');
                    $approveStmt->close();

                    // Keep the simulation's employee roster in sync when its legacy table is available.
                    if (tableExists('employees') && columnExists('employees', 'business_owner_id') && columnExists('employees', 'name') && columnExists('employees', 'role') && columnExists('employees', 'salary')) {
                        $employeeName = (string)$applicant['username'];
                        $employeeRoleLabel = $candidateRole === 'manager' ? 'Manager' : 'Worker';
                        $columns = ['business_owner_id','name','role','salary'];
                        $values = ['?','?','?','?'];
                        $types = 'issi';
                        $params = [$__ownerId, $employeeName, $employeeRoleLabel, $candidateSalary];
                        if (columnExists('employees', 'status')) { $columns[]='status'; $values[]="'active'"; }
                        $insertEmployee = $conn->prepare('INSERT INTO employees (`'.implode('`,`',$columns).'`) VALUES ('.implode(',',$values).')');
                        if ($insertEmployee) {
                            $bindArgs = [$types]; foreach ($params as $k => &$value) $bindArgs[] = &$value;
                            call_user_func_array([$insertEmployee, 'bind_param'], $bindArgs);
                            if (!$insertEmployee->execute()) throw new RuntimeException('The worker was approved, but their employee profile could not be created.');
                            $newEmployeeId = (int)$conn->insert_id;
                            $insertEmployee->close();
                            if ($newEmployeeId > 0) {
                                $workerCode = 'WRK-' . str_pad((string)$newEmployeeId, 5, '0', STR_PAD_LEFT);
                                $employeeCode = 'EMP-' . str_pad((string)$newEmployeeId, 5, '0', STR_PAD_LEFT);
                                $idStmt = $conn->prepare("UPDATE employees SET worker_id=IF(worker_id IS NULL OR worker_id='', ?, worker_id), employee_id=IF(employee_id IS NULL OR employee_id='', ?, employee_id) WHERE id=?");
                                if ($idStmt) { $idStmt->bind_param('ssi', $workerCode, $employeeCode, $newEmployeeId); $idStmt->execute(); $idStmt->close(); }
                            }
                        }
                    }
                    $conn->commit();
                    businessNotify($conn, (int)$applicant['worker_id'], 'Workplace request approved', 'Your request to join this business was approved. You can now access workplace features.', 'demo.php');
                    businessLog($conn, (int)$__ownerId, (int)$__me['id'], 'Approved workplace request', $employeeName ?? (string)$applicant['username'].' was hired.');
                    $_SESSION['flash'] = ['error' => 'Worker hired successfully. Their workplace access is now enabled.'];
                } catch (Throwable $e) {
                    $conn->rollback();
                    error_log('Candidate approval failed: '.$e->getMessage());
                    $_SESSION['flash'] = ['error' => 'Could not complete the hire. Please check the database schema and try again.'];
                }
            }
        }
        header('Location: team.php');
        exit;
    }

    // Fire a real worker account from this business. The employment row is the
    // authoritative membership record; the legacy simulation roster is synced too.
    if (isset($_POST['fire_worker'])) {
        $employmentId = (int)($_POST['employment_id'] ?? 0);
        $target = null;
        if ($employmentId > 0 && $__ownerId > 0 && tableExists('business_employment')) {
            $targetStmt = $conn->prepare("SELECT be.id, be.worker_id, u.username FROM business_employment be JOIN users u ON u.id=be.worker_id WHERE be.id=? AND be.owner_id=? AND be.status='hired' AND be.employment_role='worker' LIMIT 1");
            if ($targetStmt) {
                $targetStmt->bind_param('ii', $employmentId, $__ownerId);
                $targetStmt->execute();
                $target = $targetStmt->get_result()->fetch_assoc();
                $targetStmt->close();
            }
        }
        if (!$target) {
            $_SESSION['flash'] = ['error' => 'That worker is no longer hired by this business, or cannot be fired from this profile.'];
        } else {
            $conn->begin_transaction();
            try {
                $fireStmt = $conn->prepare("UPDATE business_employment SET status='fired', updated_at=CURRENT_TIMESTAMP WHERE id=? AND owner_id=? AND status='hired' AND employment_role='worker'");
                if (!$fireStmt) throw new RuntimeException('Could not prepare the termination action.');
                $fireStmt->bind_param('ii', $employmentId, $__ownerId);
                if (!$fireStmt->execute() || $fireStmt->affected_rows !== 1) throw new RuntimeException('The worker is no longer actively hired.');
                $fireStmt->close();

                // Remove the fired worker from every project assignment in this business.
                // Keep completion/score history intact; only active assignment links are removed.
                if (tableExists('project_worker_assignments') && tableExists('projects') && columnExists('projects','business_owner_id')) {
                    $unassignStmt = $conn->prepare("DELETE pwa FROM project_worker_assignments pwa JOIN projects p ON p.id=pwa.project_id WHERE pwa.worker_id=? AND p.business_owner_id=?");
                    if (!$unassignStmt) throw new RuntimeException('Could not prepare project unassignment.');
                    $unassignStmt->bind_param('ii', $target['worker_id'], $__ownerId);
                    if (!$unassignStmt->execute()) throw new RuntimeException('Could not remove the worker from assigned projects.');
                    $unassignStmt->close();
                }

                // Also remove legacy simulated-employee assignments for this business.
                if (tableExists('employees') && columnExists('employees','business_owner_id') && columnExists('employees','name') && columnExists('employees','status')) {
                    if (tableExists('project_team') && columnExists('project_team','employee_id')) {
                        $legacyUnassignStmt = $conn->prepare("DELETE pt FROM project_team pt JOIN employees e ON e.id=pt.employee_id WHERE e.business_owner_id=? AND LOWER(TRIM(e.name))=LOWER(TRIM(?))");
                        if (!$legacyUnassignStmt) throw new RuntimeException('Could not prepare legacy project unassignment.');
                        $legacyUnassignStmt->bind_param('is', $__ownerId, $target['username']);
                        if (!$legacyUnassignStmt->execute()) throw new RuntimeException('Could not remove legacy project assignments.');
                        $legacyUnassignStmt->close();
                    }
                    $syncStmt = $conn->prepare("UPDATE employees SET status='fired' WHERE business_owner_id=? AND LOWER(TRIM(name))=LOWER(TRIM(?)) AND LOWER(COALESCE(status,'active')) IN ('active','hired','working')");
                    if ($syncStmt) { $syncStmt->bind_param('is', $__ownerId, $target['username']); if (!$syncStmt->execute()) throw new RuntimeException('Could not update the employee roster.'); $syncStmt->close(); }
                }
                $conn->commit();
                businessNotify($conn, (int)$target['worker_id'], 'Employment ended', 'Your employment with this business has ended. Business workspace access has been removed.', 'find_business.php');
                businessLog($conn, $__ownerId, (int)($__me['id'] ?? 0), 'Fired worker', (string)$target['username'].' was removed from the business.');
                $_SESSION['flash'] = ['error' => htmlspecialchars((string)$target['username'], ENT_QUOTES, 'UTF-8').' was fired and removed from the business.'];
            } catch (Throwable $e) {
                $conn->rollback();
                error_log('Worker termination failed: '.$e->getMessage());
                $_SESSION['flash'] = ['error' => 'Could not fire this worker. Please refresh and try again.'];
            }
        }
        header('Location: team.php');
        exit;
    }

    if (isset($_POST['fire'])) {

        fireEmployee((int)$_POST['employee']);

        header("Location: team.php");
        exit;
    }

    if (isset($_POST['promote'])) {

        promoteEmployee((int)$_POST['employee']);

        header("Location: team.php");
        exit;
    }

}

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$game = getGameState();
// Cash and simulation indicators are tied to this studio, not the shared legacy game_state row.
$__simState = $__ownerId > 0 ? simState($__ownerId) : null;
$companyCash = $__isManager ? simCash((int)$__ownerId) : 0;

$employees = getEmployees();

$stats = teamStatistics();

// Optional Team Overview metrics: only query tables/columns that actually exist.
$teamOverview = ['active_workers' => null, 'projects_assigned' => null, 'tasks_pending' => null, 'needs_attention' => 0];
if (tableExists('employees') && columnExists('employees', 'status')) {
    $activeSql = "SELECT COUNT(*) AS n FROM employees";
    if (columnExists('employees', 'business_owner_id')) $activeSql .= " WHERE business_owner_id=".(int)$__ownerId." AND LOWER(COALESCE(status,'')) IN ('active','hired','working')";
    else $activeSql .= " WHERE LOWER(COALESCE(status,'')) IN ('active','hired','working')";
    $activeRes = $conn->query($activeSql); if ($activeRes) $teamOverview['active_workers'] = (int)($activeRes->fetch_assoc()['n'] ?? 0);
}
// These metrics remain unavailable rather than showing misleading numbers when a compatible table is absent.
foreach ([['projects','projects_assigned',['status','project_status']],['tasks','tasks_pending',['status','task_status']]] as $metricDef) {
    [$tableName,$metricName,$statusCols] = $metricDef;
    if (tableExists($tableName)) {
        $statusCol = null; foreach ($statusCols as $candidateCol) if (columnExists($tableName,$candidateCol)) { $statusCol=$candidateCol; break; }
        $ownerCol = columnExists($tableName,'owner_id') ? 'owner_id' : (columnExists($tableName,'business_owner_id') ? 'business_owner_id' : null);
        if ($ownerCol) {
            $where = $ownerCol.'='.(int)$__ownerId;
            if ($statusCol && $metricName==='projects_assigned') $where .= " AND LOWER(COALESCE(`$statusCol`,'')) IN ('assigned','in progress','in_progress','active','pending')";
            if ($statusCol && $metricName==='tasks_pending') $where .= " AND LOWER(COALESCE(`$statusCol`,'')) NOT IN ('completed','done','approved')";
            $countRes=$conn->query("SELECT COUNT(*) AS n FROM `$tableName` WHERE $where"); if ($countRes) $teamOverview[$metricName]=(int)($countRes->fetch_assoc()['n'] ?? 0);
        }
    }
}
// Training metrics are intentionally excluded from Team Management.



// Needs Attention includes only unfinished projects/tasks marked critical or due in 1–2 days.
// Prefer explicit deadline dates; otherwise derive a project due date from created_at + deadline.
$attentionCount = 0;
if (tableExists('projects') && columnExists('projects','business_owner_id')) {
    $selectCols = ['id'];
    foreach (['title','name','status','priority','deadline_date','deadline_at','created_at','deadline'] as $col) if (columnExists('projects',$col)) $selectCols[] = $col;
    $projectRows = $conn->query("SELECT `".implode('`,`',$selectCols)."` FROM projects WHERE business_owner_id=".(int)$__ownerId);
    if ($projectRows) {
        $today = new DateTimeImmutable('today');
        while ($pr = $projectRows->fetch_assoc()) {
            $status = strtolower(trim((string)($pr['status'] ?? '')));
            if (in_array($status, ['completed','complete','done','approved','cancelled','canceled'], true)) continue;
            $priority = strtolower(trim((string)($pr['priority'] ?? '')));
            $critical = in_array($priority, ['critical','urgent','high - critical','high/critical'], true);
            $due = null;
            if (!empty($pr['deadline_date']) && $pr['deadline_date'] !== '0000-00-00') {
                try { $due = new DateTimeImmutable($pr['deadline_date']); } catch (Throwable $e) { $due = null; }
            } elseif (!empty($pr['created_at']) && isset($pr['deadline']) && is_numeric($pr['deadline'])) {
                try { $due = (new DateTimeImmutable($pr['created_at']))->modify('+'.max(0,(int)$pr['deadline']).' days'); } catch (Throwable $e) { $due = null; }
            }
            $daysLeft = $due ? (int)$today->diff($due)->format('%r%a') : null;
            if ($critical || ($daysLeft !== null && $daysLeft >= 1 && $daysLeft <= 2)) $attentionCount++;
        }
    }
}
// Include task records only when a compatible owner, status, priority, and deadline schema exists.
if (tableExists('tasks')) {
    $taskOwnerCol = columnExists('tasks','business_owner_id') ? 'business_owner_id' : (columnExists('tasks','owner_id') ? 'owner_id' : null);
    $taskStatusCol = columnExists('tasks','status') ? 'status' : (columnExists('tasks','task_status') ? 'task_status' : null);
    $taskPriorityCol = columnExists('tasks','priority') ? 'priority' : null;
    $taskDueCol = columnExists('tasks','deadline_date') ? 'deadline_date' : (columnExists('tasks','due_date') ? 'due_date' : (columnExists('tasks','deadline') ? 'deadline' : null));
    if ($taskOwnerCol && $taskStatusCol && ($taskPriorityCol || $taskDueCol)) {
        $taskCols = ['id',"`$taskStatusCol` AS task_status"];
        if ($taskPriorityCol) $taskCols[] = "`$taskPriorityCol` AS task_priority";
        if ($taskDueCol) $taskCols[] = "`$taskDueCol` AS task_due";
        if ($taskDueCol === 'deadline' && columnExists('tasks','created_at')) $taskCols[] = '`created_at` AS task_created';
        $taskRows = $conn->query("SELECT ".implode(',',$taskCols)." FROM tasks WHERE `$taskOwnerCol`=".(int)$__ownerId);
        if ($taskRows) {
            $today = new DateTimeImmutable('today');
            while ($task = $taskRows->fetch_assoc()) {
                if (in_array(strtolower(trim((string)$task['task_status'])), ['completed','complete','done','approved','cancelled','canceled'], true)) continue;
                $critical = in_array(strtolower(trim((string)($task['task_priority'] ?? ''))), ['critical','urgent','high - critical','high/critical'], true);
                $due = null;
                if (!empty($task['task_due']) && $task['task_due'] !== '0000-00-00' && $taskDueCol !== 'deadline') { try { $due = new DateTimeImmutable($task['task_due']); } catch (Throwable $e) { $due = null; } }
                elseif ($taskDueCol === 'deadline' && isset($task['task_due'],$task['task_created']) && is_numeric($task['task_due'])) { try { $due = (new DateTimeImmutable($task['task_created']))->modify('+'.max(0,(int)$task['task_due']).' days'); } catch (Throwable $e) { $due = null; } }
                $daysLeft = $due ? (int)$today->diff($due)->format('%r%a') : null;
                if ($critical || ($daysLeft !== null && $daysLeft >= 1 && $daysLeft <= 2)) $attentionCount++;
            }
        }
    }
}
$teamOverview['needs_attention'] = $attentionCount;



$events = [];
$achievements = [];
if ($__ownerId > 0) {
    $eventStmt = $conn->prepare("SELECT title, details AS description, CASE WHEN event_type='achievement' THEN 'success' WHEN event_type='expense' THEN 'warning' ELSE 'info' END AS tone, created_at FROM simulation_business_events WHERE owner_id=? ORDER BY id DESC LIMIT 8");
    $eventStmt->bind_param('i', $__ownerId);
    $eventStmt->execute();
    $events = $eventStmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $eventStmt->close();
    $achievementStmt = $conn->prepare("SELECT title, unlocked_at, description FROM simulation_business_achievements WHERE owner_id=? ORDER BY unlocked_at DESC");
    $achievementStmt->bind_param('i', $__ownerId);
    $achievementStmt->execute();
    $achievements = $achievementStmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $achievementStmt->close();
}

$candidates = candidatePool($__ownerId);

// Map real hired worker accounts to their roster profiles for the owner/manager view.
$__workerEmploymentByUsername = [];
if ($__isManager && $__ownerId > 0 && tableExists('business_employment')) {
    $workerMapStmt = $conn->prepare("SELECT be.id AS employment_id, be.worker_id, LOWER(TRIM(u.username)) AS username_key FROM business_employment be JOIN users u ON u.id=be.worker_id WHERE be.owner_id=? AND be.status='hired' AND be.employment_role='worker'");
    if ($workerMapStmt) {
        $workerMapStmt->bind_param('i', $__ownerId);
        $workerMapStmt->execute();
        foreach ($workerMapStmt->get_result()->fetch_all(MYSQLI_ASSOC) as $workerMapRow) $__workerEmploymentByUsername[(string)$workerMapRow['username_key']] = $workerMapRow;
        $workerMapStmt->close();
    }
}

if (!$__isManager) {
    // Worker-only Team Management view: team directory, assigned project tasks, and personal contribution.
    $workerTeam = [];
    if ($__ownerId > 0 && tableExists('employees') && columnExists('employees','business_owner_id')) {
        $teamSql = "SELECT id, name, role, worker_id, employee_id FROM employees WHERE business_owner_id=?";
        if (columnExists('employees','status')) $teamSql .= " AND LOWER(COALESCE(status,'active')) IN ('active','hired','working')";
        $teamSql .= " ORDER BY name ASC";
        $teamStmt = $conn->prepare($teamSql);
        if ($teamStmt) { $teamStmt->bind_param('i', $__ownerId); $teamStmt->execute(); $workerTeam = $teamStmt->get_result()->fetch_all(MYSQLI_ASSOC); $teamStmt->close(); }
    }

    // Resolve the logged-in worker's own employee record within this business.
    // Do not use the whole team roster as a task source: it is only for the directory.
    $myEmployeeId = 0;
    $myUsername = trim((string)($__me['username'] ?? ''));
    if ($myUsername !== '' && $__ownerId > 0 && tableExists('employees') && columnExists('employees','business_owner_id')) {
        $selfSql = "SELECT id FROM employees WHERE business_owner_id=? AND LOWER(TRIM(name))=LOWER(TRIM(?))";
        if (columnExists('employees','status')) $selfSql .= " AND LOWER(COALESCE(status,'active')) IN ('active','hired','working')";
        $selfSql .= " ORDER BY id ASC LIMIT 1";
        $selfStmt = $conn->prepare($selfSql);
        if ($selfStmt) { $selfStmt->bind_param('is', $__ownerId, $myUsername); $selfStmt->execute(); $selfRow = $selfStmt->get_result()->fetch_assoc(); $myEmployeeId = (int)($selfRow['id'] ?? 0); $selfStmt->close(); }
    }

    // Show projects assigned to the real logged-in worker account first. This is
    // the assignment system used by Project Management for hired worker accounts.
    $myTeamTasks = [];
    $seenTaskIds = [];
    $taskProjectTitleCol = (tableExists('projects') && columnExists('projects','title')) ? 'title' : ((tableExists('projects') && columnExists('projects','name')) ? 'name' : null);
    if ($taskProjectTitleCol && $__ownerId > 0 && (int)($__me['id'] ?? 0) > 0 && tableExists('project_worker_assignments') && tableExists('projects') && columnExists('projects','business_owner_id')) {
        $taskCols = ['p.id', 'p.`'.$taskProjectTitleCol.'` AS project_title'];
        if (columnExists('projects','status')) $taskCols[] = 'p.status AS project_status';
        if (columnExists('projects','priority')) $taskCols[] = 'p.priority AS project_priority';
        if (columnExists('projects','created_at')) $taskCols[] = 'p.created_at AS project_created';
        if (columnExists('projects','deadline_at')) $taskCols[] = 'p.deadline_at AS project_due';
        elseif (columnExists('projects','deadline_date')) $taskCols[] = 'p.deadline_date AS project_due';
        elseif (columnExists('projects','due_date')) $taskCols[] = 'p.due_date AS project_due';
        $taskSql = 'SELECT DISTINCT '.implode(', ', $taskCols).' FROM project_worker_assignments pwa JOIN projects p ON p.id=pwa.project_id WHERE pwa.worker_id=? AND p.business_owner_id=? ORDER BY '.(columnExists('projects','deadline_at') ? 'p.deadline_at IS NULL, p.deadline_at ASC' : (columnExists('projects','deadline_date') ? 'p.deadline_date IS NULL, p.deadline_date ASC' : 'p.id DESC'));
        $taskStmt = $conn->prepare($taskSql);
        if ($taskStmt) {
            $loggedWorkerId = (int)$__me['id'];
            $taskStmt->bind_param('ii', $loggedWorkerId, $__ownerId);
            $taskStmt->execute();
            foreach ($taskStmt->get_result()->fetch_all(MYSQLI_ASSOC) as $assignedTask) {
                $taskId = (int)($assignedTask['id'] ?? 0);
                if ($taskId > 0 && !isset($seenTaskIds[$taskId])) { $myTeamTasks[] = $assignedTask; $seenTaskIds[$taskId] = true; }
            }
            $taskStmt->close();
        }
    }

    // Also support older simulated employee assignments without duplicating projects.
    if ($myEmployeeId > 0 && tableExists('project_team') && tableExists('projects') && columnExists('projects','business_owner_id') && $taskProjectTitleCol) {
        $legacyCols = ['p.id', 'p.`'.$taskProjectTitleCol.'` AS project_title'];
        if (columnExists('projects','status')) $legacyCols[] = 'p.status AS project_status';
        if (columnExists('projects','priority')) $legacyCols[] = 'p.priority AS project_priority';
        if (columnExists('projects','created_at')) $legacyCols[] = 'p.created_at AS project_created';
        if (columnExists('projects','deadline_at')) $legacyCols[] = 'p.deadline_at AS project_due';
        elseif (columnExists('projects','deadline_date')) $legacyCols[] = 'p.deadline_date AS project_due';
        elseif (columnExists('projects','due_date')) $legacyCols[] = 'p.due_date AS project_due';
        $legacySql = 'SELECT DISTINCT '.implode(', ', $legacyCols).' FROM project_team pt JOIN projects p ON p.id=pt.project_id JOIN employees e ON e.id=pt.employee_id WHERE pt.employee_id=? AND p.business_owner_id=? AND e.business_owner_id=? AND LOWER(TRIM(e.name))=LOWER(TRIM(?))';
        if (columnExists('employees','status')) $legacySql .= " AND LOWER(COALESCE(e.status,'active')) IN ('active','hired','working')";
        $legacySql .= ' ORDER BY p.id DESC';
        $legacyStmt = $conn->prepare($legacySql);
        if ($legacyStmt) {
            $legacyStmt->bind_param('iiis', $myEmployeeId, $__ownerId, $__ownerId, $myUsername);
            $legacyStmt->execute();
            foreach ($legacyStmt->get_result()->fetch_all(MYSQLI_ASSOC) as $assignedTask) {
                $taskId = (int)($assignedTask['id'] ?? 0);
                if ($taskId > 0 && !isset($seenTaskIds[$taskId])) { $myTeamTasks[] = $assignedTask; $seenTaskIds[$taskId] = true; }
            }
            $legacyStmt->close();
        }
    }
    // Worker task display order: in-progress projects first, then newest/recent
    // projects, with older projects naturally appearing toward the bottom.
    usort($myTeamTasks, static function (array $a, array $b): int {
        $activeStatuses = ['in progress','in_progress','active','working'];
        $statusA = strtolower(trim((string)($a['project_status'] ?? '')));
        $statusB = strtolower(trim((string)($b['project_status'] ?? '')));
        $rankA = in_array($statusA, $activeStatuses, true) ? 0 : 1;
        $rankB = in_array($statusB, $activeStatuses, true) ? 0 : 1;
        if ($rankA !== $rankB) return $rankA <=> $rankB;
        $dateA = strtotime((string)($a['project_created'] ?? '')) ?: 0;
        $dateB = strtotime((string)($b['project_created'] ?? '')) ?: 0;
        if ($dateA !== $dateB) return $dateB <=> $dateA;
        return ((int)($b['id'] ?? 0)) <=> ((int)($a['id'] ?? 0));
    });

    $myAssignedCount = count($myTeamTasks);
    $myCompletedCount = 0;
    foreach ($myTeamTasks as $myTask) if (in_array(strtolower(trim((string)($myTask['project_status'] ?? ''))), ['completed','complete','done','approved'], true)) $myCompletedCount++;
    $myInProgressCount = 0;
    foreach ($myTeamTasks as $myTask) if (in_array(strtolower(trim((string)($myTask['project_status'] ?? ''))), ['in progress','in_progress','active','working'], true)) $myInProgressCount++;
    $myContributionRate = $myAssignedCount > 0 ? (int)round(($myCompletedCount / $myAssignedCount) * 100) : 0;
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Team Management | DEVSTUDIO SIMS</title><script src="https://cdn.tailwindcss.com"></script><link rel="stylesheet" href="assets/theme.css"></head>
<body class="bg-slate-900 text-white"><div class="ds-shell ds-unified-shell"><?php include "partial_nav.php"; ?><main class="ds-main ds-unified-main"><div class="max-w-6xl mx-auto p-5 md:p-8">
  <div class="mb-7"><p class="text-sm text-cyan-300 font-semibold mb-2">WORKSPACE</p><h1 class="text-3xl font-bold mb-2">Team Management</h1><p class="text-slate-400">See your teammates, review your assigned project tasks, and track your contribution.</p></div>
  <section class="mb-8"><div class="flex items-center justify-between gap-3 mb-4"><div><h2 class="text-xl font-bold">My Team</h2><p class="text-sm text-slate-400">People working in your business.</p></div><span class="rounded-full bg-slate-800 px-3 py-1 text-sm text-slate-300"><?= count($workerTeam) ?> members</span></div>
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
    <?php foreach ($workerTeam as $member): ?><article class="ds-panel p-4 flex items-center gap-3"><div class="w-11 h-11 rounded-full bg-cyan-900/60 text-cyan-200 flex items-center justify-center font-bold"><?= htmlspecialchars(strtoupper(substr(trim((string)($member['name'] ?? 'T')),0,1))) ?></div><div class="min-w-0"><p class="font-semibold truncate"><?= htmlspecialchars((string)($member['name'] ?? 'Team member')) ?><?php if ((int)$member['id'] === $myEmployeeId): ?> <span class="text-xs text-cyan-300">(You)</span><?php endif; ?></p><p class="text-sm text-slate-400"><?= htmlspecialchars((string)($member['role'] ?? 'Team member')) ?></p><p class="text-xs text-slate-500"><?= htmlspecialchars((string)($member['employee_id'] ?: ($member['worker_id'] ?? 'Team member'))) ?></p></div></article><?php endforeach; ?>
    <?php if (!$workerTeam): ?><div class="ds-panel p-5 text-slate-400 sm:col-span-2 lg:col-span-3">Your team directory will appear here when team members have been added.</div><?php endif; ?>
    </div>
  </section>
  <section class="mb-8"><div class="mb-4"><h2 class="text-xl font-bold">My Team Tasks</h2><p class="text-sm text-slate-400">Projects assigned to you by your team lead or manager.</p></div>
    <div class="ds-panel overflow-x-auto"><table class="w-full text-left"><thead class="bg-slate-800/70"><tr><th class="p-3 text-sm">Project</th><th class="p-3 text-sm">Status</th><th class="p-3 text-sm">Priority</th><th class="p-3 text-sm">Due date</th></tr></thead><tbody>
    <?php foreach ($myTeamTasks as $task): $taskStatus = trim((string)($task['project_status'] ?? 'Not started')); ?><tr class="border-t border-slate-700"><td class="p-3 font-medium"><?= htmlspecialchars((string)$task['project_title']) ?></td><td class="p-3"><span class="rounded-full bg-slate-800 px-2 py-1 text-xs"><?= htmlspecialchars($taskStatus !== '' ? ucwords(str_replace('_',' ',$taskStatus)) : 'Not started') ?></span></td><td class="p-3 text-sm text-slate-300"><?= htmlspecialchars((string)($task['project_priority'] ?? '—')) ?></td><td class="p-3 text-sm text-slate-300"><?= !empty($task['project_due']) && $task['project_due'] !== '0000-00-00' ? htmlspecialchars((string)$task['project_due']) : '—' ?></td></tr><?php endforeach; ?>
    <?php if (!$myTeamTasks): ?><tr><td colspan="4" class="p-5 text-slate-400">No projects are assigned to your employee profile yet. Ask your manager to assign you to a project.</td></tr><?php endif; ?>
    </tbody></table></div>
  </section>
  <section><div class="mb-4"><h2 class="text-xl font-bold">My Contribution</h2><p class="text-sm text-slate-400">A personal summary based on your assigned projects.</p></div>
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
      <div class="ds-panel p-4"><p class="text-sm text-slate-400">Assigned projects</p><p class="text-3xl font-bold mt-2"><?= $myAssignedCount ?></p></div>
      <div class="ds-panel p-4"><p class="text-sm text-slate-400">In progress</p><p class="text-3xl font-bold mt-2"><?= $myInProgressCount ?></p></div>
      <div class="ds-panel p-4"><p class="text-sm text-slate-400">Completed</p><p class="text-3xl font-bold mt-2"><?= $myCompletedCount ?></p></div>
      <div class="ds-panel p-4"><p class="text-sm text-slate-400">Completion rate</p><p class="text-3xl font-bold mt-2"><?= $myContributionRate ?>%</p></div>
    </div>
  </section>
</div></main></div></body></html>
<?php exit; }
?>
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Team Management</title>

<script src="https://cdn.tailwindcss.com"></script>

<script src="https://unpkg.com/lucide@latest"></script>

<link rel="stylesheet" href="assets/theme.css">

</head>

<body class="bg-slate-900 text-white">
 <div class="ds-shell ds-unified-shell">
<?php include "partial_nav.php"; ?>
<div class="ds-main ds-unified-main">


<div class="max-w-7xl mx-auto p-5 md:p-6">

<div class="flex justify-between items-center mb-8 flex-wrap gap-4">

<h1 class="text-3xl font-bold">

Team Management

</h1>



<?php if($__me): ?>
<div class="text-right text-sm">
<span class="text-slate-400"><?= htmlspecialchars($__me['username']) ?></span>
&middot;
</div>
<?php endif; ?>

</div>

<?php if($flash): ?>

<div class="mb-6 bg-slate-800 p-4 rounded-lg">

<?= htmlspecialchars($flash['error'] ?? 'Success') ?>

</div>

<?php endif; ?>

<div class="grid grid-cols-1 sm:grid-cols-3 gap-5 mb-8">

<div class="bg-slate-800 p-5 rounded-xl">

<div class="text-slate-400">

Employees

</div>

<div class="text-4xl font-bold text-blue-400">

<?= count($employees) ?>

</div>

</div>

<div class="bg-slate-800 p-5 rounded-xl">

<div class="text-slate-400">

Payroll

</div>

<div class="text-3xl font-bold text-emerald-400">

₱<?= number_format($stats['payroll']) ?>

</div>

</div>

<div class="bg-slate-800 p-5 rounded-xl">

<div class="text-slate-400">

Budget

</div>

<div class="text-3xl font-bold text-green-400">

₱<?= number_format($companyCash, 2) ?>

</div>

</div>

</div>

<section class="mb-6 grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3" aria-label="Team overview">
<?php
$overviewCards = [
 ['Total Employees', (string)count($employees), 'Currently on your roster'],
 ['Active Workers', $teamOverview['active_workers']===null ? '—' : (string)$teamOverview['active_workers'], 'From recorded employee status'],
 ['Projects Assigned', $teamOverview['projects_assigned']===null ? '—' : (string)$teamOverview['projects_assigned'], 'Matching project records'],
 ['Tasks Pending', $teamOverview['tasks_pending']===null ? '—' : (string)$teamOverview['tasks_pending'], 'Matching task records'],
 ['Needs Attention', (string)$teamOverview['needs_attention'], 'Critical or due in 1–2 days']
];
foreach ($overviewCards as $card): ?>
 <div class="rounded-xl border border-slate-700 bg-slate-800 p-3 min-w-0"><div class="text-xs text-slate-400 leading-4"><?=htmlspecialchars($card[0])?></div><div class="mt-1 text-2xl font-bold text-teal-300"><?=htmlspecialchars($card[1])?></div><div class="mt-1 text-[11px] text-slate-500"><?=htmlspecialchars($card[2])?></div></div>
<?php endforeach; ?>
</section>

<section class="rounded-xl border border-slate-700 bg-slate-800 p-4 mb-6">
 <div class="flex flex-wrap items-center justify-between gap-3 mb-3"><div><h2 class="text-lg font-bold">Employee Profiles</h2><p class="text-xs text-slate-400">Search the roster and open a worker profile for details.</p></div><input id="teamEmployeeSearch" type="search" placeholder="Search name, role, or employee ID…" class="w-full sm:w-72 rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-sm text-white" aria-label="Search employees"></div>
 <div id="teamEmployeeGrid" class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
 <?php foreach ($employees as $emp): $empId=(int)($emp['id']??0); $empName=(string)($emp['name']??'Employee'); $empRole=(string)($emp['role']??'Worker'); $empCode=(string)($emp['employee_id']??('EMP-'.str_pad((string)$empId,5,'0',STR_PAD_LEFT))); $empStatus=(string)($emp['status']??'Not recorded'); $__workerEmployment = $__workerEmploymentByUsername[mb_strtolower(trim($empName), 'UTF-8')] ?? null; ?>
 <article class="team-employee-card rounded-lg border border-slate-700 bg-slate-900/70 p-3" data-search="<?=htmlspecialchars(mb_strtolower($empName.' '.$empRole.' '.$empCode),ENT_QUOTES,'UTF-8')?>">
  <div class="flex items-start justify-between gap-2"><div class="min-w-0"><div class="font-semibold truncate"><?=htmlspecialchars($empName)?></div><div class="text-xs text-slate-400 mt-1"><?=htmlspecialchars($empRole)?></div></div><span class="shrink-0 rounded-full bg-slate-700 px-2 py-1 text-[10px] text-slate-300"><?=htmlspecialchars($empStatus)?></span></div>
  <div class="mt-3 flex items-center justify-between gap-2"><span class="font-mono text-xs text-teal-300"><?=htmlspecialchars($empCode)?></span><button type="button" class="team-profile-open text-xs rounded-md border border-slate-600 px-2.5 py-1.5 hover:bg-slate-700" data-profile="team-profile-<?=$empId?>">View profile</button></div>
  <dialog id="team-profile-<?=$empId?>" class="team-profile-dialog w-[min(92vw,460px)] rounded-xl border border-slate-600 bg-slate-900 p-0 text-white backdrop:bg-black/70"><div class="p-5"><div class="flex justify-between gap-3"><div><h3 class="text-xl font-bold"><?=htmlspecialchars($empName)?></h3><p class="text-sm text-slate-400"><?=htmlspecialchars($empRole)?> · <?=htmlspecialchars($empCode)?></p></div><button type="button" class="team-profile-close rounded-md px-2 py-1 text-slate-300 hover:bg-slate-700" aria-label="Close profile">✕</button></div><div class="mt-4 grid grid-cols-2 gap-3"><div class="rounded-lg bg-slate-800 p-3"><div class="text-xs text-slate-400">Employment status</div><div class="mt-1 font-semibold"><?=htmlspecialchars($empStatus)?></div></div><div class="rounded-lg bg-slate-800 p-3"><div class="text-xs text-slate-400">Monthly salary</div><div class="mt-1 font-semibold">₱<?=number_format((float)($emp['salary']??0),2)?></div></div></div><p class="mt-4 text-xs text-slate-500">Only information currently recorded in the employee roster is shown here.</p>
  <?php if ($__workerEmployment): ?><form method="post" class="mt-5 border-t border-slate-700 pt-4" onsubmit="return confirm('Fire <?=htmlspecialchars(addslashes($empName), ENT_QUOTES, 'UTF-8')?> and remove their access to this business? This action cannot be undone from this screen.');"><?=appCsrfField()?> <input type="hidden" name="employment_id" value="<?=(int)$__workerEmployment['employment_id']?>"><button type="submit" name="fire_worker" value="1" class="w-full rounded-lg border border-red-500/50 bg-red-600/15 px-4 py-2.5 font-bold text-red-200 hover:bg-red-600 hover:text-white">Fired — Remove from Business</button><p class="mt-2 text-xs text-slate-500">Ends their employment and removes access to this business. Their account itself will not be deleted.</p></form><?php endif; ?>
  </div></dialog>
 </article>
 <?php endforeach; ?>
 <?php if (!$employees): ?><p class="text-sm text-slate-400">No team members yet.</p><?php endif; ?>
 </div><p id="teamNoSearchResults" class="hidden mt-3 text-sm text-slate-400">No employees match your search.</p>
</section>


<script>
document.addEventListener('DOMContentLoaded',()=>{
 const search=document.getElementById('teamEmployeeSearch'), cards=[...document.querySelectorAll('.team-employee-card')], empty=document.getElementById('teamNoSearchResults');
 if(search) search.addEventListener('input',()=>{const q=search.value.trim().toLowerCase();let shown=0;cards.forEach(c=>{const ok=(c.dataset.search||'').includes(q);c.classList.toggle('hidden',!ok);if(ok)shown++;});if(empty)empty.classList.toggle('hidden',shown!==0);});
 document.querySelectorAll('.team-profile-open').forEach(b=>b.addEventListener('click',()=>{const d=document.getElementById(b.dataset.profile);if(d&&d.showModal)d.showModal();}));
 document.querySelectorAll('.team-profile-close').forEach(b=>b.addEventListener('click',()=>b.closest('dialog')?.close()));
 document.querySelectorAll('.team-profile-dialog').forEach(d=>d.addEventListener('click',e=>{if(e.target===d)d.close();}));
});
</script>

<div class="mt-8 bg-slate-800 rounded-xl p-6">
<h2 class="text-2xl font-bold mb-2">Candidate Pool</h2>
<p class="text-sm text-slate-400 mb-5">Workers who requested to join your business appear here. Select a candidate to set their workplace role and monthly salary, then confirm hiring.</p>
<input id="candidateSearch" type="search" placeholder="Search candidate name..." class="w-full md:max-w-md mb-5 rounded-lg bg-slate-700 border border-slate-600 p-3 text-white" aria-label="Search candidate name">
<div id="candidateList" class="grid grid-cols-1 lg:grid-cols-2 gap-4">
<?php foreach($candidates as $candidate): ?>
<div class="candidate-card bg-slate-700 rounded-lg p-4" data-candidate-name="<?= htmlspecialchars(mb_strtolower((string)$candidate['name']), ENT_QUOTES, 'UTF-8') ?>">
  <div class="flex items-start justify-between gap-4">
    <div><div class="font-bold candidate-name"><?= htmlspecialchars($candidate['name']) ?></div>
      <div class="text-sm text-slate-300">Applied to join your business</div>
      <div class="text-xs text-slate-400 mt-1">Application received: <?= htmlspecialchars(date('M j, Y', strtotime($candidate['applied_at']))) ?></div>
    </div>
    <span class="text-xs rounded-full bg-amber-400/10 text-amber-300 px-3 py-1">Pending application</span>
  </div>
  <div class="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2">
    <a href="inbox.php?employment_id=<?=(int)$candidate['application_id']?>" class="inline-flex items-center justify-center gap-2 rounded-lg border border-cyan-500/50 bg-cyan-500/10 hover:bg-cyan-500/20 px-4 py-3 font-semibold text-cyan-200"><span aria-hidden="true">💬</span> Message Candidate</a>
    <button type="button" class="hire-candidate-btn rounded-lg bg-emerald-600 hover:bg-emerald-500 px-4 py-3 font-bold text-white" data-application-id="<?=(int)$candidate['application_id']?>" data-candidate-name="<?= htmlspecialchars($candidate['name'], ENT_QUOTES, 'UTF-8') ?>">Set Up as Worker / Hire</button>
  </div>
</div>
<?php endforeach; ?>
</div>
<?php if (!$candidates): ?><div class="border border-dashed border-slate-600 rounded-lg p-5 text-slate-400">No applications yet. Workers will appear here after they request to join your business.</div><?php endif; ?>
<div id="candidateNoResults" class="hidden text-slate-400 py-4">No candidate matches that name.</div>
</div>

<div id="hireCandidateModal" class="fixed inset-0 z-50 hidden items-center justify-center bg-black/70 p-4" style="display:none;">
 <div class="w-full max-w-md rounded-2xl border border-slate-700 bg-slate-900 p-6 shadow-2xl">
  <h3 class="text-xl font-bold">Hire Candidate</h3>
  <p class="text-slate-400 mt-2">Set up <strong id="hireCandidateName" class="text-white"></strong> as a worker in your business.</p>
  <form method="post" class="mt-5 space-y-4"><?= appCsrfField() ?>
   <input type="hidden" name="application_id" id="hireApplicationId" value="">
   <label class="block text-sm">Workplace Role<select name="candidate_role" class="mt-1 w-full rounded-lg bg-slate-800 border border-slate-700 p-3"><option value="worker">Worker</option><option value="manager">Manager</option></select></label>
   <label class="block text-sm">Monthly Salary (₱)<input type="number" name="candidate_salary" min="1" step="1" required class="mt-1 w-full rounded-lg bg-slate-800 border border-slate-700 p-3" placeholder="e.g. 15000"></label>
   <p class="text-xs text-slate-400">Confirming hires this applicant and unlocks business access for their account.</p>
   <div class="flex justify-end gap-3"><button type="button" id="cancelHireCandidate" class="rounded-lg border border-slate-600 px-4 py-2">Cancel</button><button type="submit" name="approve_candidate" value="1" class="rounded-lg bg-emerald-600 hover:bg-emerald-500 px-4 py-2 font-bold">Confirm Hire</button></div>
  </form>
 </div>
</div>

<?php
// Show a one-time in-session popup for each newly visible pending application.
$pendingPopup = $candidates[0] ?? null;
$showApplicationPopup = false;
if ($pendingPopup && (int)($_SESSION['last_workplace_popup_application'] ?? 0) !== (int)$pendingPopup['application_id']) {
    $_SESSION['last_workplace_popup_application'] = (int)$pendingPopup['application_id'];
    $showApplicationPopup = true;
}
?>
<?php if ($showApplicationPopup): ?>
<div id="newApplicationModal" class="fixed inset-0 z-40 flex items-center justify-center bg-black/70 p-4"><div class="w-full max-w-md rounded-2xl border border-teal-500/40 bg-slate-900 p-6 text-center shadow-2xl"><div class="text-3xl mb-2">🔔</div><h3 class="text-xl font-bold">New Workplace Request</h3><p class="text-slate-300 mt-3"><strong><?=htmlspecialchars($pendingPopup['name'])?></strong> wants to work at your business.</p><p class="text-sm text-slate-400 mt-2">Review the candidate in the Candidate Pool to hire them.</p><button type="button" id="closeNewApplicationModal" class="mt-5 rounded-lg bg-teal-400 px-5 py-2 font-bold text-slate-900">View Candidate Pool</button></div></div>
<?php endif; ?>

<script>
document.addEventListener('DOMContentLoaded', function () {
 const search = document.getElementById('candidateSearch');
 const cards = Array.from(document.querySelectorAll('.candidate-card'));
 const noResults = document.getElementById('candidateNoResults');
 if (search) search.addEventListener('input', function () {
   const query = search.value.trim().toLocaleLowerCase(); let visible = 0;
   cards.forEach(card => { const match = (card.dataset.candidateName || '').includes(query); card.classList.toggle('hidden', !match); if (match) visible++; });
   if (noResults) noResults.classList.toggle('hidden', visible !== 0);
 });
 const modal = document.getElementById('hireCandidateModal');
 const appId = document.getElementById('hireApplicationId');
 const candidateName = document.getElementById('hireCandidateName');
 function openHire(id, name) { if (!modal) return; appId.value = id; candidateName.textContent = name; modal.classList.remove('hidden'); modal.classList.add('flex'); modal.style.display = 'flex'; }
 function closeHire() { if (!modal) return; modal.classList.add('hidden'); modal.classList.remove('flex'); modal.style.display = 'none'; }
 document.querySelectorAll('.hire-candidate-btn').forEach(button => button.addEventListener('click', () => openHire(button.dataset.applicationId, button.dataset.candidateName)));
 const cancel = document.getElementById('cancelHireCandidate'); if (cancel) cancel.addEventListener('click', closeHire);
 if (modal) modal.addEventListener('click', e => { if (e.target === modal) closeHire(); });
 const applicationModal = document.getElementById('newApplicationModal');
 const closeApplication = document.getElementById('closeNewApplicationModal');
 if (closeApplication && applicationModal) closeApplication.addEventListener('click', () => { applicationModal.remove(); document.getElementById('candidateSearch')?.focus(); });
});
</script>

<footer class="text-center text-slate-500 text-sm py-10">

DEVSTUDIO SIMS © <?= date("Y") ?>

</footer>

<script>

lucide.createIcons();

</script>

</div></div>
</body>

</html>
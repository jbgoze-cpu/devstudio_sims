<?php
session_start();
require_once 'db.php';
requireLogin();
$user = currentUser();
if (!$user || !in_array(($user['role'] ?? ''), ['owner', 'worker'], true)) {
    http_response_code(403);
    exit('Please sign in with a valid workspace account to access stored submissions.');
}
$id = (int)($_GET['id'] ?? 0);
$stmt = $conn->prepare('SELECT ps.original_name, ps.stored_name, ps.project_id FROM project_submissions ps WHERE ps.id=? LIMIT 1');
$stmt->bind_param('i', $id);
$stmt->execute();
$submission = $stmt->get_result()->fetch_assoc();
if (!$submission || !getProject((int)$submission['project_id'])) {
    http_response_code(404);
    exit('Submission not found for your team.');
}
$path = __DIR__ . '/uploads/submissions/' . basename($submission['stored_name']);
if (!is_file($path)) {
    http_response_code(404);
    exit('The submitted file is no longer available.');
}
header('X-Content-Type-Options: nosniff');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . str_replace(['"', "\r", "\n"], '', basename($submission['original_name'])) . '"');
header('Content-Length: ' . filesize($path));
readfile($path);
exit;

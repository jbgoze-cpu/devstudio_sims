DEVSTUDIO SIMS — Analytics & Decision Modeling updates

Business Analytics:
- Added compact Financial Performance comparison bars for recorded income/expenses and scenario gains/costs (last 30 days).
- Added data-derived Smart Business Insights for negative cash flow, low/zero budget, project risk, overdue/failed projects, and pending review.
- Added Project Performance metrics: completion rate, pending review, overdue/failed, and high-risk counts.
- Added owner/manager-only CSV report export with finance summary and project list.
- Reduced card spacing and list spacing to reduce unnecessary scrolling; mobile layout still scrolls where needed.

Decision Modeling:
- Improved the what-if preview with current vs projected Budget, cash impact, percentage impact, remaining-reserve warning, and team-effect caveat.
- Explicitly labels the impact as a simulation only; no real budget or business records are changed by previewing.

Validation:
- PHP syntax checked for edited PHP files.
- Not tested against a live MySQL database/browser. Confirm your database contains the existing simulation_business_events and project tables.
- Export uses CSV and is restricted to owner/manager business roles.

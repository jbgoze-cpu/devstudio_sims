<?php
session_start();
require_once 'db.php';
requireLogin();
require_once 'business_helpers.php';
$me = currentUser();
$role = businessRoleForUser($conn, $me);
if (!in_array($role, ['owner', 'manager'], true)) {
    header('Location: worker_messages.php');
    exit;
}
$uid = (int)$me['id'];
$ownerId = null;
if ($role === 'owner') {
    $ownerId = $uid;
} else {
    // A manager can only see conversations for the business that hired them as a manager.
    $ownerStmt = $conn->prepare("SELECT owner_id FROM business_employment WHERE worker_id=? AND status='hired' AND employment_role='manager' ORDER BY updated_at DESC LIMIT 1");
    if ($ownerStmt) {
        $ownerStmt->bind_param('i', $uid);
        $ownerStmt->execute();
        $ownerRow = $ownerStmt->get_result()->fetch_assoc();
        $ownerStmt->close();
        if ($ownerRow) $ownerId = (int)$ownerRow['owner_id'];
    }
}
$rows = [];
if ($ownerId) {
    $stmt = $conn->prepare("SELECT e.id,e.business_name,e.employment_role,e.status,e.created_at,e.updated_at,w.username AS worker_name,w.id AS worker_id FROM business_employment e JOIN users w ON w.id=e.worker_id WHERE e.owner_id=? AND (e.status='hired' OR (e.status='pending' AND e.created_at >= DATE_SUB(NOW(), INTERVAL 3 DAY))) ORDER BY CASE WHEN e.status='pending' THEN 0 ELSE 1 END,e.updated_at DESC");
    if ($stmt) {
        $stmt->bind_param('i', $ownerId);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
    }
}
function bm_h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Chatbox</title><script src="https://cdn.tailwindcss.com"></script><link rel="stylesheet" href="assets/theme.css"></head>
<body class="bg-slate-900 text-white"><main class="max-w-4xl mx-auto p-4 md:p-6"><a class="ds-btn" href="<?= $role === 'manager' ? 'team.php' : 'demo.php' ?>">Back to Dashboard</a><header class="my-6"><p class="text-xs uppercase tracking-widest text-cyan-300">Workplace communication</p><h1 class="text-2xl md:text-3xl font-bold mt-1">Chatbox</h1><p class="text-slate-400 mt-2">Chat privately with workers who requested to join your business and workers you have hired.</p></header>
<?php if (!$ownerId): ?>
<section class="ds-panel"><h2 class="text-lg font-semibold">No business connected</h2><p class="text-slate-400 mt-2">This manager account is not currently linked to a business. Ask the business owner to confirm your manager employment.</p></section>
<?php elseif (!$rows): ?>
<section class="ds-panel"><h2 class="text-lg font-semibold">No worker conversations yet</h2><p class="text-slate-400 mt-2">When someone requests to join your business, their conversation will appear here. You can also chat with workers you have hired.</p><a class="ds-btn process inline-block mt-4" href="team.php">Manage Hiring</a></section>
<?php else: ?>
<section><h2 class="text-xl font-semibold mb-3">Business Conversations</h2><div class="grid gap-3"><?php foreach ($rows as $row): $pending = $row['status'] === 'pending'; ?><article class="ds-panel flex flex-col sm:flex-row sm:items-center gap-4 justify-between"><div><h2 class="font-semibold text-lg"><?=bm_h($row['worker_name'])?></h2><p class="text-slate-400 text-sm mt-1"><?=bm_h($row['business_name'] ?: 'Business')?></p><p class="text-xs mt-2 <?= $pending ? 'text-amber-300' : 'text-emerald-300' ?>"><?= $pending ? 'Join request pending — you can chat with this applicant' : 'Hired — active business conversation' ?></p></div><a class="ds-btn process text-center" href="inbox.php?employment_id=<?=(int)$row['id']?>">Open Chat →</a></article><?php endforeach; ?></div></section>
<?php endif; ?></main></body></html>

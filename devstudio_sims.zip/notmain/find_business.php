<?php
session_start();
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/business_helpers.php';
requireLogin();
verifyAppCsrfPost();
$me = currentUser();
$userId = (int)($me['id'] ?? 0);
if (($me['role'] ?? '') !== 'worker') {
    http_response_code(403);
    exit('Find a Business is available to worker accounts.');
}
// Ensure the workplace-request table exists and is compatible with older installations.
$conn->query("CREATE TABLE IF NOT EXISTS business_employment (
  id INT AUTO_INCREMENT PRIMARY KEY, owner_id INT NOT NULL, worker_id INT NOT NULL,
  business_name VARCHAR(150) NULL, employment_role ENUM('worker','manager') NOT NULL DEFAULT 'worker',
  status ENUM('pending','hired','declined','fired') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_employment_owner_status (owner_id,status), INDEX idx_employment_worker_status (worker_id,status),
  INDEX idx_employment_owner_worker (owner_id,worker_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Some existing databases may have an older version of this table. Add only missing fields.
$employmentColumns = [];
$columnResult = $conn->query("SHOW COLUMNS FROM business_employment");
if ($columnResult) { while ($column = $columnResult->fetch_assoc()) $employmentColumns[$column['Field']] = true; $columnResult->free(); }
$requiredEmploymentColumns = [
    'business_name' => "ALTER TABLE business_employment ADD COLUMN business_name VARCHAR(150) NULL",
    'employment_role' => "ALTER TABLE business_employment ADD COLUMN employment_role ENUM('worker','manager') NOT NULL DEFAULT 'worker'",
    'status' => "ALTER TABLE business_employment ADD COLUMN status ENUM('pending','hired','declined','fired') NOT NULL DEFAULT 'pending'",
    'created_at' => "ALTER TABLE business_employment ADD COLUMN created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP",
    'updated_at' => "ALTER TABLE business_employment ADD COLUMN updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
];
foreach ($requiredEmploymentColumns as $columnName => $alterSql) {
    if (!isset($employmentColumns[$columnName])) { try { $conn->query($alterSql); } catch (Throwable $e) { error_log('Find a Business schema update: '.$e->getMessage()); } }
}

// Read optional profile columns safely so older users tables do not crash the marketplace.
$userColumns = [];
$userColumnResult = $conn->query("SHOW COLUMNS FROM users");
if ($userColumnResult) { while ($column = $userColumnResult->fetch_assoc()) $userColumns[$column['Field']] = true; $userColumnResult->free(); }
if (!isset($userColumns['business_name']) || !isset($userColumns['username']) || !isset($userColumns['role'])) {
    http_response_code(500);
    exit('Find a Business needs the users table to contain username, role, and business_name. Please check the database schema.');
}
$locationSelect = isset($userColumns['business_location']) ? 'u.business_location' : "'' AS business_location";
$locationSearch = ''; // Marketplace search intentionally matches business name only.
$flash = '';
$popupSuccess = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_request'])) {
    $requestId = (int)($_POST['request_id'] ?? 0);
    $cancel = $conn->prepare("UPDATE business_employment SET status='declined', updated_at=CURRENT_TIMESTAMP WHERE id=? AND worker_id=? AND status='pending'");
    $cancel->bind_param('ii', $requestId, $userId);
    $cancel->execute();
    $cancelled = $cancel->affected_rows > 0;
    $cancel->close();
    $flash = $cancelled ? 'Your request has been cancelled. You can request to join another business now.' : 'That pending request could not be cancelled.';
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['join_business'])) {
    $ownerId = (int)($_POST['owner_id'] ?? 0);
    $confirmed = ($_POST['confirmed'] ?? '') === 'yes';
    // business_location is optional in older installations, so do not reference it unless it exists.
    $ownerLocationSelect = isset($userColumns['business_location']) ? 'business_location' : "'' AS business_location";
    $ownerStmt = $conn->prepare("SELECT id,business_name,{$ownerLocationSelect} FROM users WHERE id=? AND role='owner' LIMIT 1");
    $ownerStmt->bind_param('i', $ownerId);
    $ownerStmt->execute();
    $ownerResult = $ownerStmt->get_result();
    $business = $ownerResult ? $ownerResult->fetch_assoc() : null;
    $ownerStmt->close();
    if (!$confirmed) $flash = 'Please confirm that you want to join this workplace.';
    elseif (!$business || trim((string)$business['business_name']) === '') $flash = 'That business could not be found.';
    else {
        $active = $conn->prepare("SELECT id FROM business_employment WHERE worker_id=? AND status='hired' LIMIT 1");
        $active->bind_param('i',$userId); $active->execute(); $alreadyHired = $active->get_result()->fetch_assoc(); $active->close();
        $duplicate = $conn->prepare("SELECT id,status FROM business_employment WHERE worker_id=? AND owner_id=? AND (status='hired' OR (status='pending' AND created_at >= DATE_SUB(NOW(), INTERVAL 3 DAY))) LIMIT 1");
        $duplicate->bind_param('ii',$userId,$ownerId); $duplicate->execute(); $existing = $duplicate->get_result()->fetch_assoc(); $duplicate->close();
        $recent = $conn->prepare("SELECT id,owner_id,created_at FROM business_employment WHERE worker_id=? AND status='pending' AND created_at >= DATE_SUB(NOW(), INTERVAL 3 DAY) ORDER BY created_at DESC LIMIT 1");
        $recent->bind_param('i',$userId); $recent->execute(); $recentRequest = $recent->get_result()->fetch_assoc(); $recent->close();
        if ($alreadyHired) $flash = 'You already have a workplace. Leave your current workplace before requesting another.';
        elseif ($existing && $existing['status']==='hired') $flash = 'You already work at this business.';
        elseif ($existing) $flash = 'Your request to join this business is already pending. You may cancel it if you want to choose another business.';
        elseif ($recentRequest) $flash = 'You can only send one workplace request every 3 days. Cancel your pending request to choose another business sooner.';
        else {
            // Expire older pending requests so they no longer appear active after the three-day window.
            $expire = $conn->prepare("UPDATE business_employment SET status='declined', updated_at=CURRENT_TIMESTAMP WHERE worker_id=? AND status='pending' AND created_at < DATE_SUB(NOW(), INTERVAL 3 DAY)");
            $expire->bind_param('i',$userId); $expire->execute(); $expire->close();
            $name = (string)$business['business_name'];
            $insert = $conn->prepare("INSERT INTO business_employment (owner_id,worker_id,business_name,employment_role,status) VALUES (?,?,?,'worker','pending')");
            $insert->bind_param('iis',$ownerId,$userId,$name);
            if ($insert->execute()) { $flash = 'Request to join has been sent. Please wait for a response from the business owner.'; $popupSuccess = true; businessNotify($conn,$ownerId,'New workplace request',($me['username'] ?? 'A worker').' wants to join '.$name.'.','team.php'); }
            else $flash = 'Could not send your request. Please try again.';
            $insert->close();
        }
    }
}
$pendingStmt = $conn->prepare("SELECT be.id,be.business_name,be.created_at,be.owner_id FROM business_employment be WHERE be.worker_id=? AND be.status='pending' AND be.created_at >= DATE_SUB(NOW(), INTERVAL 3 DAY) ORDER BY be.created_at DESC LIMIT 1");
$pendingStmt->bind_param('i',$userId); $pendingStmt->execute(); $pendingRequest=$pendingStmt->get_result()->fetch_assoc(); $pendingStmt->close();
$hiredStmt = $conn->prepare("SELECT id FROM business_employment WHERE worker_id=? AND status='hired' LIMIT 1");
$hiredStmt->bind_param('i',$userId); $hiredStmt->execute(); $hasWorkplace=(bool)$hiredStmt->get_result()->fetch_assoc(); $hiredStmt->close();
$search = trim((string)($_GET['q'] ?? ''));
$like = '%'.$search.'%';
$businessSql = "SELECT u.id,u.business_name,{$locationSelect} AS business_location,u.username,
    (SELECT be.status FROM business_employment be WHERE be.owner_id=u.id AND be.worker_id=? AND (be.status='hired' OR (be.status='pending' AND be.created_at >= DATE_SUB(NOW(), INTERVAL 3 DAY))) ORDER BY be.id DESC LIMIT 1) AS my_status
    FROM users u WHERE u.role='owner' AND COALESCE(TRIM(u.business_name),'')<>'' AND (?='' OR u.business_name LIKE ?)
    ORDER BY u.business_name ASC";
$stmt = $conn->prepare($businessSql);
$stmt->bind_param('iss',$userId,$search,$like);
$stmt->execute(); $businesses=$stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
function fb_e($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Find a Business | DEVSTUDIO SIMS</title><script src="https://cdn.tailwindcss.com"></script><link rel="stylesheet" href="assets/theme.css"><style>.biz-card{background:linear-gradient(145deg,#1e293b,#111827);border:1px solid #334155;border-radius:16px;padding:20px;display:flex;flex-direction:column;gap:12px}.biz-card:hover{border-color:#2dd4bf}.biz-btn{background:#2dd4bf;color:#042f2e;padding:10px 15px;border-radius:9px;font-weight:800}.biz-muted{color:#94a3b8}</style></head>
<body class="bg-slate-900 text-white"><div class="ds-shell ds-unified-shell"><?php include 'partial_nav.php'; ?><main class="ds-main ds-unified-main"><div class="max-w-6xl mx-auto p-6 md:p-8"><div class="flex flex-wrap items-start justify-between gap-4 mb-7"><div><div class="text-xs tracking-widest text-teal-300 font-bold mb-2">WORKER MARKETPLACE</div><h1 class="text-3xl font-bold">Find a Business</h1><p class="biz-muted mt-2">Explore registered businesses and request to join a workplace. The owner must approve your request before you are hired.</p></div><a href="demo.php" class="ds-btn">Back to Dashboard</a></div>
<?php if($flash!==''): ?><div class="mb-5 rounded-xl border border-teal-500/40 bg-teal-500/10 p-4 text-teal-100"><?=fb_e($flash)?></div><?php endif; ?>
<form method="get" class="ds-panel flex flex-col sm:flex-row gap-3 mb-6"><input type="search" name="q" value="<?=fb_e($search)?>" placeholder="Search business name..." class="flex-1 rounded-lg bg-slate-950 border border-slate-700 px-4 py-3 text-white"><button class="biz-btn" type="submit">Search Businesses</button><?php if($search!==''): ?><a href="find_business.php" class="ds-btn text-center">Clear</a><?php endif; ?></form>
<div class="flex items-center justify-between gap-3 mb-4"><h2 class="text-xl font-bold">Registered Businesses</h2><span class="text-sm biz-muted"><?=count($businesses)?> found</span></div>
<?php if(!$businesses): ?><div class="ds-panel text-center py-12"><div class="text-3xl mb-3">⌕</div><h3 class="font-bold text-lg">No businesses found</h3><p class="biz-muted mt-2">Try another search, or check back when more businesses register.</p></div><?php else: ?><div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4"><?php foreach($businesses as $b): ?><article class="biz-card"><div class="flex items-start justify-between gap-3"><div><h3 class="text-lg font-bold"><?=fb_e($b['business_name'])?></h3><p class="text-sm biz-muted mt-1">Owner: <?=fb_e($b['username'])?></p></div><span class="text-xs rounded-full px-3 py-1 bg-slate-800 border border-slate-700">Registered</span></div><p class="text-sm biz-muted">📍 <?=fb_e($b['business_location'] ?: 'Location not provided')?></p><div class="mt-auto pt-3 border-t border-slate-700">
<?php if(($b['my_status']??'')==='hired'): ?><button class="w-full rounded-lg bg-emerald-900/50 text-emerald-300 px-4 py-3 font-bold" disabled>✓ Your Workplace</button>
<?php elseif(($b['my_status']??'')==='pending'): ?><button class="w-full rounded-lg bg-amber-900/40 text-amber-200 px-4 py-3 font-bold" disabled>Request Pending</button>
<?php elseif($hasWorkplace): ?><button class="w-full rounded-lg bg-slate-800 text-slate-400 px-4 py-3 font-bold" disabled>Already Employed</button>
<?php elseif($pendingRequest): ?><button class="w-full rounded-lg bg-slate-800 text-slate-400 px-4 py-3 font-bold" disabled>Request Limit: 3 Days</button>
<?php else: ?><button class="biz-btn w-full" type="button" data-open-join data-owner-id="<?=(int)$b['id']?>" data-business-name="<?=fb_e($b['business_name'])?>">Request to Join Business</button><?php endif; ?></div></article><?php endforeach; ?></div><?php endif; ?>
<?php if($pendingRequest): ?><div class="mt-6 rounded-xl border border-amber-500/40 bg-amber-500/10 p-4"><div class="font-bold text-amber-200">Pending workplace request: <?=fb_e($pendingRequest['business_name'] ?: 'Business')?></div><p class="text-sm biz-muted mt-1">You can only have one pending request at a time. If there is no response within 3 days, you may choose another business. You can also cancel this request now.</p><form method="post" class="mt-3" onsubmit="return confirm('Cancel your pending workplace request? You can then request to join another business.');"><?=appCsrfField()?><input type="hidden" name="request_id" value="<?=(int)$pendingRequest['id']?>"><button type="submit" name="cancel_request" value="1" class="rounded-lg border border-rose-500/50 bg-rose-500/10 px-4 py-2 font-bold text-rose-200">Cancel Request</button></form></div><?php endif; ?>
<div id="joinConfirmModal" class="fixed inset-0 z-50 hidden items-center justify-center bg-black/70 p-4" style="display:none;"><div class="w-full max-w-md rounded-2xl border border-slate-700 bg-slate-900 p-6 shadow-2xl"><h3 class="text-xl font-bold">Confirm workplace request</h3><p id="joinConfirmText" class="biz-muted mt-3">Are you sure you want to request to join this business?</p><form method="post" class="mt-6 flex justify-end gap-3"><?=appCsrfField()?><input type="hidden" name="owner_id" id="joinOwnerId" value=""><input type="hidden" name="confirmed" value="yes"><button type="button" class="ds-btn" onclick="closeJoinModal()">No, go back</button><button type="submit" name="join_business" value="1" class="biz-btn">Yes, send request</button></form></div></div>
<?php if($popupSuccess): ?><div id="joinSuccessModal" class="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4"><div class="w-full max-w-md rounded-2xl border border-teal-500/40 bg-slate-900 p-6 text-center shadow-2xl"><div class="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-full bg-teal-500/15 text-3xl text-teal-300">✓</div><h3 class="text-xl font-bold">Request Sent</h3><p class="biz-muted mt-3">Request to join has been sent. Please wait for a response from the business owner.</p><p class="biz-muted mt-2 text-sm">You can request another business after 3 days, or cancel this request to choose another business sooner.</p><button type="button" class="biz-btn mt-5 w-full" onclick="document.getElementById('joinSuccessModal').remove()">Okay</button></div></div><?php endif; ?>
<script>
function openJoinModal(ownerId, businessName) { const id=document.getElementById('joinOwnerId'); const text=document.getElementById('joinConfirmText'); const modal=document.getElementById('joinConfirmModal'); if(!id || !text || !modal) return; id.value=ownerId; text.textContent='Are you sure you want to request to work at '+businessName+'? Your request will be sent to the business owner for approval.'; modal.classList.remove('hidden'); modal.classList.add('flex'); modal.style.display='flex'; }
function closeJoinModal() { const modal=document.getElementById('joinConfirmModal'); if(!modal) return; modal.classList.add('hidden'); modal.classList.remove('flex'); modal.style.display='none'; }
document.addEventListener('click', function(e){ const btn=e.target.closest('[data-open-join]'); if(btn){ e.preventDefault(); openJoinModal(btn.getAttribute('data-owner-id'), btn.getAttribute('data-business-name') || 'this business'); }});
document.addEventListener('keydown', function(e){ if(e.key==='Escape') closeJoinModal(); });
</script>
</div></main></div></body></html>

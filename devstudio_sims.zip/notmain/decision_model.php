<?php
session_start();
require_once 'db.php';
require_once 'simulation_helpers.php';
requireLogin();

$me = currentUser();
$uid = (int)($me['id'] ?? 0);
$ownerId = (int)(function_exists('currentBusinessOwnerId') ? (currentBusinessOwnerId() ?? 0) : 0);
$businessRole = businessRoleForUser($conn, $me);
$canManage = in_array($businessRole, ['owner','manager'], true);
$scenarios = [
 'delay' => [
  'title'=>'What-If Scenario',
  'context'=>'A client milestone is behind schedule. Choose how to recover delivery without ignoring budget, quality, or team wellbeing.',
  'choices'=>[
   'overtime'=>['label'=>'Authorize limited overtime','cash'=>-4500,'morale'=>-8,'efficiency'=>10,'summary'=>'Short-term delivery capacity improves, but overtime can increase fatigue if repeated.'],
   'scope'=>['label'=>'Negotiate a smaller first release','cash'=>1500,'morale'=>3,'efficiency'=>2,'summary'=>'The first release becomes more manageable and saves resources, but the client may see reduced scope.'],
   'reassign'=>['label'=>'Reassign an experienced developer','cash'=>-2000,'morale'=>-2,'efficiency'=>8,'summary'=>'The deadline risk decreases, but other work may slow while the experienced developer is reassigned.']
  ]
 ],
 'budget'=>[
  'title'=>'Unexpected Budget Shortfall',
  'context'=>'A required tool or service costs more than expected. Select a response that keeps the project viable.',
  'choices'=>[
   'cut_marketing'=>['label'=>'Pause optional marketing','cash'=>2500,'morale'=>0,'efficiency'=>0,'summary'=>'Cash is preserved, but fewer new leads may arrive in the next cycle.'],
   'phase'=>['label'=>'Negotiate phased delivery and payment','cash'=>4000,'morale'=>2,'efficiency'=>2,'summary'=>'A staged plan improves cash flow and expectation management, although coordination is needed.'],
   'absorb'=>['label'=>'Pay the cost from the reserve','cash'=>-6000,'morale'=>1,'efficiency'=>4,'summary'=>'The project continues with minimal disruption, but the studio has less cash for future risks.']
  ]
 ],
 'burnout'=>[
  'title'=>'Team Capacity Under Pressure',
  'context'=>'The team is working under pressure. Decide whether to prioritize recovery time, delivery speed, or capability.',
  'choices'=>[
   'recovery'=>['label'=>'Schedule a recovery day','cash'=>-1500,'morale'=>12,'efficiency'=>5,'summary'=>'Recovery improves morale and can restore sustainable productivity, with a small schedule cost.'],
   'overtime'=>['label'=>'Push for another overtime sprint','cash'=>1000,'morale'=>-12,'efficiency'=>-5,'summary'=>'A short-term push may appear productive, but fatigue can reduce future output and trust.'],
   'training'=>['label'=>'Invest in targeted team training','cash'=>-3000,'morale'=>4,'efficiency'=>10,'summary'=>'Training costs time and cash now but can improve the team’s ability to handle later tasks.']
  ]
 ],
 'scope'=>[
  'title'=>'Client Requests Extra Features',
  'context'=>'A client requests additional features after work has started. Decide how to protect scope, budget, and the relationship.',
  'choices'=>[
   'change_order'=>['label'=>'Create a paid change request','cash'=>5000,'morale'=>2,'efficiency'=>1,'summary'=>'The extra work receives a budget and clear acceptance criteria before the team proceeds.'],
   'absorb_scope'=>['label'=>'Accept the extra work at no charge','cash'=>-3500,'morale'=>-2,'efficiency'=>-3,'summary'=>'The client may appreciate the flexibility, but unplanned work consumes capacity and margin.'],
   'decline'=>['label'=>'Decline the extra scope for this release','cash'=>0,'morale'=>2,'efficiency'=>3,'summary'=>'The team protects the agreed plan, but the client may be disappointed if expectations were not clarified.']
  ]
 ]
];

if ($ownerId < 1) {
 $state = null; $cash = 0; $recent = [];
} else {
 $state = simState($ownerId); $cash = simCash($ownerId);
 $stmt = $conn->prepare("SELECT * FROM simulation_business_events WHERE owner_id=? ORDER BY id DESC LIMIT 8");
 $stmt->bind_param('i',$ownerId); $stmt->execute(); $recent=$stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
}
$selected = (string)($_GET['scenario'] ?? $_POST['scenario'] ?? 'delay');
if (!isset($scenarios[$selected])) $selected='delay';
$flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);

if ($_SERVER['REQUEST_METHOD']==='POST') {
 $token = (string)($_POST['csrf'] ?? '');
 if (!hash_equals((string)($_SESSION['sim_csrf'] ?? ''), $token)) {
  simFlashRedirect('Your session token expired. Please try again.','error','decision_model.php?scenario='.urlencode($selected));
 }
 if (!$canManage) { http_response_code(403); exit('Only the studio owner or manager can apply simulation decisions or record simulated finances.'); }
 $action = (string)($_POST['action'] ?? '');
 if ($action === 'decision' || $action === 'preview') {
  // Decision Modeling is intentionally a what-if sandbox. Never apply scenario
  // deltas to the real studio budget, team metrics, points, or business history.
  simFlashRedirect('What-if only: no budget, team metrics, points, or business data were changed.','success','decision_model.php?scenario='.urlencode($selected));
 }
 simFlashRedirect('Unknown action.','error','decision_model.php?scenario='.urlencode($selected));
}

if ($ownerId>0) { $state=simState($ownerId); $cash=simCash($ownerId); }
$scenarioData=$scenarios[$selected];
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Decision Modeling | DEVSTUDIO SIMS</title><script src="https://cdn.tailwindcss.com"></script><script src="https://unpkg.com/lucide@latest"></script><link rel="stylesheet" href="assets/theme.css"><style>
.sim-card{background:rgba(15,23,42,.82);border:1px solid rgba(148,163,184,.2);border-radius:14px;padding:18px}.sim-choice{display:block;border:1px solid rgba(148,163,184,.22);border-radius:12px;padding:14px;cursor:pointer;transition:border-color .15s,background .15s}.sim-choice:has(input:checked){border-color:#2dd4bf;background:rgba(20,184,166,.09)}.sim-choice input{accent-color:#2dd4bf}.sim-meter{height:7px;background:#334155;border-radius:999px;overflow:hidden}.sim-meter span{display:block;height:100%;border-radius:999px;background:linear-gradient(90deg,#14b8a6,#fbbf24)}.sim-muted{color:#94a3b8}
/* Compact Decision Modeling workspace */
.decision-wrap{padding:10px!important;max-width:1600px!important}.sim-card{padding:12px;border-radius:12px}.sim-choice{padding:10px}.decision-support{margin-top:0!important;gap:10px!important;display:grid;grid-template-columns:minmax(0,1fr)}.decision-support .sim-card{padding:11px}.decision-list{max-height:110px;overflow:auto}.decision-heading{margin-bottom:10px!important}.decision-intro{display:none}@media(min-width:1100px){.decision-wrap{height:auto;overflow:visible}.decision-main-grid{min-height:0;grid-template-columns:minmax(0,1fr) minmax(0,1fr)!important;align-items:start;gap:12px!important}.decision-main-grid>.scenario-panel{grid-column:1;grid-row:1}.decision-main-grid>.decision-support{grid-column:2;grid-row:1;grid-template-columns:minmax(0,1fr)!important}.decision-support .sim-card{min-height:0}.decision-support .sim-card p.sim-muted{line-height:1.25}.decision-list{max-height:120px}}@media(max-width:1099px){.decision-wrap{height:auto;overflow:visible}}
</style></head><body class="bg-slate-900 text-white"><div class="ds-shell ds-unified-shell"><?php include 'partial_nav.php'; ?><main class="ds-main ds-unified-main min-w-0"><div class="max-w-7xl mx-auto p-5 md:p-8 decision-wrap">
<div class="flex flex-wrap justify-between items-start gap-3 mb-3 decision-heading"><div><p class="ds-eyebrow">DECISION THEORY · SIMULATION</p><h1 class="text-3xl md:text-4xl font-bold">Decision Modeling</h1><p class="sim-muted mt-1 max-w-2xl decision-intro">Test management choices in a safe what-if sandbox. All projected changes are hypothetical; your actual studio budget and business data stay unchanged.</p></div><a class="ds-button" href="analytics.php">View Analytics →</a></div>
<?php if($flash): ?><div class="mb-5 rounded-xl border px-4 py-3 <?= ($flash['type']??'')==='error'?'border-red-500/40 bg-red-500/10 text-red-200':'border-emerald-500/40 bg-emerald-500/10 text-emerald-100' ?>"><?= simEscape($flash['message']??'') ?></div><?php endif; ?>
<?php if($ownerId<1): ?><section class="sim-card"><h2 class="text-xl font-semibold">No active studio</h2><p class="sim-muted mt-2">This account is not linked to a business yet. Register or sign in with a Team Leader account to run the simulation.</p></section>
<?php else: ?>
<div class="grid grid-cols-1 gap-3 mb-6">
 <?php $metricCards=[]; if($canManage)$metricCards[]=['Budget','₱'.number_format($cash,2)]; foreach($metricCards as $metric): ?><div class="sim-card"><p class="sim-muted text-sm"><?= simEscape($metric[0]) ?></p><p class="text-2xl font-bold mt-2"><?= simEscape($metric[1]) ?></p></div><?php endforeach; ?>
</div>
<div class="grid grid-cols-1 gap-3 decision-main-grid">
<section class="sim-card scenario-panel"><div class="flex flex-wrap items-start justify-between gap-3"><div><p class="text-xs uppercase tracking-widest text-teal-300">Scenario tree · Step 1</p><h2 class="text-2xl font-bold mt-2"><?= simEscape($scenarioData['title']) ?></h2></div><span class="text-xs rounded-full bg-amber-400/10 text-amber-200 px-3 py-1">Simulated scenario</span></div><p class="sim-muted mt-2 mb-2"><?= simEscape($scenarioData['context']) ?></p><p class="text-xs text-teal-200/90 mb-3">Choose an option to compare current Budget with the projected scenario balance. This is a what-if simulation only; no real funds or records change.</p>
<div class="flex flex-wrap gap-2 mb-3"><?php foreach($scenarios as $key=>$item): ?><a href="decision_model.php?scenario=<?= simEscape($key) ?>" class="rounded-lg border px-3 py-2 text-sm <?= $selected===$key?'border-teal-400 bg-teal-400/10 text-teal-200':'border-slate-700 text-slate-300 hover:border-slate-500' ?>"><?= simEscape($item['title']) ?></a><?php endforeach; ?></div>
<?php if(!$canManage): ?><p class="rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-100 p-4">View-only mode: only the studio owner can apply decisions or change simulated finances.</p><?php else: ?>
<form id="whatIfForm" class="space-y-2" onsubmit="return false;"><input type="hidden" id="whatIfCurrentCash" value="<?= simEscape((string)$cash) ?>">
<?php foreach($scenarioData['choices'] as $key=>$choice): ?><label class="sim-choice"><span class="flex items-start gap-3"><input type="radio" name="choice" value="<?= simEscape($key) ?>" required class="mt-1" data-choice="<?= simEscape(json_encode($choice, JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_TAG|JSON_HEX_AMP)) ?>"><span class="flex-1"><strong class="block"><?= simEscape($choice['label']) ?></strong><span class="sim-muted text-sm block mt-1"><?= simEscape($choice['summary']) ?></span><span class="grid sm:grid-cols-2 gap-2 mt-3 text-xs"><span class="rounded-md bg-slate-800 px-2 py-1">Hypothetical budget impact: <b class="<?= $choice['cash']<0?'text-rose-300':'text-emerald-300' ?>"><?= $choice['cash']>=0?'+':'−' ?>₱<?= number_format(abs($choice['cash'])) ?></b></span></span></span></span></label><?php endforeach; ?>
<button id="previewWhatIf" class="mt-2 rounded-lg bg-teal-400 hover:bg-teal-300 text-slate-950 font-bold px-5 py-3" type="button">Preview What-If Outcome</button></form>
<div id="whatIfResult" class="hidden mt-5 rounded-xl border border-teal-400/30 bg-teal-400/5 p-4" aria-live="polite"></div>
<?php endif; ?></section>

<?php if($canManage):
$advisorWorkers=[]; $riskProjects=[];
try {
 $advisorSql="SELECT u.id,u.username,COUNT(DISTINCT CASE WHEN LOWER(COALESCE(p.status,'')) NOT IN ('completed','missed deadline') THEN p.id END) active_projects, SUM(CASE WHEN LOWER(COALESCE(p.status,''))='missed deadline' THEN 1 ELSE 0 END) missed_projects FROM business_employment be JOIN users u ON u.id=be.worker_id LEFT JOIN project_worker_assignments pwa ON pwa.worker_id=u.id LEFT JOIN projects p ON p.id=pwa.project_id AND p.business_owner_id=be.owner_id WHERE be.owner_id=? AND be.status='hired' GROUP BY u.id,u.username ORDER BY active_projects ASC,u.username ASC";
 $as=$conn->prepare($advisorSql);$as->bind_param('i',$ownerId);$as->execute();$advisorWorkers=$as->get_result()->fetch_all(MYSQLI_ASSOC);$as->close();
} catch(Throwable $e) { $advisorWorkers=[]; }
try {
 $hasDeadline=columnExists('projects','deadline_at');
 if($hasDeadline){$rs=$conn->prepare("SELECT id,title,status,deadline_at FROM projects WHERE business_owner_id=? AND deadline_at IS NOT NULL AND LOWER(COALESCE(status,'')) NOT IN ('completed','missed deadline') AND deadline_at <= DATE_ADD(NOW(), INTERVAL 3 DAY) ORDER BY deadline_at ASC LIMIT 8");$rs->bind_param('i',$ownerId);$rs->execute();$riskProjects=$rs->get_result()->fetch_all(MYSQLI_ASSOC);$rs->close();}
} catch(Throwable $e) { $riskProjects=[]; }
?>
<section class="decision-support">
 <div class="sim-card"><p class="text-xs uppercase tracking-widest text-teal-300">Decision support · Live business data</p><h2 class="text-xl font-bold mt-2">Smart Worker Assignment</h2><p class="sim-muted text-sm mt-2">A starting-point recommendation based on each hired worker’s current active project load. This is advisory only and does not assign anyone automatically.</p>
 <?php if(!$advisorWorkers): ?><p class="sim-muted mt-4 text-sm">No hired workers found, or assignment data is not available yet.</p><?php else: ?><div class="space-y-2 mt-3 decision-list"><?php foreach(array_slice($advisorWorkers,0,5) as $w): ?><div class="rounded-lg bg-slate-800 p-3 flex items-center justify-between gap-3"><div><p class="font-semibold"><?= simEscape($w['username']) ?></p><p class="sim-muted text-xs mt-1"><?= (int)$w['active_projects'] ?> active project(s) · <?= (int)$w['missed_projects'] ?> missed-deadline project(s)</p></div><span class="text-xs rounded-full px-3 py-1 <?= (int)$w['active_projects']===0?'bg-emerald-500/15 text-emerald-200':((int)$w['active_projects']>=3?'bg-rose-500/15 text-rose-200':'bg-amber-500/15 text-amber-200') ?>"><?= (int)$w['active_projects']===0?'Available':((int)$w['active_projects']>=3?'High workload':'Review load') ?></span></div><?php endforeach; ?></div><p class="sim-muted text-xs mt-3">Recommendation: review workers with fewer active assignments first, then verify skills and deadlines before assigning.</p><?php endif; ?></div>
 <div class="sim-card"><p class="text-xs uppercase tracking-widest text-amber-300">Early warning system</p><h2 class="text-xl font-bold mt-2">Risk Detection</h2><p class="sim-muted text-sm mt-2">Projects with deadlines approaching in the next 72 hours are flagged for review. This panel is read-only.</p>
 <?php if(!$riskProjects): ?><div class="rounded-lg bg-slate-800 p-4 mt-4"><p class="font-semibold text-emerald-200">No imminent deadline risks detected</p><p class="sim-muted text-sm mt-1">No active project with a recorded deadline is due within the next three days, or deadline data is unavailable.</p></div><?php else: ?><div class="space-y-2 mt-3 decision-list"><?php foreach(array_slice($riskProjects,0,3) as $rp): $remaining=strtotime((string)$rp['deadline_at'])-time(); ?><div class="rounded-lg bg-slate-800 p-3"><div class="flex items-start justify-between gap-2"><p class="font-semibold"><?= simEscape($rp['title']??('Project #'.$rp['id'])) ?></p><span class="text-xs rounded-full bg-rose-500/15 text-rose-200 px-2 py-1">Deadline risk</span></div><p class="sim-muted text-xs mt-1">Due <?= simEscape(date('M j, Y g:i A',strtotime((string)$rp['deadline_at']))) ?> · <?= $remaining<0?'Overdue':(int)floor($remaining/3600).' hour(s) remaining' ?></p><p class="text-xs text-amber-200 mt-2">Suggested action: review progress, clarify blockers, and discuss workload with the assigned worker.</p></div><?php endforeach; ?></div><?php endif; ?></div>
</section>
</div>

<?php endif; ?>
<?php endif; ?>
</main></div><script>
(function(){
 const form=document.getElementById('whatIfForm'), button=document.getElementById('previewWhatIf'), result=document.getElementById('whatIfResult');
 if(!form||!button||!result)return;
 button.addEventListener('click',function(){
  const selected=form.querySelector('input[name="choice"]:checked');
  if(!selected){result.classList.remove('hidden');result.innerHTML='<strong>Select an option first.</strong>';return;}
  let choice; try{choice=JSON.parse(selected.dataset.choice||'{}')}catch(e){return;}
  const cash=Number(document.getElementById('whatIfCurrentCash').value||0), delta=Number(choice.cash||0), projected=cash+delta;
  const money=n=>'₱'+Math.abs(n).toLocaleString('en-PH',{minimumFractionDigits:2,maximumFractionDigits:2});
  const signed=n=>(n>=0?'+':'−')+money(n);
  result.classList.remove('hidden');
  result.innerHTML='<p class="text-xs uppercase tracking-widest text-teal-300">Cash Flow & Scenario Impact · Preview only</p>'+ 
   '<h3 class="text-xl font-bold mt-2"></h3><p class="sim-muted text-sm mt-2"></p>'+ 
   '<div class="grid sm:grid-cols-2 gap-3 mt-4"><div class="rounded-lg bg-slate-800 p-3"><p class="sim-muted text-xs">Actual studio budget (unchanged)</p><p class="text-xl font-bold mt-1">'+money(cash)+'</p></div><div class="rounded-lg bg-slate-800 p-3"><p class="sim-muted text-xs">Hypothetical budget after this choice</p><p class="text-xl font-bold mt-1">'+(projected<0?'−':'')+money(projected)+'</p><p class="text-xs mt-1 '+(delta<0?'text-rose-300':'text-emerald-300')+'">'+signed(delta)+' in this scenario only</p></div></div>'+ 
   '<div class="grid sm:grid-cols-3 gap-2 mt-3"><div class="rounded-lg bg-slate-800 p-3"><p class="sim-muted text-xs">Budget impact</p><p class="font-bold '+(delta<0?'text-rose-300':'text-emerald-300')+'">'+signed(delta)+'</p></div><div class="rounded-lg bg-slate-800 p-3"><p class="sim-muted text-xs">Budget change</p><p class="font-bold">'+(cash!==0?(delta/cash*100).toFixed(1):'—')+'% </p></div><div class="rounded-lg bg-slate-800 p-3"><p class="sim-muted text-xs">Scenario risk</p><p class="font-bold '+(projected<0?'text-rose-300':(projected<cash*0.2?'text-amber-200':'text-emerald-300'))+'">'+(projected<0?'Budget goes below zero':(projected<cash*0.2?'Low remaining reserve':'Review assumptions'))+'</p></div></div>'+ '<p class="sim-muted text-sm mt-3">Possible team effects: morale '+(Number(choice.morale)>=0?'+':'')+Number(choice.morale||0)+', efficiency '+(Number(choice.efficiency)>=0?'+':'')+Number(choice.efficiency||0)+'. These are illustrative scenario values, not measured forecasts. Nothing is applied to the real Budget or business records.</p>'; 
  result.querySelector('h3').textContent=choice.label||'Scenario result';
  result.querySelector('h3').insertAdjacentText('afterend','');
  result.querySelector('h3').nextElementSibling.textContent=choice.summary||'';
 });
})();
if(window.lucide)lucide.createIcons();</script></body></html>

<?php
session_start();require_once 'db.php';require_once 'simulation_helpers.php';requireLogin();
$me=currentUser();$uid=(int)($me['id']??0);$businessRole=businessRoleForUser($conn,$me);$isWorkerView=(($me['role']??'')==='worker'||$businessRole==='worker');$canSeeCash=in_array($businessRole,['owner','manager'],true);$ownerId=(int)(function_exists('currentBusinessOwnerId')?(currentBusinessOwnerId()??0):0);
$isOwner=(($me['role']??'')==='owner' && $ownerId===$uid);
$state=$ownerId>0?simState($ownerId):null;
if($isOwner)simCheckAchievements($ownerId,$uid);
$projects=$ownerId>0&&function_exists('getProjects')?getProjects():[];if(!is_array($projects))$projects=[];
$projectCount=count($projects);$complete=0;$active=0;$riskCount=0;
foreach($projects as $p){$s=strtolower((string)($p['status']??''));if(in_array($s,['complete','completed'],true))$complete++;else $active++;if(in_array(strtolower((string)($p['risk']??'')),['high','critical','danger'],true))$riskCount++;}
$employeeCount=0;
if($ownerId>0 && tableExists('business_employment')){$stmt=$conn->prepare("SELECT COUNT(*) n FROM business_employment WHERE owner_id=? AND status='hired'");if($stmt){$stmt->bind_param('i',$ownerId);$stmt->execute();$employeeCount=(int)($stmt->get_result()->fetch_assoc()['n']??0);$stmt->close();}}
$cash=($canSeeCash && $ownerId>0)?simCash($ownerId):null;
$business=trim((string)($me['business_name']??''));if($business==='')$business='Your Software Studio';
function dashEscape($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Business Dashboard | DEVSTUDIO SIMS</title><script src="https://cdn.tailwindcss.com"></script><script src="https://unpkg.com/lucide@latest"></script><link rel="stylesheet" href="assets/theme.css"><style>.dash-card{background:rgba(15,23,42,.82);border:1px solid rgba(148,163,184,.18);border-radius:14px;padding:18px}.dash-muted{color:#94a3b8}.dash-link{display:flex;flex-direction:column;min-height:150px;transition:transform .15s,border-color .15s}.dash-link:hover{transform:translateY(-2px);border-color:rgba(45,212,191,.6)}</style></head><body class="bg-slate-900 text-white"><div class="ds-shell ds-unified-shell"><?php include 'partial_nav.php'; ?><main class="ds-main ds-unified-main min-w-0"><div class="max-w-7xl mx-auto p-5 md:p-8">
<header class="flex flex-wrap items-start justify-between gap-4 mb-7"><div><p class="ds-eyebrow">SOFTWARE BUSINESS SIMULATION</p><h1 class="text-3xl md:text-4xl font-bold"><?= dashEscape($business) ?></h1><p class="dash-muted mt-2">Plan projects, manage resources, model decisions, and learn from your studio’s performance.</p><span class="inline-flex mt-3 rounded-full bg-teal-400/10 text-teal-200 px-3 py-1 text-sm"><?= $businessRole==='owner'?'Studio Owner':($businessRole==='manager'?'Studio Manager':'Team Member · View Only') ?></span></div><?php if($canSeeCash): ?><a href="decision_model.php" class="rounded-lg bg-teal-400 text-slate-950 font-bold px-4 py-3">Make a Business Decision →</a><?php endif; ?></header>
<?php if($ownerId<1): ?><section class="dash-card mb-6"><h2 class="text-xl font-bold">No active studio linked</h2><p class="dash-muted mt-2">This account is not linked to a studio yet. Use a Team Leader account or join an existing business to view its simulation.</p></section><?php else: ?>
<div class="grid grid-cols-2 xl:grid-cols-3 gap-3 mb-6">
<?php if($canSeeCash): ?><div class="dash-card"><p class="dash-muted text-sm">Budget</p><p class="text-2xl font-bold mt-2">₱<?= number_format((float)$cash,2) ?></p><p class="text-xs dash-muted mt-1">Simulated balance</p></div><?php endif; ?>
<div class="dash-card"><p class="dash-muted text-sm">Active Projects</p><p class="text-2xl font-bold mt-2"><?= $active ?></p><p class="text-xs dash-muted mt-1"><?= $complete ?> completed</p></div>
<div class="dash-card"><p class="dash-muted text-sm">Decision Points</p><p class="text-2xl font-bold mt-2"><?= (int)$state['points'] ?></p><p class="text-xs dash-muted mt-1">Gamified progress</p></div>
</div>
<?php if(!columnExists('projects','business_owner_id')): ?><div class="mb-5 rounded-xl border border-amber-500/40 bg-amber-500/10 text-amber-100 p-4"><strong>Setup required:</strong> Import <code>project_business_migration.sql</code> in phpMyAdmin to enable business-specific projects and analytics.</div><?php endif; ?>
<section class="grid sm:grid-cols-2 xl:grid-cols-3 gap-4 mb-6">
<?php $dashNavNumber=0; ?>
<a href="project_management.php" class="dash-card dash-link"><span class="text-teal-300 text-sm"><?= sprintf('%02d',++$dashNavNumber) ?> · OPERATIONS</span><h2 class="text-xl font-bold mt-3">Project Management</h2><p class="dash-muted text-sm mt-2">Monitor progress, deadlines, risk, budgets, and project assignments.</p><span class="mt-auto pt-4 text-teal-300 text-sm">Open projects →</span></a>
<a href="feedback.php" class="dash-card dash-link"><span class="text-pink-300 text-sm"><?= sprintf('%02d',++$dashNavNumber) ?> · TEAM VOICE</span><h2 class="text-xl font-bold mt-3">Worker Feedback</h2><p class="dash-muted text-sm mt-2">Read feedback submitted by your team. Feedback cannot be edited by management.</p><span class="mt-auto pt-4 text-pink-300 text-sm">Open feedback →</span></a>
<a href="team.php" class="dash-card dash-link"><span class="text-cyan-300 text-sm"><?= sprintf('%02d',++$dashNavNumber) ?> · RESOURCES</span><h2 class="text-xl font-bold mt-3">Team Management</h2><p class="dash-muted text-sm mt-2">Manage team members, skills, and worker feedback.</p><span class="mt-auto pt-4 text-cyan-300 text-sm">Manage team →</span></a>
<?php if(!$isWorkerView): ?><a href="decision_model.php" class="dash-card dash-link"><span class="text-amber-300 text-sm"><?= sprintf('%02d',++$dashNavNumber) ?> · STRATEGY</span><h2 class="text-xl font-bold mt-3">Decision Modeling</h2><p class="dash-muted text-sm mt-2">Choose a response to business scenarios and review the resulting trade-offs.</p><span class="mt-auto pt-4 text-amber-300 text-sm">Explore scenarios →</span></a>
<a href="analytics.php" class="dash-card dash-link"><span class="text-violet-300 text-sm"><?= sprintf('%02d',++$dashNavNumber) ?> · INSIGHTS</span><h2 class="text-xl font-bold mt-3">Business Analytics</h2><p class="dash-muted text-sm mt-2">Review studio indicators, project status, cash flow, and decision history.</p><span class="mt-auto pt-4 text-violet-300 text-sm">View analytics →</span></a>
<?php endif; ?>
<a href="leaderboard.php" class="dash-card dash-link"><span class="text-rose-300 text-sm"><?= sprintf('%02d',++$dashNavNumber) ?> · GAMIFICATION</span><h2 class="text-xl font-bold mt-3">Studio Leaderboard</h2><p class="dash-muted text-sm mt-2">Compare decision points and reputation with other studios.</p><span class="mt-auto pt-4 text-rose-300 text-sm">View rankings →</span></a>
<?php if(!$isWorkerView): ?><a href="studio3d.php" class="dash-card dash-link"><span class="text-emerald-300 text-sm"><?= sprintf('%02d',++$dashNavNumber) ?> · VISUALIZATION</span><h2 class="text-xl font-bold mt-3">3D Studio View</h2><p class="dash-muted text-sm mt-2">Explore a visual representation of studio performance and project risk.</p><span class="mt-auto pt-4 text-emerald-300 text-sm">Open 3D view →</span></a>
<?php endif; ?>
</section>

<?php endif; ?></div></main></div><script>if(window.lucide)lucide.createIcons();</script></body></html>

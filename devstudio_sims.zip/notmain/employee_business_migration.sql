-- DEVSTUDIO SIMS: isolate simulated employees by studio.
-- Back up the database first, select devstudio_sims, then run once.
-- Requires a MySQL/MariaDB version supporting ADD COLUMN IF NOT EXISTS.
ALTER TABLE employees ADD COLUMN IF NOT EXISTS business_owner_id INT NULL;
CREATE INDEX idx_employees_business_owner ON employees (business_owner_id);

-- Preserve existing employee records by assigning unscoped legacy employees to
-- the earliest registered studio. New hires are assigned to their active owner.
UPDATE employees
SET business_owner_id = (
  SELECT owner_id FROM (
    SELECT id AS owner_id
    FROM users
    WHERE role='owner'
    ORDER BY created_at ASC, id ASC
    LIMIT 1
  ) AS first_owner
)
WHERE business_owner_id IS NULL;

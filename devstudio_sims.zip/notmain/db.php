<?php

/* ==========================================================
   DEVSTUDIO SIMS
   Database Backend
   Part 1 - Connection, Game State & Decision System
========================================================== */

$host = "localhost";
$user = "root";
$pass = "";
$db   = "devstudio_sims";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Database Connection Failed : " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

// Profile preferences used by Settings. Add missing columns safely for existing installs.
$profileColumns = [
    'birthday' => "ALTER TABLE users ADD COLUMN birthday DATE NULL",
    'personal_location' => "ALTER TABLE users ADD COLUMN personal_location VARCHAR(255) NULL"
];
foreach ($profileColumns as $column => $alterSql) {
    $safeColumn = $conn->real_escape_string($column);
    $check = $conn->query("SHOW COLUMNS FROM users LIKE '$safeColumn'");
    if ($check && $check->num_rows === 0) {
        $conn->query($alterSql);
    }
}



function appCsrfToken()
{
    if (session_status() !== PHP_SESSION_ACTIVE) return '';
    if (empty($_SESSION['app_csrf'])) $_SESSION['app_csrf'] = bin2hex(random_bytes(32));
    return (string)$_SESSION['app_csrf'];
}

function appCsrfField()
{
    return '<input type="hidden" name="app_csrf" value="' . htmlspecialchars(appCsrfToken(), ENT_QUOTES, 'UTF-8') . '">';
}

function verifyAppCsrfPost()
{
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') return;
    $expected = appCsrfToken();
    $provided = (string)($_POST['app_csrf'] ?? '');
    if ($expected === '' || !hash_equals($expected, $provided)) {
        http_response_code(400);
        exit('Your form expired or could not be verified. Refresh the page and try again.');
    }
}

/* ==========================================================
   HELPER FUNCTIONS
========================================================== */

function seedCatalogs()
{
    seedSkills();
    seedUpgrades();
}

seedCatalogs();

function tableExists($name)
{
    global $conn;

    $name = $conn->real_escape_string($name);

    $result = $conn->query("SHOW TABLES LIKE '$name'");

    return $result && $result->num_rows > 0;
}

/*
    Stops the page with a friendly notice if the tables this
    feature needs haven't been created yet, instead of a raw
    PHP fatal error.
*/
function requireTables($names)
{
    $missing = [];

    foreach ($names as $name) {
        if (!tableExists($name)) {
            $missing[] = $name;
        }
    }

    if (empty($missing)) {
        return;
    }

    echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Setup Needed | DEVSTUDIO SIMS</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="assets/theme.css">
    </head><body class="bg-slate-900 text-white">
    <div class="max-w-2xl mx-auto py-24 px-8">
    <div class="ds-panel accent-alert">
    <h1 class="text-2xl font-bold mb-3">Database setup needed</h1>
    <p class="text-slate-300 mb-4">This feature needs a few tables that aren\'t in your database yet: <strong>' . implode(', ', $missing) . '</strong>.</p>
    <p class="text-slate-400">Run <code class="ds-tag">schema_additions.sql</code> against your <code class="ds-tag">devstudio_sims</code> database, then reload this page.</p>
    <a href="demo.php" class="ds-btn primary mt-6">Back to Dashboard</a>
    </div></div></body></html>';
    exit;
}

function fetchOne($sql)
{
    global $conn;

    $result = $conn->query($sql);

    if (!$result) {
        return [];
    }

    return $result->fetch_assoc();
}

function fetchAll($sql)
{
    global $conn;

    $rows = [];

    $result = $conn->query($sql);

    if (!$result) {
        return [];
    }

    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }

    return $rows;
}

/* ==========================================================
   GAME STATE
========================================================== */

function getGameState()
{
    global $conn;

    $result = $conn->query("
        SELECT *
        FROM game_state
        LIMIT 1
    ");

    if (!$result || $result->num_rows == 0) {

        $conn->query("
            INSERT INTO game_state
            (
                id,
                cash,
                team,
                efficiency,
                achievement,
                project,
                deadline_days,
                budget_spent,
                budget_total,
                morale
            )
            VALUES
            (
                1,
                50000,
                5,
                75,
                0,
                20,
                30,
                0,
                100000,
                90
            )
        ");

        $result = $conn->query("
            SELECT *
            FROM game_state
            LIMIT 1
        ");
    }

    $game = $result->fetch_assoc();
    // Once logged in, expose the current studio's own saved values to legacy modules
    // instead of leaking the shared legacy singleton across different studios.
    if (session_status() === PHP_SESSION_ACTIVE && function_exists('currentBusinessOwnerId')) {
        $ownerId = (int)(currentBusinessOwnerId() ?? 0);
        if ($ownerId > 0) {
            $cashStmt = $conn->prepare("SELECT business_cash FROM users WHERE id=? AND role='owner' LIMIT 1");
            $cashStmt->bind_param("i", $ownerId);
            $cashStmt->execute();
            $cashRow = $cashStmt->get_result()->fetch_assoc();
            $cashStmt->close();
            if ($cashRow) $game['cash'] = (float)$cashRow['business_cash'];
            if (tableExists('simulation_business_state')) {
                $stateStmt = $conn->prepare("SELECT morale, efficiency, points FROM simulation_business_state WHERE owner_id=? LIMIT 1");
                $stateStmt->bind_param("i", $ownerId);
                $stateStmt->execute();
                $stateRow = $stateStmt->get_result()->fetch_assoc();
                $stateStmt->close();
                if ($stateRow) {
                    $game['morale'] = (int)$stateRow['morale'];
                    $game['efficiency'] = (int)$stateRow['efficiency'];
                    $game['achievement'] = (int)$stateRow['points'];
                }
            }
        }
    }
    return $game;
}

function updateGameState($data)
{
    global $conn;

    if (empty($data)) {
        return;
    }

    $fields = [];

    foreach ($data as $column => $value) {

        $fields[] = $column . "=" . intval($value);

    }

    $sql = "
        UPDATE game_state
        SET
        " . implode(",", $fields) . "
        WHERE id=1
    ";

    $conn->query($sql);
    if (session_status() === PHP_SESSION_ACTIVE && function_exists('currentBusinessOwnerId')) {
        $ownerId = (int)(currentBusinessOwnerId() ?? 0);
        if ($ownerId > 0) {
            if (array_key_exists('cash', $data)) {
                $cash = max(0, (float)$data['cash']);
                $syncCash = $conn->prepare("UPDATE users SET business_cash=? WHERE id=? AND role='owner'");
                if ($syncCash) { $syncCash->bind_param("di", $cash, $ownerId); $syncCash->execute(); $syncCash->close(); }
            }
            if (tableExists('simulation_business_state')) {
                foreach (['morale','efficiency'] as $metric) {
                    if (array_key_exists($metric, $data)) {
                        $metricValue = max(0, min(100, (int)$data[$metric]));
                        $stateUpdate = $conn->prepare("UPDATE simulation_business_state SET $metric=? WHERE owner_id=?");
                        if ($stateUpdate) { $stateUpdate->bind_param('ii', $metricValue, $ownerId); $stateUpdate->execute(); $stateUpdate->close(); }
                    }
                }
            }
        }
    }
}

function addCash($amount)
{
    global $conn;
    $amount = max(0, (float)$amount);

    $stmt = $conn->prepare("UPDATE game_state SET cash = cash + ? WHERE id = 1");
    if ($stmt) { $stmt->bind_param("d", $amount); $stmt->execute(); $stmt->close(); }

    // Keep the active studio owner's balance in sync, including actions performed by an assigned manager.
    if (session_status() === PHP_SESSION_ACTIVE && function_exists('currentBusinessOwnerId')) {
        $ownerId = (int)(currentBusinessOwnerId() ?? 0);
        if ($ownerId > 0) {
            $sync = $conn->prepare("UPDATE users SET business_cash = business_cash + ? WHERE id = ? AND role = 'owner'");
            if ($sync) { $sync->bind_param("di", $amount, $ownerId); $sync->execute(); $sync->close(); }
        }
    }
}

function subtractCash($amount)
{
    global $conn;
    $amount = max(0, (float)$amount);

    $stmt = $conn->prepare("UPDATE game_state SET cash = GREATEST(cash - ?, 0) WHERE id = 1");
    if ($stmt) { $stmt->bind_param("d", $amount); $stmt->execute(); $stmt->close(); }

    // Expenses and project funding reduce the active studio owner's balance, including manager actions.
    if (session_status() === PHP_SESSION_ACTIVE && function_exists('currentBusinessOwnerId')) {
        $ownerId = (int)(currentBusinessOwnerId() ?? 0);
        if ($ownerId > 0) {
            $sync = $conn->prepare("UPDATE users SET business_cash = GREATEST(business_cash - ?, 0) WHERE id = ? AND role = 'owner'");
            if ($sync) { $sync->bind_param("di", $amount, $ownerId); $sync->execute(); $sync->close(); }
        }
    }
}

function changeMorale($value)
{
    global $conn;

    $value = intval($value);

    $conn->query("
        UPDATE game_state
        SET morale=LEAST(100,GREATEST(0,morale+$value))
        WHERE id=1
    ");
    if (function_exists('currentBusinessOwnerId') && tableExists('simulation_business_state')) {
        $ownerId = (int)(currentBusinessOwnerId() ?? 0);
        if ($ownerId > 0) {
            $stmt = $conn->prepare("UPDATE simulation_business_state SET morale=LEAST(100,GREATEST(0,morale+?)) WHERE owner_id=?");
            $stmt->bind_param("ii", $value, $ownerId); $stmt->execute(); $stmt->close();
        }
    }
}

function changeEfficiency($value)
{
    global $conn;

    $value = intval($value);

    $conn->query("
        UPDATE game_state
        SET efficiency=LEAST(100,GREATEST(0,efficiency+$value))
        WHERE id=1
    ");
    if (function_exists('currentBusinessOwnerId') && tableExists('simulation_business_state')) {
        $ownerId = (int)(currentBusinessOwnerId() ?? 0);
        if ($ownerId > 0) {
            $stmt = $conn->prepare("UPDATE simulation_business_state SET efficiency=LEAST(100,GREATEST(0,efficiency+?)) WHERE owner_id=?");
            $stmt->bind_param("ii", $value, $ownerId); $stmt->execute(); $stmt->close();
        }
    }
}

function addAchievement()
{
    global $conn;

    $conn->query("
        UPDATE game_state
        SET achievement=achievement+1
        WHERE id=1
    ");
}

/* ==========================================================
   DECISION LOGS
========================================================== */

function currentBusinessOwnerId()
{
    global $conn;
    if (empty($_SESSION['user_id'])) return null;
    $uid = (int) $_SESSION['user_id'];
    $stmt = $conn->prepare("SELECT id, role FROM users WHERE id=? LIMIT 1");
    if (!$stmt) return null;
    $stmt->bind_param("i", $uid);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    if (!$user) return null;
    if ($user['role'] === 'owner') return (int) $user['id'];
    if (!tableExists('business_employment')) return null;
    $stmt = $conn->prepare("SELECT owner_id FROM business_employment WHERE worker_id=? AND status='hired' ORDER BY updated_at DESC LIMIT 1");
    if (!$stmt) return null;
    $stmt->bind_param("i", $uid);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    return $row ? (int) $row['owner_id'] : null;
}

function logDecision(
    $decision,
    $result,
    $message,
    $game
)
{
    global $conn;

    $stmt = $conn->prepare("
        INSERT INTO decisions
        (
            decision,
            result,
            message,
            cash,
            efficiency,
            morale,
            deadline_days, owner_id
        )
        VALUES
        (
            ?,?,?,?,?,?,?,?
        )
    ");

    $ownerId = currentBusinessOwnerId() ?? 0;
    $cash = (int) $game['cash'];
    $efficiency = (int) $game['efficiency'];
    $morale = (int) $game['morale'];
    $deadline = (int) $game['deadline_days'];
    $stmt->bind_param("sssiiiii", $decision, $result, $message, $cash, $efficiency, $morale, $deadline, $ownerId);
    $stmt->execute();
}

function getRecentDecisions($limit = 5)
{
    global $conn;

    $limit = intval($limit);

    $ownerId = currentBusinessOwnerId();
    if (!$ownerId) return [];
    return fetchAll("SELECT * FROM decisions WHERE owner_id=" . (int)$ownerId . " ORDER BY id DESC LIMIT $limit");
}

function getAllDecisions()
{
    $ownerId = currentBusinessOwnerId();
    if (!$ownerId) return [];
    return fetchAll("SELECT * FROM decisions WHERE owner_id=" . (int)$ownerId . " ORDER BY id DESC");
}

function getDecisionCountsByType()
{
    global $conn;

    $data = [
        "hire" => 0,
        "workload" => 0,
        "delay" => 0
    ];

    $result = $conn->query("
        SELECT
            decision,
            COUNT(*) total
        FROM decisions
        GROUP BY decision
    ");

    while ($row = $result->fetch_assoc()) {

        $data[$row['decision']] = $row['total'];

    }

    return $data;
}

function getDecisionCountsByResult()
{
    global $conn;

    $data = [
        "success" => 0,
        "warning" => 0,
        "danger" => 0
    ];

    $result = $conn->query("
        SELECT
            result,
            COUNT(*) total
        FROM decisions
        GROUP BY result
    ");

    while ($row = $result->fetch_assoc()) {

        $data[$row['result']] = $row['total'];

    }

    return $data;
}

function getDecisionStats()
{
    $game = getGameState();

    return [

        "total" => count(getAllDecisions()),

        "cash_spent" => $game['budget_spent'],

        "first" => date("Y-m-d")

    ];
}

/* ==========================================================
   RESET GAME
========================================================== */

function resetGameState()
{
    global $conn;

    $conn->query("DELETE FROM decisions");

    $conn->query("
        UPDATE game_state
        SET

        cash=50000,

        team=5,

        efficiency=75,

        achievement=0,

        project=20,

        deadline_days=30,

        budget_spent=0,

        budget_total=100000,

        morale=90

        WHERE id=1
    ");
}

function employeeOwnerId()
{
    if (function_exists('currentBusinessOwnerId')) {
        return (int)(currentBusinessOwnerId() ?? 0);
    }
    return 0;
}

function getEmployees($status = 'active')
{
    global $conn;
    if (!columnExists('employees', 'business_owner_id')) return [];
    $ownerId = employeeOwnerId();
    if ($ownerId < 1) return [];
    $stmt = $conn->prepare("SELECT * FROM employees WHERE business_owner_id=? AND status=? ORDER BY efficiency DESC, morale DESC");
    if (!$stmt) return [];
    $stmt->bind_param("is", $ownerId, $status);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

function getEmployee($id)
{
    global $conn;
    if (!columnExists('employees', 'business_owner_id')) return null;
    $ownerId = employeeOwnerId();
    if ($ownerId < 1) return null;
    $id = (int)$id;
    $stmt = $conn->prepare("SELECT * FROM employees WHERE id=? AND business_owner_id=? LIMIT 1");
    if (!$stmt) return null;
    $stmt->bind_param("ii", $id, $ownerId);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

function employeeExists($name)
{
    global $conn;
    if (!columnExists('employees', 'business_owner_id')) return false;
    $ownerId = employeeOwnerId();
    if ($ownerId < 1) return false;
    $stmt = $conn->prepare("SELECT id FROM employees WHERE name=? AND business_owner_id=? LIMIT 1");
    if (!$stmt) return false;
    $stmt->bind_param("si", $name, $ownerId);
    $stmt->execute();
    return $stmt->get_result()->num_rows > 0;
}

function hireEmployee($name, $role, $salary)
{
    global $conn;
    $ownerId = employeeOwnerId();
    if ($ownerId < 1 || !columnExists('employees', 'business_owner_id')) {
        return ["ok"=>false, "error"=>"Import the business employee migration before managing studio staff."];
    }
    $name = trim((string)$name); $role = trim((string)$role); $salary = (int)$salary;
    if ($name === '' || $role === '' || $salary <= 0) return ["ok"=>false, "error"=>"Enter a valid employee name, role, and salary."];
    if (employeeExists($name)) return ["ok"=>false, "error"=>"An employee with that name already exists in your studio."];

    $stmt = $conn->prepare("SELECT business_cash FROM users WHERE id=? AND role='owner' LIMIT 1");
    $stmt->bind_param("i", $ownerId); $stmt->execute();
    $owner = $stmt->get_result()->fetch_assoc(); $stmt->close();
    if (!$owner || (float)$owner['business_cash'] < $salary) return ["ok"=>false, "error"=>"Not enough studio cash to hire this employee."];

    $morale = 0; $efficiency = 0;
    $stmt = $conn->prepare("INSERT INTO employees (business_owner_id,name,role,salary,morale,efficiency,status) VALUES (?,?,?,?,?,?,'active')");
    $stmt->bind_param("issiii", $ownerId, $name, $role, $salary, $morale, $efficiency);
    if (!$stmt->execute()) return ["ok"=>false, "error"=>"The employee could not be added. Please try again."];
    $stmt->close();
    // No upfront hiring fee: salary is recorded as the employee's monthly salary.
    $game = getGameState();
    updateGameState(["team"=>max(0,(int)$game['team']+1)]);
    logEvent("Hiring", "$name joined the studio as $role.", "success");
    return ["ok"=>true, "message"=>"Employee hired successfully."];
}

function fireEmployee($id)
{
    global $conn;
    $employee = getEmployee((int)$id);
    if (!$employee) return ["ok"=>false, "error"=>"Employee not found in your studio."];
    $ownerId = employeeOwnerId();
    $stmt = $conn->prepare("UPDATE employees SET status='fired' WHERE id=? AND business_owner_id=?");
    $id=(int)$id; $stmt->bind_param("ii",$id,$ownerId); $stmt->execute(); $stmt->close();
    $game=getGameState();
    updateGameState(["team"=>max(0,(int)$game['team']-1)]);
    logEvent("Termination", $employee['name']." left the studio.", "warning");
    return ["ok"=>true];
}

function promoteEmployee($id)
{
    global $conn;
    $employee=getEmployee((int)$id);
    if(!$employee) return false;
    $ownerId=employeeOwnerId(); $id=(int)$id; $salary=(int)$employee['salary']+1000;
    $stmt=$conn->prepare("UPDATE employees SET salary=?, morale=LEAST(100,morale+10), efficiency=LEAST(100,efficiency+8) WHERE id=? AND business_owner_id=?");
    $stmt->bind_param("iii",$salary,$id,$ownerId); $ok=$stmt->execute(); $stmt->close();
    if($ok) logEvent("Promotion",$employee['name']." received a promotion.","success");
    return $ok;
}

function calculatePayroll()
{
    global $conn;
    if (!columnExists('employees','business_owner_id')) return 0;
    $ownerId=employeeOwnerId(); if($ownerId<1)return 0;
    $stmt=$conn->prepare("SELECT COALESCE(SUM(salary),0) total FROM employees WHERE status='active' AND business_owner_id=?");
    $stmt->bind_param("i",$ownerId);$stmt->execute();$row=$stmt->get_result()->fetch_assoc();$stmt->close();
    return (int)($row['total']??0);
}

function averageMorale()
{
    global $conn;
    if (!columnExists('employees','business_owner_id')) return 0;
    $ownerId=employeeOwnerId(); if($ownerId<1)return 0;
    $stmt=$conn->prepare("SELECT COALESCE(AVG(morale),0) avgMorale FROM employees WHERE status='active' AND business_owner_id=?");
    $stmt->bind_param("i",$ownerId);$stmt->execute();$row=$stmt->get_result()->fetch_assoc();$stmt->close();
    return (int)round((float)($row['avgMorale']??0));
}

function averageEfficiency()
{
    global $conn;
    if (!columnExists('employees','business_owner_id')) return 0;
    $ownerId=employeeOwnerId(); if($ownerId<1)return 0;
    $stmt=$conn->prepare("SELECT COALESCE(AVG(efficiency),0) avgEfficiency FROM employees WHERE status='active' AND business_owner_id=?");
    $stmt->bind_param("i",$ownerId);$stmt->execute();$row=$stmt->get_result()->fetch_assoc();$stmt->close();
    return (int)round((float)($row['avgEfficiency']??0));
}

function topPerformer()
{
    global $conn;
    if (!columnExists('employees','business_owner_id')) return null;
    $ownerId=employeeOwnerId(); if($ownerId<1)return null;
    $stmt=$conn->prepare("SELECT * FROM employees WHERE status='active' AND business_owner_id=? ORDER BY efficiency DESC LIMIT 1");
    $stmt->bind_param("i",$ownerId);$stmt->execute();$row=$stmt->get_result()->fetch_assoc();$stmt->close();
    return $row;
}

function lowMoraleEmployees()
{
    global $conn;
    if (!columnExists('employees','business_owner_id')) return [];
    $ownerId=employeeOwnerId(); if($ownerId<1)return [];
    $stmt=$conn->prepare("SELECT * FROM employees WHERE morale<60 AND status='active' AND business_owner_id=? ORDER BY morale ASC");
    $stmt->bind_param("i",$ownerId);$stmt->execute();$rows=$stmt->get_result()->fetch_all(MYSQLI_ASSOC);$stmt->close();
    return $rows;
}

function teamStatistics()
{
    return [
        "employees"=>count(getEmployees()),
        "payroll"=>calculatePayroll(),
        "morale"=>averageMorale(),
        "efficiency"=>averageEfficiency(),
        "top"=>topPerformer()
    ];
}

function candidatePool($ownerId = null)
{
    global $conn;
    $ownerId = (int)($ownerId ?? (function_exists('currentBusinessOwnerId') ? (currentBusinessOwnerId() ?? 0) : 0));
    if ($ownerId < 1 || !tableExists('business_employment') || !tableExists('users')) return [];

    // Older installations may not yet have the employment workflow tables/columns.
    // Fail closed (show no applicants) instead of breaking Team Management.
    $required = [
        'business_employment' => ['id', 'owner_id', 'worker_id', 'employment_role', 'status', 'created_at'],
        'users' => ['id', 'username'],
    ];
    foreach ($required as $table => $columns) {
        foreach ($columns as $column) {
            $safeTable = str_replace('`', '', $table);
            $safeColumn = $conn->real_escape_string($column);
            $check = $conn->query("SHOW COLUMNS FROM `{$safeTable}` LIKE '{$safeColumn}'");
            if (!$check || $check->num_rows === 0) return [];
        }
    }

    $sql = "SELECT be.id AS application_id, u.id AS worker_id, u.username AS name,
                   be.employment_role AS role, be.created_at AS applied_at
            FROM business_employment be
            INNER JOIN users u ON u.id = be.worker_id
            WHERE be.owner_id = ? AND be.status = 'pending'
            ORDER BY be.created_at DESC";
    $stmt = $conn->prepare($sql);
    if (!$stmt) return [];
    $stmt->bind_param('i', $ownerId);
    if (!$stmt->execute()) {
        $stmt->close();
        return [];
    }
    $result = $stmt->get_result();
    $rows = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
    $stmt->close();
    return $rows;
}

/* ==========================================================
   TEAM EVENTS
========================================================== */

function triggerRandomEvent()
{

    $events=[

        [

            "title"=>"Hackathon Winner",

            "effect_summary"=>"Efficiency increased by 8%",

            "tone"=>"success"

        ],

        [

            "title"=>"Developer Burnout",

            "effect_summary"=>"Morale decreased by 12%",

            "tone"=>"warning"

        ],

        [

            "title"=>"Server Outage",

            "effect_summary"=>"Project delayed",

            "tone"=>"danger"

        ],

        [

            "title"=>"Major Client Signed",

            "effect_summary"=>"Company cash increased",

            "tone"=>"success"

        ]

    ];

    $event=$events[array_rand($events)];

    switch($event['title'])
    {

        case "Hackathon Winner":

            changeEfficiency(8);

            break;

        case "Developer Burnout":

            changeMorale(-12);

            break;

        case "Server Outage":

            break;

        case "Major Client Signed":

            addCash(15000);

            break;

    }

    logEvent(

        $event['title'],

        $event['effect_summary'],

        $event['tone']

    );

    return $event;
}

/* ==========================================================
   PART 3A
   EVENTS & ACHIEVEMENTS
========================================================== */

/* ==========================================================
   EVENT LOGGING
========================================================== */

function logEvent($title, $description, $tone = "info")
{
    global $conn;

    $stmt = $conn->prepare("
        INSERT INTO events
        (
            title,
            description,
            tone
        )
        VALUES
        (
            ?,?,?
        )
    ");

    $stmt->bind_param(
        "sss",
        $title,
        $description,
        $tone
    );

    return $stmt->execute();
}

function getRecentEvents($limit = 8)
{
    global $conn;

    $limit = intval($limit);

    $result = $conn->query("
        SELECT *
        FROM events
        ORDER BY id DESC
        LIMIT $limit
    ");

    if(!$result){
        return [];
    }

    return $result->fetch_all(MYSQLI_ASSOC);
}

function clearEvents()
{
    global $conn;

    $conn->query("TRUNCATE TABLE events");
}

/* ==========================================================
   ACHIEVEMENTS
========================================================== */

function unlockAchievement($title)
{
    global $conn;

    $stmt = $conn->prepare("
        SELECT id
        FROM achievements
        WHERE title=?
        LIMIT 1
    ");

    $stmt->bind_param("s",$title);
    $stmt->execute();

    if($stmt->get_result()->num_rows>0){
        return false;
    }

    $stmt = $conn->prepare("
        INSERT INTO achievements
        (
            title,
            unlocked_at
        )
        VALUES
        (
            ?,
            NOW()
        )
    ");

    $stmt->bind_param("s",$title);
    $stmt->execute();

    addAchievement();

    return true;
}

function getAchievements()
{
    global $conn;

    $result=$conn->query("
        SELECT *
        FROM achievements
        ORDER BY unlocked_at DESC
    ");

    if(!$result){
        return [];
    }

    return $result->fetch_all(MYSQLI_ASSOC);
}

function checkAchievements()
{
    $new=[];

    $game=getGameState();

    if($game['cash']>=100000){

        if(unlockAchievement("Company Millionaire")){

            $new[]="Company Millionaire";

            logEvent(
                "Achievement Unlocked",
                "Company Millionaire",
                "success"
            );

        }

    }

    if($game['team']>=10){

        if(unlockAchievement("Growing Company")){

            $new[]="Growing Company";

            logEvent(
                "Achievement Unlocked",
                "Growing Company",
                "success"
            );

        }

    }

    if($game['efficiency']>=90){

        if(unlockAchievement("High Performance")){

            $new[]="High Performance";

            logEvent(
                "Achievement Unlocked",
                "High Performance",
                "success"
            );

        }

    }

    if($game['morale']>=95){

        if(unlockAchievement("Happy Workplace")){

            $new[]="Happy Workplace";

            logEvent(
                "Achievement Unlocked",
                "Happy Workplace",
                "success"
            );

        }

    }

    return $new;
}

/* ==========================================================
   COMPANY NOTIFICATIONS
========================================================== */

function companyNotifications()
{
    $game=getGameState();

    $notifications=[];

    if($game['cash']<10000){

        $notifications[]=[
            "type"=>"danger",
            "message"=>"Company funds are running low."
        ];

    }

    if($game['morale']<50){

        $notifications[]=[
            "type"=>"warning",
            "message"=>"Employee morale is critically low."
        ];

    }

    if($game['efficiency']<50){

        $notifications[]=[
            "type"=>"warning",
            "message"=>"Overall productivity has decreased."
        ];

    }

    if($game['team']<3){

        $notifications[]=[
            "type"=>"danger",
            "message"=>"You need to hire more employees."
        ];

    }

    if(empty($notifications)){

        $notifications[]=[
            "type"=>"success",
            "message"=>"Company operations are stable."
        ];

    }

    return $notifications;
}
function deleteAchievement($id)
{
    global $conn;

    $stmt = $conn->prepare("
        DELETE FROM achievements
        WHERE id=?
    ");

    $stmt->bind_param("i",$id);

    return $stmt->execute();
}

function resetAchievements()
{
    global $conn;

    $conn->query("TRUNCATE TABLE achievements");

    $conn->query("
        UPDATE game_state
        SET achievement=0
        WHERE id=1
    ");

    return true;
}
/*=========================================================
PROJECT MANAGEMENT
=========================================================*/

/*
    Get all projects
*/
function projectBusinessOwnerId()
{
    global $conn;
    if (empty($_SESSION['user_id'])) return 0;
    $userId = (int) $_SESSION['user_id'];
    $stmt = $conn->prepare("SELECT role FROM users WHERE id=? LIMIT 1");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    if (!$user) return 0;
    if ($user['role'] === 'owner') return $userId;
    // Older installations may not have imported the hiring migration yet.
    // Treat the worker as unassigned instead of allowing a missing-table SQL error.
    if (!tableExists('business_employment')) return 0;
    $stmt = $conn->prepare("SELECT owner_id FROM business_employment WHERE worker_id=? AND status='hired' ORDER BY updated_at DESC LIMIT 1");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $employment = $stmt->get_result()->fetch_assoc();
    return $employment ? (int)$employment['owner_id'] : 0;
}

function getProjects()
{
    // Projects are private to the current owner's business. If the ownership
    // migration has not been run, fail closed instead of exposing every
    // business's projects to every signed-in account.
    global $conn;
    if (!columnExists('projects', 'business_owner_id')) return [];
    $ownerId = projectBusinessOwnerId();
    if ($ownerId < 1) return [];
    $stmt = $conn->prepare("SELECT * FROM projects WHERE business_owner_id=? ORDER BY id DESC");
    if (!$stmt) return [];
    $stmt->bind_param("i", $ownerId);
    if (!$stmt->execute()) return [];
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

function columnExists($table, $column)
{
    global $conn;
    $allowed = ['projects', 'employees'];
    if (!in_array($table, $allowed, true)) return false;
    $table = $conn->real_escape_string($table);
    $column = $conn->real_escape_string($column);
    $result = $conn->query("SHOW COLUMNS FROM `$table` LIKE '$column'");
    return $result && $result->num_rows > 0;
}

/*
    Get project by ID
*/
function getProject($id)
{
    // Enforce business boundaries on every project lookup, including file
    // downloads and submissions. Never fall back to a global project lookup.
    global $conn;
    $id = (int)$id;
    if ($id < 1 || !columnExists('projects', 'business_owner_id')) return null;
    $ownerId = projectBusinessOwnerId();
    if ($ownerId < 1) return null;
    $stmt = $conn->prepare("SELECT * FROM projects WHERE id=? AND business_owner_id=? LIMIT 1");
    if (!$stmt) return null;
    $stmt->bind_param("ii", $id, $ownerId);
    if (!$stmt->execute()) return null;
    return $stmt->get_result()->fetch_assoc() ?: null;
}

/*
    Create new project
*/
function createProject(
    $title,
    $description,
    $budget,
    $deadline,
    $priority,
    $requiredDeliverables = '',
    $deadlineAt = ''
)
{
    global $conn;

    if (!columnExists('projects', 'required_deliverables')) {
        $conn->query("ALTER TABLE projects ADD COLUMN required_deliverables TEXT NULL");
    }
    if (!columnExists('projects', 'deadline_started_at')) {
        $conn->query("ALTER TABLE projects ADD COLUMN deadline_started_at DATETIME NULL DEFAULT NULL");
    }
    if (!columnExists('projects', 'deadline_at')) {
        $conn->query("ALTER TABLE projects ADD COLUMN deadline_at DATETIME NULL DEFAULT NULL");
    }

    $ownerId = projectBusinessOwnerId();
    if ($ownerId < 1 || !columnExists('projects', 'business_owner_id')) {
        return ["ok" => false, "error" => "Your account must belong to a business before creating projects. Run project_business_migration.sql first."];
    }
    // Project budgets are user-defined simulation values and are not capped by
    // the studio's current cash balance. Only positive budgets are accepted.
    if ((float)$budget <= 0) {
        return ["ok" => false, "error" => "Project budget must be greater than ₱0."];
    }
    $deadlineAt = trim((string)$deadlineAt);
    $deadlineTimestamp = strtotime($deadlineAt);
    if (!$deadlineTimestamp || $deadlineTimestamp <= time()) {
        return ["ok" => false, "error" => "Choose a future deadline date and time."];
    }
    $deadlineAt = date('Y-m-d H:i:s', $deadlineTimestamp);
    $deadline = max(1, (int)ceil(($deadlineTimestamp - time()) / 86400));

    $stmt = $conn->prepare("
        INSERT INTO projects
        (
            title,
            description,
            budget,
            deadline,
            priority,
            progress,
            risk,
            status,
            business_owner_id,
            required_deliverables,
            deadline_started_at,
            deadline_at
        )
        VALUES
        (
            ?,?,?,?, ?,0,'Low','In Progress',?,?,NOW(),?
        )
    ");

    $stmt->bind_param(
        "ssiisiss",
        $title,
        $description,
        $budget,
        $deadline,
        $priority,
        $ownerId,
        $requiredDeliverables,
        $deadlineAt
    );

    if (!$stmt->execute()) {
        return [
            "ok" => false,
            "error" => $conn->error
        ];
    }

    subtractCash($budget);

    $game = getGameState();
    updateGameState([
        "budget_spent" => (int)($game['budget_spent'] ?? 0) + $budget
    ]);

    logEvent(
        "New Project",
        "\"$title\" launched with a budget of ₱" . number_format($budget) . ".",
        "success"
    );

    return [
        "ok" => true
    ];
}

/* Owner-only project budget update. Extra budget is funded from studio cash. */
function updateProjectBudget($id, $newBudget)
{
    global $conn;
    $user = currentUser();
    $ownerId = projectBusinessOwnerId();
    $newBudget = (int)$newBudget;
    if (!$user || ($user['role'] ?? '') !== 'owner') return ["ok" => false, "error" => "Only the business owner can edit project budgets."];
    if ($newBudget < 1) return ["ok" => false, "error" => "Budget must be at least ₱1."];
    $project = getProject((int)$id);
    if (!$project || (int)$project['business_owner_id'] !== $ownerId) return ["ok" => false, "error" => "Project not found in your business."];
    $difference = $newBudget - (int)$project['budget'];
    $game = getGameState();
    if ($difference > 0 && (int)$game['cash'] < $difference) return ["ok" => false, "error" => "Your studio does not have enough cash for this budget increase."];
    $stmt = $conn->prepare("UPDATE projects SET budget=? WHERE id=? AND business_owner_id=?");
    $stmt->bind_param("iii", $newBudget, $id, $ownerId);
    if (!$stmt->execute() || $stmt->affected_rows < 0) return ["ok" => false, "error" => "Could not update the project budget."];
    if ($difference > 0) subtractCash($difference);
    elseif ($difference < 0) addCash(abs($difference));
    logEvent("Project Budget Updated", "Budget for \"{$project['title']}\" changed to ₱" . number_format($newBudget) . ".", "success");
    return ["ok" => true, "message" => "Project budget updated."];
}

/*
    Update editable project details
*/
function updateProjectDetails($id, $priority, $deadline)
{
    global $conn;

    $ownerId = projectBusinessOwnerId();
    if ($ownerId < 1) return false;
    $stmt = $conn->prepare("UPDATE projects SET priority=?, deadline=? WHERE id=? AND business_owner_id=?");
    $stmt->bind_param("siii", $priority, $deadline, $id, $ownerId);

    return $stmt->execute();
}

/*
    Assign the current team to a project.
    There is no project/employee relation table, so this
    simulates the effect a team assignment has on a project:
    risk level reflects team efficiency, and progress gets a
    small boost proportional to how strong the team is.
*/
function assignTeamToProject($id)
{
    global $conn;

    $project = getProject($id);

    if (!$project) {
        return [
            "ok" => false,
            "error" => "Project not found."
        ];
    }

    $team = teamStatistics();

    if ($team['employees'] == 0) {
        return [
            "ok" => false,
            "error" => "You have no active employees to assign."
        ];
    }

    if ($team['efficiency'] >= 80) {
        $risk = "Low";
    } elseif ($team['efficiency'] >= 60) {
        $risk = "Medium";
    } else {
        $risk = "High";
    }

    $progressBoost = max(1, round($team['efficiency'] / 20));

    $newProgress = min(100, $project['progress'] + $progressBoost);

    $status = ($newProgress >= 100) ? "Completed" : "In Progress";

    $stmt = $conn->prepare("
        UPDATE projects
        SET
            risk=?,
            progress=?,
            status=?
        WHERE id=?
    ");

    $stmt->bind_param(
        "sisi",
        $risk,
        $newProgress,
        $status,
        $id
    );

    $stmt->execute();

    logEvent(
        "Team Assigned",
        "Team assigned to \"{$project['title']}\" &mdash; risk level set to $risk.",
        "success"
    );

    checkContractCompletion($id);

    return [
        "ok" => true,
        "risk" => $risk
    ];
}

/*
    Update progress
*/
function updateProjectProgress($id,$progress)
{
    global $conn;

    if($progress >= 100){

        $progress = 100;
        $status = "Completed";

    }else{

        $status = "In Progress";

    }

    $ownerId = projectBusinessOwnerId();
    if ($ownerId < 1) return false;
    $stmt = $conn->prepare("UPDATE projects SET progress=?, status=? WHERE id=? AND business_owner_id=?");
    $stmt->bind_param("isii", $progress, $status, $id, $ownerId);

    return $stmt->execute();
}

/*
    Delete project
*/
function deleteProject($id)
{
    global $conn;

    $ownerId = projectBusinessOwnerId();
    if ($ownerId < 1) return false;
    $stmt = $conn->prepare("DELETE FROM projects WHERE id=? AND business_owner_id=?");
    $stmt->bind_param("ii", $id, $ownerId);

    return $stmt->execute();
}

/* ==========================================================
   PART 4 — MILESTONES
========================================================== */

function getMilestones($projectId)
{
    global $conn;

    $projectId = intval($projectId);

    $stmt = $conn->prepare("
        SELECT *
        FROM project_milestones
        WHERE project_id=?
        ORDER BY id ASC
    ");

    $stmt->bind_param("i", $projectId);
    $stmt->execute();

    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

function addMilestone($projectId, $title)
{
    global $conn;

    $stmt = $conn->prepare("
        INSERT INTO project_milestones (project_id, title)
        VALUES (?, ?)
    ");

    $stmt->bind_param("is", $projectId, $title);

    return $stmt->execute();
}

function toggleMilestone($id)
{
    global $conn;

    $id = intval($id);

    $stmt = $conn->prepare("
        UPDATE project_milestones
        SET
            is_done = NOT is_done,
            completed_at = IF(is_done = 0, NOW(), NULL)
        WHERE id=?
    ");

    $stmt->bind_param("i", $id);

    return $stmt->execute();
}

function deleteMilestone($id)
{
    global $conn;

    $id = intval($id);

    $stmt = $conn->prepare("
        DELETE FROM project_milestones
        WHERE id=?
    ");

    $stmt->bind_param("i", $id);

    return $stmt->execute();
}

function milestoneProgress($projectId)
{
    $milestones = getMilestones($projectId);

    $total = count($milestones);

    if ($total == 0) {
        return null;
    }

    $done = 0;

    foreach ($milestones as $m) {
        if ($m['is_done']) {
            $done++;
        }
    }

    return round(($done / $total) * 100);
}

/* ==========================================================
   PART 4 — PER-PROJECT TEAM ASSIGNMENT
========================================================== */

function getProjectTeamMembers($projectId)
{
    global $conn;

    $projectId = intval($projectId);

    if (!getProject($projectId) || !columnExists('employees', 'business_owner_id')) return [];
    $ownerId = employeeOwnerId();
    if ($ownerId < 1) return [];
    $stmt = $conn->prepare("
        SELECT e.*
        FROM project_team pt
        JOIN employees e ON e.id = pt.employee_id
        WHERE pt.project_id=? AND e.business_owner_id=?
        ORDER BY e.efficiency DESC
    ");

    $stmt->bind_param("ii", $projectId, $ownerId);
    $stmt->execute();

    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

function getUnassignedActiveEmployees($projectId)
{
    global $conn;

    $projectId = intval($projectId);

    if (!columnExists('employees', 'business_owner_id')) return [];
    $ownerId = employeeOwnerId();
    if ($ownerId < 1 || !getProject($projectId)) return [];
    $stmt = $conn->prepare("
        SELECT e.*
        FROM employees e
        WHERE e.status='active' AND e.business_owner_id=?
        AND e.id NOT IN (
            SELECT employee_id FROM project_team WHERE project_id=?
        )
        ORDER BY e.efficiency DESC
    ");

    $stmt->bind_param("ii", $ownerId, $projectId);
    $stmt->execute();

    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

function addEmployeeToProject($projectId, $employeeId)
{
    global $conn;

    $projectId = intval($projectId);
    $employeeId = intval($employeeId);
    if (!getProject($projectId) || !getEmployee($employeeId)) return false;

    $stmt = $conn->prepare("
        INSERT IGNORE INTO project_team (project_id, employee_id)
        VALUES (?, ?)
    ");

    $stmt->bind_param("ii", $projectId, $employeeId);

    return $stmt->execute();
}

function removeEmployeeFromProject($projectId, $employeeId)
{
    global $conn;

    $projectId = intval($projectId);
    $employeeId = intval($employeeId);
    if (!getProject($projectId) || !getEmployee($employeeId)) return false;

    $stmt = $conn->prepare("
        DELETE FROM project_team
        WHERE project_id=? AND employee_id=?
    ");

    $stmt->bind_param("ii", $projectId, $employeeId);

    return $stmt->execute();
}

/* ==========================================================
   PART 4 — CLIENT CONTRACTS
========================================================== */

function contractOfferPool()
{
    return [
        ["client_name" => "Nova Retail Co.", "title" => "Inventory Dashboard", "difficulty" => "Easy", "reward_cash" => 8000, "required_deadline" => 10],
        ["client_name" => "Bayview Logistics", "title" => "Fleet Tracking App", "difficulty" => "Standard", "reward_cash" => 15000, "required_deadline" => 18],
        ["client_name" => "Solace Health", "title" => "Patient Portal Revamp", "difficulty" => "Hard", "reward_cash" => 26000, "required_deadline" => 25],
        ["client_name" => "Ferro Bank", "title" => "Fraud Detection Module", "difficulty" => "Elite", "reward_cash" => 42000, "required_deadline" => 35],
        ["client_name" => "Lumen Media", "title" => "Streaming Analytics Tool", "difficulty" => "Standard", "reward_cash" => 16000, "required_deadline" => 20],
        ["client_name" => "GreenPath Energy", "title" => "Smart Grid Monitor", "difficulty" => "Hard", "reward_cash" => 24000, "required_deadline" => 28],
        ["client_name" => "Northline Freight", "title" => "Route Optimizer", "difficulty" => "Easy", "reward_cash" => 9000, "required_deadline" => 12],
    ];
}

function getContracts($status = null)
{
    global $conn;

    if ($status) {
        $stmt = $conn->prepare("
            SELECT *
            FROM contracts
            WHERE status=?
            ORDER BY id DESC
        ");
        $stmt->bind_param("s", $status);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    return fetchAll("SELECT * FROM contracts ORDER BY id DESC");
}

function refreshContractOffers($target = 3)
{
    global $conn;

    $current = count(getContracts('offered'));

    if ($current >= $target) {
        return;
    }

    $pool = contractOfferPool();

    $needed = $target - $current;

    $picks = array_rand($pool, min($needed, count($pool)));

    if (!is_array($picks)) {
        $picks = [$picks];
    }

    foreach ($picks as $i) {

        $offer = $pool[$i];

        $stmt = $conn->prepare("
            INSERT INTO contracts
            (client_name, title, description, reward_cash, required_deadline, difficulty)
            VALUES (?, ?, ?, ?, ?, ?)
        ");

        $description = "A {$offer['difficulty']} engagement for {$offer['client_name']}.";

        $stmt->bind_param(
            "sssiis",
            $offer['client_name'],
            $offer['title'],
            $description,
            $offer['reward_cash'],
            $offer['required_deadline'],
            $offer['difficulty']
        );

        $stmt->execute();
    }
}

function acceptContract($id)
{
    global $conn;

    $id = intval($id);

    $stmt = $conn->prepare("SELECT * FROM contracts WHERE id=? AND status='offered' LIMIT 1");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $contract = $stmt->get_result()->fetch_assoc();

    if (!$contract) {
        return ["ok" => false, "error" => "Contract is no longer available."];
    }

    // Contract projects belong only to the current business.
    $ownerId = projectBusinessOwnerId();
    if ($ownerId < 1 || !columnExists('projects', 'business_owner_id')) {
        return ["ok" => false, "error" => "Run project_business_migration.sql and sign in with a business account first."];
    }
    $budget = max(1000, intval($contract['reward_cash'] * 0.2));

    $stmt = $conn->prepare("
        INSERT INTO projects
        (title, description, budget, deadline, priority, progress, sprint, risk, status, business_owner_id)
        VALUES (?, ?, ?, ?, 'High', 0, 1, 'Low', 'In Progress', ?)
    ");

    $title = $contract['client_name'] . " — " . $contract['title'];

    $stmt->bind_param("ssiii", $title, $contract['description'], $budget, $contract['required_deadline'], $ownerId);
    $stmt->execute();

    $projectId = $conn->insert_id;

    $stmt = $conn->prepare("
        UPDATE contracts
        SET status='accepted', project_id=?
        WHERE id=?
    ");
    $stmt->bind_param("ii", $projectId, $id);
    $stmt->execute();

    logEvent(
        "Contract Accepted",
        "\"{$contract['title']}\" for {$contract['client_name']} is now an active project.",
        "success"
    );

    return ["ok" => true, "project_id" => $projectId];
}

function declineContract($id)
{
    global $conn;

    $id = intval($id);

    $stmt = $conn->prepare("
        UPDATE contracts
        SET status='declined', resolved_at=NOW()
        WHERE id=? AND status='offered'
    ");
    $stmt->bind_param("i", $id);

    return $stmt->execute();
}

/*
    Called whenever a project's progress changes. If that project
    is linked to an accepted contract and just hit 100%, pay out
    the reward and close the contract.
*/
function checkContractCompletion($projectId)
{
    global $conn;

    $projectId = intval($projectId);

    $project = getProject($projectId);

    if (!$project || $project['status'] !== 'Completed') {
        return;
    }

    $stmt = $conn->prepare("
        SELECT * FROM contracts
        WHERE project_id=? AND status='accepted'
        LIMIT 1
    ");
    $stmt->bind_param("i", $projectId);
    $stmt->execute();
    $contract = $stmt->get_result()->fetch_assoc();

    if (!$contract) {
        return;
    }

    addCash($contract['reward_cash']);

    $stmt = $conn->prepare("
        UPDATE contracts
        SET status='completed', resolved_at=NOW()
        WHERE id=?
    ");
    $stmt->bind_param("i", $contract['id']);
    $stmt->execute();

    logEvent(
        "Contract Delivered",
        "{$contract['client_name']} paid out $" . number_format($contract['reward_cash']) . " for \"{$contract['title']}\".",
        "success"
    );
}

/* ==========================================================
   PART 4 — SKILLS, TRAINING & EMPLOYEE LEVELING
========================================================== */

function defaultSkillList()
{
    return [
        ["name" => "Backend Engineering", "description" => "Server logic, APIs, and databases."],
        ["name" => "Frontend Engineering", "description" => "UI implementation and client-side logic."],
        ["name" => "UI/UX Design", "description" => "Interface design and user research."],
        ["name" => "QA & Testing", "description" => "Test coverage and bug hunting."],
        ["name" => "DevOps", "description" => "Deployment, infra, and reliability."],
        ["name" => "Project Leadership", "description" => "Planning and coordinating a team."],
    ];
}

function seedSkills()
{
    global $conn;

    $existing = fetchOne("SELECT COUNT(*) c FROM skills");

    // empty() here also covers "table doesn't exist yet" (migration not run)
    if (empty($existing) || intval($existing['c']) > 0) {
        return;
    }

    foreach (defaultSkillList() as $skill) {
        $stmt = $conn->prepare("INSERT INTO skills (name, description) VALUES (?, ?)");
        $stmt->bind_param("ss", $skill['name'], $skill['description']);
        $stmt->execute();
    }
}

function getSkills()
{
    return fetchAll("SELECT * FROM skills ORDER BY name ASC");
}

function getEmployeeSkills($employeeId)
{
    global $conn;

    $employeeId = intval($employeeId);
    if (!getEmployee($employeeId)) return [];

    $stmt = $conn->prepare("
        SELECT s.id, s.name, s.description, COALESCE(es.level, 0) AS level
        FROM skills s
        LEFT JOIN employee_skills es
            ON es.skill_id = s.id AND es.employee_id = ?
        ORDER BY s.name ASC
    ");

    $stmt->bind_param("i", $employeeId);
    $stmt->execute();

    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

function trainingCost($currentLevel)
{
    return 800 * ($currentLevel + 1);
}

function trainEmployee($employeeId, $skillId)
{
    global $conn;

    $employeeId = intval($employeeId);
    $skillId = intval($skillId);

    $employee = getEmployee($employeeId);

    if (!$employee) {
        return ["ok" => false, "error" => "Employee not found."];
    }

    $stmt = $conn->prepare("
        SELECT level FROM employee_skills
        WHERE employee_id=? AND skill_id=?
    ");
    $stmt->bind_param("ii", $employeeId, $skillId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();

    $currentLevel = $row ? intval($row['level']) : 0;

    if ($currentLevel >= 5) {
        return ["ok" => false, "error" => "This skill is already at max level."];
    }

    $cost = trainingCost($currentLevel);

    $ownerId = employeeOwnerId();
    $cashStmt = $conn->prepare("SELECT business_cash FROM users WHERE id=? AND role='owner' LIMIT 1");
    $cashStmt->bind_param("i", $ownerId);
    $cashStmt->execute();
    $cashRow = $cashStmt->get_result()->fetch_assoc();
    $cashStmt->close();
    if (!$cashRow || (float)$cashRow['business_cash'] < $cost) {
        return ["ok" => false, "error" => "Not enough studio cash for this training."];
    }

    subtractCash($cost);

    $stmt = $conn->prepare("
        INSERT INTO employee_skills (employee_id, skill_id, level)
        VALUES (?, ?, 1)
        ON DUPLICATE KEY UPDATE level = level + 1
    ");
    $stmt->bind_param("ii", $employeeId, $skillId);
    $stmt->execute();

    $stmt = $conn->prepare("
        UPDATE employees
        SET efficiency = LEAST(100, efficiency + 3)
        WHERE id=?
    ");
    $stmt->bind_param("i", $employeeId);
    $stmt->execute();

    addEmployeeXp($employeeId, 40);

    logEvent(
        "Training Completed",
        "{$employee['name']} leveled up a skill.",
        "success"
    );

    return ["ok" => true, "cost" => $cost];
}

function xpForLevel($level)
{
    return $level * 150;
}

function addEmployeeXp($employeeId, $xp)
{
    global $conn;

    $employeeId = intval($employeeId);

    $employee = getEmployee($employeeId);

    if (!$employee) {
        return;
    }

    $newXp = intval($employee['xp']) + intval($xp);
    $level = intval($employee['level']);

    $leveledUp = false;

    while ($newXp >= xpForLevel($level)) {
        $newXp -= xpForLevel($level);
        $level++;
        $leveledUp = true;
    }

    $stmt = $conn->prepare("
        UPDATE employees
        SET xp=?, level=?
        WHERE id=?
    ");
    $stmt->bind_param("iii", $newXp, $level, $employeeId);
    $stmt->execute();

    if ($leveledUp) {

        $stmt = $conn->prepare("
            UPDATE employees
            SET morale = LEAST(100, morale + 5),
                salary = salary + 250
            WHERE id=?
        ");
        $stmt->bind_param("i", $employeeId);
        $stmt->execute();

        logEvent(
            "Level Up",
            "{$employee['name']} reached level $level.",
            "success"
        );
    }
}

function employeeLevelProgress($employee)
{
    $need = xpForLevel(intval($employee['level']));

    return [
        "xp" => intval($employee['xp']),
        "needed" => $need,
        "percent" => $need > 0 ? min(100, round((intval($employee['xp']) / $need) * 100)) : 0
    ];
}

/* ==========================================================
   PART 4 — FINANCE: LOANS
========================================================== */

function getLoans($status = null)
{
    if ($status) {
        global $conn;
        $stmt = $conn->prepare("SELECT * FROM loans WHERE status=? ORDER BY id DESC");
        $stmt->bind_param("s", $status);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    return fetchAll("SELECT * FROM loans ORDER BY id DESC");
}

function totalDebt()
{
    $row = fetchOne("SELECT COALESCE(SUM(balance),0) total FROM loans WHERE status='active'");
    return intval($row['total']);
}

function takeLoan($amount)
{
    global $conn;

    $amount = intval($amount);

    if ($amount <= 0) {
        return ["ok" => false, "error" => "Enter a loan amount."];
    }

    if (totalDebt() + $amount > 200000) {
        return ["ok" => false, "error" => "Lenders won't extend the studio's debt beyond ₱200,000."];
    }

    $rate = 12.00;
    $balance = intval(round($amount * (1 + $rate / 100)));

    $stmt = $conn->prepare("
        INSERT INTO loans (principal, balance, interest_rate)
        VALUES (?, ?, ?)
    ");
    $stmt->bind_param("iid", $amount, $balance, $rate);
    $stmt->execute();

    addCash($amount);

    logEvent(
        "Loan Issued",
        "Borrowed $" . number_format($amount) . " at {$rate}% interest.",
        "warning"
    );

    return ["ok" => true];
}

function payLoan($id, $amount)
{
    global $conn;

    $id = intval($id);
    $amount = intval($amount);

    $stmt = $conn->prepare("SELECT * FROM loans WHERE id=? AND status='active' LIMIT 1");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $loan = $stmt->get_result()->fetch_assoc();

    if (!$loan) {
        return ["ok" => false, "error" => "Loan not found."];
    }

    $game = getGameState();

    if ($amount <= 0 || $game['cash'] < $amount) {
        return ["ok" => false, "error" => "Not enough cash to make that payment."];
    }

    $newBalance = max(0, $loan['balance'] - $amount);

    subtractCash($amount);

    if ($newBalance == 0) {
        $stmt = $conn->prepare("UPDATE loans SET balance=0, status='paid', paid_at=NOW() WHERE id=?");
        $stmt->bind_param("i", $id);
        $stmt->execute();

        logEvent("Loan Paid Off", "The studio is debt-free on this loan.", "success");
    } else {
        $stmt = $conn->prepare("UPDATE loans SET balance=? WHERE id=?");
        $stmt->bind_param("ii", $newBalance, $id);
        $stmt->execute();
    }

    return ["ok" => true];
}

/* ==========================================================
   PART 4 — FINANCE: INVESTORS
========================================================== */

function getInvestors()
{
    return fetchAll("SELECT * FROM investors ORDER BY id DESC");
}

function totalEquityGiven()
{
    $game = getGameState();
    return floatval($game['equity_given'] ?? 0);
}

function seekInvestment($name, $amount, $equityPercent)
{
    global $conn;

    $amount = intval($amount);
    $equityPercent = floatval($equityPercent);

    if ($amount <= 0 || $equityPercent <= 0) {
        return ["ok" => false, "error" => "Enter a valid investment amount and equity split."];
    }

    if (totalEquityGiven() + $equityPercent > 49) {
        return ["ok" => false, "error" => "You can't give away more than 49% equity total."];
    }

    $stmt = $conn->prepare("
        INSERT INTO investors (name, investment_amount, equity_percent)
        VALUES (?, ?, ?)
    ");
    $stmt->bind_param("sid", $name, $amount, $equityPercent);
    $stmt->execute();

    addCash($amount);

    $game = getGameState();
    $newEquity = totalEquityGiven() + $equityPercent;

    $stmt = $conn->prepare("UPDATE game_state SET equity_given=? WHERE id=1");
    $stmt->bind_param("d", $newEquity);
    $stmt->execute();

    logEvent(
        "Investment Secured",
        "$name invested $" . number_format($amount) . " for {$equityPercent}% equity.",
        "success"
    );

    return ["ok" => true];
}

/* ==========================================================
   PART 4 — FINANCE: UPGRADES (marketing / office / tools)
========================================================== */

function defaultUpgradeList()
{
    return [
        ["name" => "Local Ad Campaign", "description" => "Modest marketing push in local channels.", "category" => "marketing", "cost" => 4000, "effect_morale" => 0, "effect_efficiency" => 0, "effect_cash_bonus" => 6000],
        ["name" => "Brand Sponsorship", "description" => "Sponsor a dev conference for visibility.", "category" => "marketing", "cost" => 12000, "effect_morale" => 0, "effect_efficiency" => 0, "effect_cash_bonus" => 20000],
        ["name" => "Ergonomic Workstations", "description" => "New desks and chairs for the team.", "category" => "office", "cost" => 6000, "effect_morale" => 10, "effect_efficiency" => 3, "effect_cash_bonus" => 0],
        ["name" => "Office Relocation", "description" => "Move into a bigger, nicer space.", "category" => "office", "cost" => 20000, "effect_morale" => 15, "effect_efficiency" => 5, "effect_cash_bonus" => 0],
        ["name" => "CI/CD Pipeline", "description" => "Automated builds and deployments.", "category" => "tools", "cost" => 9000, "effect_morale" => 2, "effect_efficiency" => 12, "effect_cash_bonus" => 0],
        ["name" => "Premium Dev Tooling", "description" => "Licenses for better IDEs and monitoring.", "category" => "tools", "cost" => 5000, "effect_morale" => 3, "effect_efficiency" => 8, "effect_cash_bonus" => 0],
    ];
}

function seedUpgrades()
{
    global $conn;

    $existing = fetchOne("SELECT COUNT(*) c FROM upgrades");

    // empty() here also covers "table doesn't exist yet" (migration not run)
    if (empty($existing) || intval($existing['c']) > 0) {
        return;
    }

    foreach (defaultUpgradeList() as $u) {
        $stmt = $conn->prepare("
            INSERT INTO upgrades
            (name, description, category, cost, effect_morale, effect_efficiency, effect_cash_bonus)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->bind_param(
            "sssiiii",
            $u['name'], $u['description'], $u['category'], $u['cost'],
            $u['effect_morale'], $u['effect_efficiency'], $u['effect_cash_bonus']
        );
        $stmt->execute();
    }
}

function getUpgrades()
{
    return fetchAll("SELECT * FROM upgrades ORDER BY category ASC, cost ASC");
}

function getPurchasedUpgradeIds()
{
    global $conn;

    $rows = fetchAll("SELECT upgrade_id FROM purchased_upgrades");

    return array_map(function ($r) {
        return intval($r['upgrade_id']);
    }, $rows);
}

function purchaseUpgrade($id)
{
    global $conn;

    $id = intval($id);

    if (in_array($id, getPurchasedUpgradeIds())) {
        return ["ok" => false, "error" => "You already own this upgrade."];
    }

    $stmt = $conn->prepare("SELECT * FROM upgrades WHERE id=? LIMIT 1");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $upgrade = $stmt->get_result()->fetch_assoc();

    if (!$upgrade) {
        return ["ok" => false, "error" => "Upgrade not found."];
    }

    $game = getGameState();

    if ($game['cash'] < $upgrade['cost']) {
        return ["ok" => false, "error" => "Not enough studio cash for this upgrade."];
    }

    subtractCash($upgrade['cost']);

    if ($upgrade['effect_morale'] != 0) {
        changeMorale($upgrade['effect_morale']);
    }

    if ($upgrade['effect_efficiency'] != 0) {
        changeEfficiency($upgrade['effect_efficiency']);
    }

    if ($upgrade['effect_cash_bonus'] != 0) {
        addCash($upgrade['effect_cash_bonus']);
    }

    $stmt = $conn->prepare("INSERT INTO purchased_upgrades (upgrade_id) VALUES (?)");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    logEvent(
        "Upgrade Purchased",
        "{$upgrade['name']} is now active.",
        "success"
    );

    return ["ok" => true];
}


/* ==========================================================
   PART 5 — ACCOUNTS / AUTHENTICATION
========================================================== */

function registerUser($username, $email, $password, $confirmPassword, $role = 'worker', $businessName = '', $businessCash = 0, $businessLocation = '')
{
    global $conn;

    $username = trim($username);
    $email = trim($email);
    $role = in_array($role, ['owner', 'worker'], true) ? $role : 'worker';
    $businessName = trim($businessName);
    $businessLocation = trim($businessLocation);
    $businessCash = filter_var($businessCash, FILTER_VALIDATE_FLOAT);

    if ($username === '' || $email === '' || $password === '') {
        return ["ok" => false, "error" => "Fill in every required field."];
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return ["ok" => false, "error" => "Enter a valid email address."];
    }
    if (strlen($password) < 6) {
        return ["ok" => false, "error" => "Password must be at least 6 characters."];
    }
    if ($password !== $confirmPassword) {
        return ["ok" => false, "error" => "Passwords don't match."];
    }
    if ($role === 'owner' && ($businessName === '' || $businessLocation === '')) {
        return ["ok" => false, "error" => "Enter your business name and location."];
    }
    if ($role === 'owner' && strlen($businessLocation) > 255) {
        return ["ok" => false, "error" => "Business location must be 255 characters or fewer."];
    }
    if ($role === 'owner' && (strlen($businessName) > 150 || $businessCash === false || $businessCash < 0 || $businessCash > 1000000000)) {
        return ["ok" => false, "error" => "Enter a valid business name and non-negative cash amount."];
    }
    if ($role === 'worker') {
        $businessName = '';
        $businessLocation = '';
        $businessCash = 0;
    }

    $stmt = $conn->prepare("SELECT id FROM users WHERE username=? OR email=? LIMIT 1");
    $stmt->bind_param("ss", $username, $email);
    $stmt->execute();
    if ($stmt->get_result()->fetch_assoc()) {
        return ["ok" => false, "error" => "That username or email is already registered."];
    }

    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("
        INSERT INTO users (username, email, password_hash, role, business_name, business_location, business_cash)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->bind_param("ssssssd", $username, $email, $hash, $role, $businessName, $businessLocation, $businessCash);

    if (!$stmt->execute()) {
        return ["ok" => false, "error" => "Could not create the account. Check the database setup and try again."];
    }

    $newUserId = (int) $conn->insert_id;

    // Each studio reads its own starting cash from users.business_cash; do not overwrite the shared legacy game_state row.

    return ["ok" => true, "id" => $newUserId];
}

function getOwnerBusinesses()
{
    global $conn;
    $result = $conn->query("
        SELECT id, username, email, business_name, business_location, business_cash, created_at
        FROM users
        WHERE role = 'owner'
        ORDER BY created_at DESC
    ");
    if (!$result) {
        return [];
    }
    return $result->fetch_all(MYSQLI_ASSOC);
}

function attemptLogin($identifier, $password)
{
    global $conn;

    $identifier = trim($identifier);

    $stmt = $conn->prepare("
        SELECT * FROM users
        WHERE username=? OR email=?
        LIMIT 1
    ");
    $stmt->bind_param("ss", $identifier, $identifier);
    $stmt->execute();

    $user = $stmt->get_result()->fetch_assoc();

    if (!$user || !password_verify($password, $user['password_hash'])) {
        return ["ok" => false, "error" => "Incorrect username/email or password."];
    }

    $stmt = $conn->prepare("UPDATE users SET last_login_at=NOW() WHERE id=?");
    $stmt->bind_param("i", $user['id']);
    $stmt->execute();

    return ["ok" => true, "user" => $user];
}

function currentUser()
{
    global $conn;

    if (empty($_SESSION['user_id'])) {
        return null;
    }

    $stmt = $conn->prepare("
        SELECT id, username, email, role, business_name, business_location, personal_location, birthday, business_cash, created_at, last_login_at
        FROM users
        WHERE id=?
        LIMIT 1
    ");
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();

    return $stmt->get_result()->fetch_assoc();
}

/*
    Call at the top of every page that requires a logged-in
    user. Purely session-based, so it works even if the users
    table hasn't been created yet (it just won't let anyone in
    until registration/login has actually worked once).
*/
function requireLogin()
{
    if (empty($_SESSION['user_id'])) {
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'] ?? 'demo.php';
        header("Location: login.php");
        exit;
    }
}

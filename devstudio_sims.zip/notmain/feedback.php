<?php
session_start();
require_once 'db.php';
require_once 'business_helpers.php';
requireLogin();
verifyAppCsrfPost();
$me=currentUser(); $uid=(int)($me['id']??0); $role=businessRoleForUser($conn,$me); $canManage=in_array($role,['owner','manager'],true);
$ownerId=(int)(function_exists('currentBusinessOwnerId')?(currentBusinessOwnerId()??0):0);
$msg=''; $error='';
if ($_SERVER['REQUEST_METHOD']==='POST' && !$canManage) {
  if ($ownerId<1) $error='You must be hired by a studio before submitting feedback.';
  else {
    $rating=(int)($_POST['rating']??0); $comments=trim((string)($_POST['comments']??'')); $anonymous=isset($_POST['anonymous'])?1:0;
    $stmt=$conn->prepare("SELECT id FROM business_employment WHERE worker_id=? AND owner_id=? AND status='hired' LIMIT 1");
    $stmt->bind_param('ii',$uid,$ownerId);$stmt->execute();$hired=$stmt->get_result()->fetch_assoc();$stmt->close();
    if(!$hired) $error='Only currently hired team members can submit feedback.';
    elseif($rating<1||$rating>5) $error='Choose a rating from 1 to 5.';
    elseif($comments==='') $error='Please add a comment.';
    elseif(mb_strlen($comments)>3000) $error='Comments must be 3,000 characters or fewer.';
    else { $stmt=$conn->prepare('INSERT INTO worker_feedback (owner_id,worker_id,rating,comments,is_anonymous) VALUES (?,?,?,?,?)'); $stmt->bind_param('iiisi',$ownerId,$uid,$rating,$comments,$anonymous); if($stmt->execute())$msg='Feedback submitted. Management can read it but cannot edit or delete it.';else$error='Could not submit feedback. Please try again.'; $stmt->close(); }
  }
}
$rows=[];
if($ownerId>0){
 if($canManage){$stmt=$conn->prepare("SELECT f.id,f.rating,f.comments,f.is_anonymous,f.created_at,u.username FROM worker_feedback f LEFT JOIN users u ON u.id=f.worker_id WHERE f.owner_id=? ORDER BY f.created_at DESC");$stmt->bind_param('i',$ownerId);}
 else {$stmt=$conn->prepare("SELECT f.id,f.rating,f.comments,f.is_anonymous,f.created_at,u.username FROM worker_feedback f LEFT JOIN users u ON u.id=f.worker_id WHERE f.owner_id=? AND f.worker_id=? ORDER BY f.created_at DESC");$stmt->bind_param('ii',$ownerId,$uid);}
 $stmt->execute();$rows=$stmt->get_result()->fetch_all(MYSQLI_ASSOC);$stmt->close();
}
function fbEsc($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Worker Feedback | DEVSTUDIO SIMS</title><script src="https://cdn.tailwindcss.com"></script><link rel="stylesheet" href="assets/theme.css"></head><body class="bg-slate-900 text-white"><div class="ds-shell ds-unified-shell"><?php include 'partial_nav.php'; ?><main class="ds-main ds-unified-main"><div class="max-w-5xl mx-auto p-5 md:p-8"><p class="ds-eyebrow">TEAM VOICE</p><h1 class="text-3xl md:text-4xl font-bold">Worker Feedback</h1><p class="text-slate-400 mt-2 mb-6">Workers can submit ratings and comments. Submitted feedback is read-only for owners and managers.</p>
<?php if($msg):?><div class="rounded-lg border border-emerald-500/30 bg-emerald-500/10 p-3 mb-4 text-emerald-200"><?=fbEsc($msg)?></div><?php endif;?><?php if($error):?><div class="rounded-lg border border-rose-500/30 bg-rose-500/10 p-3 mb-4 text-rose-200"><?=fbEsc($error)?></div><?php endif;?>
<?php if(!$canManage):?><section class="rounded-2xl border border-slate-700 bg-slate-800/70 p-5 mb-6"><h2 class="text-xl font-bold">Submit feedback</h2><?php if($ownerId<1):?><p class="text-slate-400 mt-2">You need to join a studio before you can submit feedback.</p><?php else:?><form method="post" class="mt-4 space-y-4"><input type="hidden" name="csrf" value="<?=fbEsc(appCsrfToken())?>"><label class="block"><span class="block text-sm mb-2">Rating</span><select name="rating" required class="w-full rounded-lg bg-slate-900 border border-slate-700 p-3"><option value="">Choose 1–5</option><?php for($i=1;$i<=5;$i++):?><option value="<?=$i?>"><?=$i?> / 5<?=$i===5?' — Excellent':($i===1?' — Needs improvement':'')?></option><?php endfor;?></select></label><label class="block"><span class="block text-sm mb-2">Comments</span><textarea name="comments" required maxlength="3000" rows="4" class="w-full rounded-lg bg-slate-900 border border-slate-700 p-3" placeholder="Share your experience or suggestions..."></textarea></label><label class="flex items-center gap-2 text-sm text-slate-300"><input type="checkbox" name="anonymous" value="1"> Submit anonymously to management</label><button class="rounded-lg bg-teal-400 text-slate-950 font-bold px-4 py-3">Submit feedback</button></form><?php endif;?></section><?php else:?><section class="rounded-2xl border border-amber-500/30 bg-amber-500/10 p-4 mb-6"><strong>Read-only feedback.</strong> Owners and managers may review submitted feedback, but there are no controls to edit or delete ratings or comments.</section><?php endif;?>
<section class="rounded-2xl border border-slate-700 bg-slate-800/70 p-5"><h2 class="text-xl font-bold"><?=$canManage?'Feedback received':'My feedback history'?></h2><?php if(!$rows):?><p class="text-slate-400 mt-4">No feedback submitted yet.</p><?php else:?><div class="space-y-4 mt-4"><?php foreach($rows as $r):?><article class="rounded-xl bg-slate-900/80 border border-slate-700 p-4"><div class="flex flex-wrap items-center justify-between gap-2"><strong><?= $r['is_anonymous']?'Anonymous worker':fbEsc($r['username']??'Worker')?></strong><span class="text-amber-300 font-bold"><?= (int)$r['rating']?> / 5 ★</span></div><p class="text-slate-300 mt-3 whitespace-pre-wrap"><?=fbEsc($r['comments'])?></p><p class="text-xs text-slate-500 mt-3"><?=fbEsc(date('M j, Y · g:i A',strtotime($r['created_at'])))?></p></article><?php endforeach;?></div><?php endif;?></section></div></main></div></body></html>

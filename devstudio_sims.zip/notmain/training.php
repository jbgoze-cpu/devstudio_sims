<?php
session_start();
require_once "db.php";

requireLogin();
verifyAppCsrfPost();
$__trainingUser = currentUser();
$__trainingBusinessRole = function_exists('businessRoleForUser') ? businessRoleForUser($conn, $__trainingUser) : ($__trainingUser['role'] ?? '');
if (($__trainingUser['role'] ?? '') === 'owner' || $__trainingBusinessRole === 'owner') {
    // Owners must not access Skill Training, even through a direct URL.
    header('Location: demo.php');
    exit;
}
if (($__trainingUser['role'] ?? '') === 'worker') {
    // Add the destination column safely for databases created with the older migration.
    $urlColumn = $conn->query("SHOW COLUMNS FROM worker_training_courses LIKE 'website_url'");
    if ($urlColumn && $urlColumn->num_rows === 0) {
        $conn->query("ALTER TABLE worker_training_courses ADD COLUMN website_url VARCHAR(500) NULL AFTER duration_hours");
    }
    // Official learning pages matched to each training topic.
    $trainingLinks = [
        'Web Development Fundamentals' => 'https://developer.mozilla.org/en-US/docs/Learn',
        'PHP and Database Basics' => 'https://www.php.net/manual/en/',
        'UI/UX Design Essentials' => 'https://help.figma.com/hc/en-us/categories/360002051613-Get-started',
        'Software Quality Assurance' => 'https://www.atlassian.com/software-testing',
        'Git and Team Collaboration' => 'https://skills.github.com/',
        'Cybersecurity Awareness' => 'https://www.cisa.gov/secure-our-world'
    ];
    $linkUpdate = $conn->prepare("UPDATE worker_training_courses SET website_url=? WHERE title=? AND (website_url IS NULL OR website_url='')");
    foreach ($trainingLinks as $trainingTitle => $trainingUrl) {
        $linkUpdate->bind_param('ss', $trainingUrl, $trainingTitle);
        $linkUpdate->execute();
    }
    $linkUpdate->close();

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['course_id'])) {
        $courseId = (int)$_POST['course_id'];
        $stmt = $conn->prepare("SELECT website_url FROM worker_training_courses WHERE id=? AND is_active=1 LIMIT 1");
        $stmt->bind_param('i', $courseId);
        $stmt->execute();
        $course = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($course && !empty($course['website_url']) && str_starts_with($course['website_url'], 'https://')) {
            $stmt = $conn->prepare("INSERT IGNORE INTO worker_training_enrollments (user_id, course_id) VALUES (?, ?)");
            $stmt->bind_param('ii', $__trainingUser['id'], $courseId);
            $stmt->execute();
            $stmt->close();
            header('Location: ' . $course['website_url']);
            exit;
        }
        $_SESSION['flash'] = ['type'=>'error','message'=>'This training does not have a learning website yet.'];
        header('Location: training.php'); exit;
    }
    $courses = $conn->query("SELECT c.*, (e.id IS NOT NULL) AS selected FROM worker_training_courses c LEFT JOIN worker_training_enrollments e ON e.course_id=c.id AND e.user_id=".(int)$__trainingUser['id']." WHERE c.is_active=1 ORDER BY c.title");
    $flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);
    ?>
    <!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Training | DEVSTUDIO SIMS</title><script src="https://cdn.tailwindcss.com"></script><link rel="stylesheet" href="assets/theme.css"></head><body class="bg-slate-900 text-white"><div class="ds-shell"><?php include 'partial_nav.php'; ?><main class="ds-main"><div class="max-w-5xl mx-auto p-8"><h1 class="text-3xl font-bold">Skill Training</h1><p class="text-slate-400 mt-2 mb-6">Choose training classes to improve your skills. You cannot manage other employees' training.</p><?php if($flash): ?><div class="ds-panel mb-4"><?= htmlspecialchars($flash['message']) ?></div><?php endif; ?><div class="grid md:grid-cols-2 gap-4"><?php while($c=$courses->fetch_assoc()): ?><section class="ds-panel"><h2 class="text-xl font-bold"><?= htmlspecialchars($c['title']) ?></h2><p class="text-slate-400 my-3"><?= htmlspecialchars($c['description']) ?></p><p class="text-sm mb-4">Skill: <?= htmlspecialchars($c['skill_name']) ?> · <?= (int)$c['duration_hours'] ?> hours</p><p class="text-sm mb-4"><a class="text-cyan-300 underline" href="<?= htmlspecialchars($c['website_url'] ?? '#', ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener noreferrer"><?= htmlspecialchars($c['website_url'] ?? '', ENT_QUOTES, 'UTF-8') ?></a></p><form method="post"><?= appCsrfField() ?><input type="hidden" name="course_id" value="<?= (int)$c['id'] ?>"><button class="rounded-lg px-4 py-2 bg-emerald-500 text-black font-semibold">Select Training</button></form></section><?php endwhile; ?></div></div></main></div></body></html><?php exit;
}

// Owners and managers can access the same self-directed learning courses as workers,
// while retaining the existing employee skill-level training below.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['course_id']) && ($__trainingUser['role'] ?? '') !== 'worker') {
    $courseId = (int)$_POST['course_id'];
    $stmt = $conn->prepare("SELECT website_url FROM worker_training_courses WHERE id=? AND is_active=1 LIMIT 1");
    $stmt->bind_param('i', $courseId);
    $stmt->execute();
    $course = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($course && !empty($course['website_url']) && str_starts_with($course['website_url'], 'https://')) {
        $stmt = $conn->prepare("INSERT IGNORE INTO worker_training_enrollments (user_id, course_id) VALUES (?, ?)");
        $stmt->bind_param('ii', $__trainingUser['id'], $courseId);
        $stmt->execute();
        $stmt->close();
        header('Location: ' . $course['website_url']);
        exit;
    }
    $_SESSION['flash'] = ['type'=>'error','message'=>'This training does not have a learning website yet.'];
    header('Location: training.php'); exit;
}

$__studioCourses = $conn->query("SELECT c.*, (e.id IS NOT NULL) AS selected FROM worker_training_courses c LEFT JOIN worker_training_enrollments e ON e.course_id=c.id AND e.user_id=".(int)$__trainingUser['id']." WHERE c.is_active=1 ORDER BY c.title");

requireTables(['skills', 'employee_skills']);

/*======================================
    TRAINING & LEVELING
======================================*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $action = $_POST['action'] ?? '';

    if ($action === 'train') {

        $employeeId = (int)($_POST['employee_id'] ?? 0);
        $skillId = (int)($_POST['skill_id'] ?? 0);

        $result = trainEmployee($employeeId, $skillId);

        $_SESSION['flash'] = $result['ok']
            ? ["type" => "success", "message" => "Training complete for ₱" . number_format($result['cost']) . "."]
            : ["type" => "error", "message" => $result['error']];
    }

    header("Location: training.php" . (isset($_POST['employee_id']) ? "?employee=" . (int)$_POST['employee_id'] : ""));
    exit;
}

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$game = getGameState();
$employees = getEmployees();
$skills = getSkills();

$selectedId = (int)($_GET['employee'] ?? ($employees[0]['id'] ?? 0));
$selected = null;

foreach ($employees as $e) {
    if ($e['id'] == $selectedId) {
        $selected = $e;
        break;
    }
}

if (!$selected && count($employees) > 0) {
    $selected = $employees[0];
    $selectedId = $selected['id'];
}

$selectedSkills = $selected ? getEmployeeSkills($selected['id']) : [];
$progress = $selected ? employeeLevelProgress($selected) : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Training | DEVSTUDIO SIMS</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<link rel="stylesheet" href="assets/theme.css">
</head>
<body class="bg-slate-900 text-white">

<div class="ds-shell">

<?php include "partial_nav.php"; ?>

<div class="ds-main">

<div class="flex justify-between items-start mb-8">
<div>
<div class="ds-eyebrow">Team Development</div>
<h1 class="text-3xl font-bold">Training</h1>
<p class="text-slate-400 mt-2">Level up your team's skills. Training costs cash and grants XP toward promotions.</p>
</div>
</div>

<?php if($flash): ?>
<div class="ds-panel <?= $flash['type']=="success" ? "accent-ok" : "accent-alert" ?> mb-8">
<?= htmlspecialchars($flash['message']) ?>
</div>
<?php endif; ?>

<section class="mb-8">
  <div class="mb-4"><h2 class="text-2xl font-bold">Learning Courses</h2><p class="text-slate-400 mt-1">Choose the same self-paced software development courses available to workers.</p></div>
  <div class="grid md:grid-cols-2 gap-4">
  <?php if ($__studioCourses): while($course = $__studioCourses->fetch_assoc()): ?>
    <article class="ds-panel">
      <h3 class="text-lg font-bold"><?= htmlspecialchars($course['title']) ?></h3>
      <p class="text-slate-400 my-3"><?= htmlspecialchars($course['description']) ?></p>
      <p class="text-sm mb-4">Skill: <?= htmlspecialchars($course['skill_name']) ?> · <?= (int)$course['duration_hours'] ?> hours</p>
      <p class="text-sm mb-4"><a class="text-cyan-300 underline" href="<?= htmlspecialchars($course['website_url'] ?? '#', ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener noreferrer"><?= htmlspecialchars($course['website_url'] ?? '', ENT_QUOTES, 'UTF-8') ?></a></p>
      <form method="post"><?= appCsrfField() ?><input type="hidden" name="course_id" value="<?= (int)$course['id'] ?>"><button class="rounded-lg px-4 py-2 bg-emerald-500 text-black font-semibold">Select Training</button></form>
    </article>
  <?php endwhile; endif; ?>
  </div>
</section>

<?php if(count($employees)==0): ?>

<div class="ds-panel text-slate-400">You have no active employees yet. Hire someone from Team first.</div>

<?php else: ?>

<div class="grid lg:grid-cols-3 gap-6">

<!-- ROSTER -->
<div class="ds-panel lg:col-span-1">
<h2 class="font-bold mb-4">Roster</h2>
<div class="flex flex-col gap-2">
<?php foreach($employees as $e): $lp = employeeLevelProgress($e); ?>
<a href="training.php?employee=<?= $e['id'] ?>"
class="p-3 rounded <?= $e['id']==$selectedId ? 'bg-slate-700' : 'hover:bg-slate-700' ?> border border-slate-700">
<div class="flex justify-between">
<span class="font-semibold"><?= htmlspecialchars($e['name']) ?></span>
<span class="ds-tag signal">Lv <?= intval($e['level']) ?></span>
</div>
<div class="text-xs text-slate-400"><?= htmlspecialchars($e['role']) ?></div>
<div class="ds-progress-track mt-2">
<div class="ds-progress-fill" style="width:<?= $lp['percent'] ?>%"></div>
</div>
</a>
<?php endforeach; ?>
</div>
</div>

<!-- SKILLS PANEL -->
<div class="lg:col-span-2">

<?php if($selected): ?>

<div class="ds-panel accent-signal mb-6">
<div class="flex justify-between items-start">
<div>
<h2 class="text-xl font-bold"><?= htmlspecialchars($selected['name']) ?></h2>
<div class="text-slate-400 text-sm"><?= htmlspecialchars($selected['role']) ?></div>
</div>
<div class="text-right">
<div class="ds-tag signal">Level <?= intval($selected['level']) ?></div>
<div class="text-xs text-slate-500 mt-1"><?= $progress['xp'] ?> / <?= $progress['needed'] ?> XP</div>
</div>
</div>
<div class="ds-progress-track mt-4">
<div class="ds-progress-fill" style="width:<?= $progress['percent'] ?>%"></div>
</div>
<div class="grid grid-cols-2 gap-4 mt-5 text-sm">
<div><span class="text-slate-400">Morale</span> <span class="ds-stat-figure text-green-400"><?= $selected['morale'] ?>%</span></div>
<div><span class="text-slate-400">Efficiency</span> <span class="ds-stat-figure text-cyan-400"><?= $selected['efficiency'] ?>%</span></div>
</div>
</div>

<div class="grid md:grid-cols-2 gap-4">
<?php foreach($selectedSkills as $s): $cost = trainingCost($s['level']); ?>
<div class="ds-panel">
<div class="flex justify-between items-start mb-2">
<h3 class="font-semibold"><?= htmlspecialchars($s['name']) ?></h3>
<span class="ds-tag process">Lv <?= $s['level'] ?>/5</span>
</div>
<p class="text-xs text-slate-400 mb-4"><?= htmlspecialchars($s['description']) ?></p>

<?php if($s['level'] >= 5): ?>
<div class="ds-tag ok">Maxed</div>
<?php else: ?>
<form method="post"><?= appCsrfField() ?>
<input type="hidden" name="action" value="train">
<input type="hidden" name="employee_id" value="<?= $selected['id'] ?>">
<input type="hidden" name="skill_id" value="<?= $s['id'] ?>">
<button class="ds-btn primary w-full justify-center">
Train — ₱<?= number_format($cost) ?>
</button>
</form>
<?php endif; ?>
</div>
<?php endforeach; ?>
</div>

<?php endif; ?>

</div>

</div>

<?php endif; ?>

</div>
</div>

<script>lucide.createIcons();</script>
</body>
</html>

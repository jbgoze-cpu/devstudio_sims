<?php
/* Shared helpers for DEVSTUDIO SIMS' educational business simulation. */
require_once __DIR__ . '/business_helpers.php';
if (!function_exists('simEnsureTables')) {
function simEnsureTables(): void {
    global $conn;
    if (!tableExists('simulation_business_state')) $conn->query("CREATE TABLE IF NOT EXISTS simulation_business_state (
      owner_id INT NOT NULL PRIMARY KEY,
      morale TINYINT UNSIGNED NOT NULL DEFAULT 0,
      efficiency TINYINT UNSIGNED NOT NULL DEFAULT 0,
      reputation TINYINT UNSIGNED NOT NULL DEFAULT 0,
      points INT UNSIGNED NOT NULL DEFAULT 0,
      decisions_made INT UNSIGNED NOT NULL DEFAULT 0,
      updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    if (!tableExists('simulation_business_events')) $conn->query("CREATE TABLE IF NOT EXISTS simulation_business_events (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
      owner_id INT NOT NULL,
      actor_id INT NOT NULL,
      event_type ENUM('decision','income','expense','achievement') NOT NULL,
      title VARCHAR(180) NOT NULL,
      details TEXT NOT NULL,
      cash_delta DECIMAL(12,2) NOT NULL DEFAULT 0,
      morale_delta SMALLINT NOT NULL DEFAULT 0,
      efficiency_delta SMALLINT NOT NULL DEFAULT 0,
      reputation_delta SMALLINT NOT NULL DEFAULT 0,
      points_delta INT NOT NULL DEFAULT 0,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_sim_events_owner_date (owner_id, created_at),
      INDEX idx_sim_events_owner_type (owner_id, event_type)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    if (!tableExists('simulation_business_achievements')) $conn->query("CREATE TABLE IF NOT EXISTS simulation_business_achievements (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
      owner_id INT NOT NULL,
      title VARCHAR(120) NOT NULL,
      description VARCHAR(255) NOT NULL,
      unlocked_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      UNIQUE KEY uq_sim_achievement (owner_id, title)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    if (!tableExists('simulation_business_reflections')) $conn->query("CREATE TABLE IF NOT EXISTS simulation_business_reflections (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
      owner_id INT NOT NULL,
      user_id INT NOT NULL,
      scenario_key VARCHAR(40) NOT NULL,
      reflection TEXT NOT NULL,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_sim_reflections_owner_date (owner_id, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}
}
if (!function_exists('simState')) {
function simState(int $ownerId): array {
    global $conn;
    $stmt = $conn->prepare("INSERT IGNORE INTO simulation_business_state (owner_id) VALUES (?)");
    $stmt->bind_param('i', $ownerId); $stmt->execute(); $stmt->close();
    $stmt = $conn->prepare("SELECT * FROM simulation_business_state WHERE owner_id=? LIMIT 1");
    $stmt->bind_param('i', $ownerId); $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc(); $stmt->close();

    // Morale and efficiency represent the active workers' condition, not a studio-wide default.
    // If the owner has no active workers, force both metrics to zero and persist the correction.
    // Use the application's owner-scoped employee helper so this also works when the employee
    // ownership migration has not yet been applied (that helper safely returns an empty list).
    $activeEmployeeCount = null;
    if (function_exists('getEmployees')) {
        $activeEmployees = getEmployees('active');
        if (is_array($activeEmployees)) $activeEmployeeCount = count($activeEmployees);
    }
    if ($activeEmployeeCount === null && tableExists('employees') && columnExists('employees', 'business_owner_id')) {
        $countStmt = $conn->prepare("SELECT COUNT(*) AS total FROM employees WHERE business_owner_id=? AND status='active'");
        $countStmt->bind_param('i', $ownerId); $countStmt->execute();
        $countRow = $countStmt->get_result()->fetch_assoc(); $countStmt->close();
        $activeEmployeeCount = (int)($countRow['total'] ?? 0);
    }
    // A new studio with no decisions starts at 0 reputation, not the legacy 50% seed.
    if ($row && (int)($row['decisions_made'] ?? 0) === 0 && (int)($row['reputation'] ?? 0) !== 0) {
        $row['reputation'] = 0;
        $resetReputation = $conn->prepare("UPDATE simulation_business_state SET reputation=0 WHERE owner_id=? AND decisions_made=0");
        $resetReputation->bind_param('i', $ownerId); $resetReputation->execute(); $resetReputation->close();
    }
    if ($row && $activeEmployeeCount === 0) {
        $row['morale'] = 0;
        $row['efficiency'] = 0;
        $resetStmt = $conn->prepare("UPDATE simulation_business_state SET morale=0, efficiency=0 WHERE owner_id=?");
        $resetStmt->bind_param('i', $ownerId); $resetStmt->execute(); $resetStmt->close();
    }
    return $row ?: ['owner_id'=>$ownerId,'morale'=>0,'efficiency'=>0,'reputation'=>0,'points'=>0,'decisions_made'=>0];
}
}
if (!function_exists('simCash')) {
function simCash(int $ownerId): float {
    global $conn;
    $stmt = $conn->prepare("SELECT business_cash FROM users WHERE id=? AND role='owner' LIMIT 1");
    $stmt->bind_param('i', $ownerId); $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc(); $stmt->close();
    return (float)($row['business_cash'] ?? 0);
}
}
if (!function_exists('simLog')) {
function simLog(int $ownerId, int $actorId, string $type, string $title, string $details, float $cash=0, int $morale=0, int $efficiency=0, int $reputation=0, int $points=0): void {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO simulation_business_events (owner_id, actor_id, event_type, title, details, cash_delta, morale_delta, efficiency_delta, reputation_delta, points_delta) VALUES (?,?,?,?,?,?,?,?,?,?)");
    $stmt->bind_param('iisssdiiii', $ownerId, $actorId, $type, $title, $details, $cash, $morale, $efficiency, $reputation, $points);
    $stmt->execute(); $stmt->close();
    if (function_exists('businessLog')) businessLog($conn, $ownerId, $actorId, $title, $details);
}
}
if (!function_exists('simAward')) {
function simAward(int $ownerId, int $actorId, string $title, string $description): bool {
    global $conn;
    $stmt = $conn->prepare("INSERT IGNORE INTO simulation_business_achievements (owner_id,title,description) VALUES (?,?,?)");
    $stmt->bind_param('iss', $ownerId, $title, $description);
    $stmt->execute(); $won = $stmt->affected_rows > 0; $stmt->close();
    if ($won) {
        global $conn;
        $points = 25;
        $stateUpdate = $conn->prepare("UPDATE simulation_business_state SET points=points+? WHERE owner_id=?");
        $stateUpdate->bind_param('ii', $points, $ownerId); $stateUpdate->execute(); $stateUpdate->close();
        simLog($ownerId, $actorId, 'achievement', 'Achievement unlocked: '.$title, $description, 0,0,0,0,25);
    }
    return $won;
}
}
if (!function_exists('simCheckAchievements')) {
function simCheckAchievements(int $ownerId, int $actorId): void {
    $state = simState($ownerId); $cash = simCash($ownerId);
    if ((int)$state['decisions_made'] >= 1) simAward($ownerId,$actorId,'Decision Maker','Recorded your first business decision.');
    if ($cash >= 100000) simAward($ownerId,$actorId,'Cash Guardian','Maintained at least ₱100,000 in studio cash.');
    if ((int)$state['morale'] >= 80) simAward($ownerId,$actorId,'Team Builder','Raised simulated team morale to 80 or above.');
    if ((int)$state['efficiency'] >= 85) simAward($ownerId,$actorId,'High Efficiency','Raised simulated efficiency to 85 or above.');
    if ((int)$state['reputation'] >= 70) simAward($ownerId,$actorId,'Trusted Studio','Raised studio reputation to 70 or above.');
    if (function_exists('getProjects')) {
        $projects = getProjects();
        if (is_array($projects) && count($projects) > 0) simAward($ownerId,$actorId,'Project Starter','Created at least one software project.');
    }
}
}
if (!function_exists('simFlashRedirect')) {
function simFlashRedirect(string $message, string $type='success', string $to='decision_model.php'): void {
    $_SESSION['flash'] = ['message'=>$message,'type'=>$type];
    header('Location: '.$to); exit;
}
}
if (!function_exists('simEscape')) {
function simEscape($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
}
simEnsureTables();
if (empty($_SESSION['sim_csrf'])) $_SESSION['sim_csrf'] = bin2hex(random_bytes(32));

-- DEVSTUDIO SIMS: business simulation state, decision modeling, finance history, achievements.
-- Select devstudio_sims before importing. Safe to run repeatedly.
CREATE TABLE IF NOT EXISTS simulation_business_state (
  owner_id INT NOT NULL PRIMARY KEY,
  morale TINYINT UNSIGNED NOT NULL DEFAULT 0,
  efficiency TINYINT UNSIGNED NOT NULL DEFAULT 0,
  reputation TINYINT UNSIGNED NOT NULL DEFAULT 0,
  points INT UNSIGNED NOT NULL DEFAULT 0,
  decisions_made INT UNSIGNED NOT NULL DEFAULT 0,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS simulation_business_events (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  owner_id INT NOT NULL,
  actor_id INT NOT NULL,
  event_type ENUM('decision','income','expense','achievement') NOT NULL,
  title VARCHAR(180) NOT NULL,
  details TEXT NOT NULL,
  cash_delta DECIMAL(12,2) NOT NULL DEFAULT 0,
  morale_delta SMALLINT NOT NULL DEFAULT 0,
  efficiency_delta SMALLINT NOT NULL DEFAULT 0,
  reputation_delta SMALLINT NOT NULL DEFAULT 0,
  points_delta INT NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_sim_events_owner_date (owner_id, created_at),
  INDEX idx_sim_events_owner_type (owner_id, event_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS simulation_business_achievements (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  owner_id INT NOT NULL,
  title VARCHAR(120) NOT NULL,
  description VARCHAR(255) NOT NULL,
  unlocked_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_sim_achievement (owner_id, title)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS simulation_business_reflections (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  owner_id INT NOT NULL,
  user_id INT NOT NULL,
  scenario_key VARCHAR(40) NOT NULL,
  reflection TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_sim_reflections_owner_date (owner_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Normalize untouched studio defaults from the older 70/70 starting values.
UPDATE simulation_business_state SET morale=0, efficiency=0 WHERE decisions_made=0 AND morale=70 AND efficiency=70;

<?php
session_start();
require_once "db.php";
require_once "business_helpers.php";
require_once "simulation_helpers.php";

requireLogin();
verifyAppCsrfPost();

$__currentUser = currentUser();
$__currentBusinessRole = businessRoleForUser($conn, $__currentUser);
if (!$__currentUser || !in_array($__currentBusinessRole, ['owner','manager'], true)) {
    http_response_code(403);
    exit('Only the studio owner or manager can create projects.');
}

/*======================================
    CREATE NEW PROJECT
======================================*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $title       = trim($_POST['title']);
    $description = trim($_POST['description']);
    $budget      = (int)$_POST['budget'];
    $deadlineAtInput = trim((string)($_POST['deadline_at'] ?? ''));
    $deadlineTimestamp = strtotime($deadlineAtInput);
    $deadline = ($deadlineTimestamp && $deadlineTimestamp > time()) ? max(1, (int)ceil(($deadlineTimestamp - time()) / 86400)) : 0;
    $deadlineAtForDb = $deadlineTimestamp ? date('Y-m-d H:i:s', $deadlineTimestamp) : '';
    $priority    = $_POST['priority'];
    $requiredDeliverables = trim($_POST['required_deliverables'] ?? '');

    if (
        $title == "" ||
        $description == "" ||
        $budget <= 0 ||
        $deadline <= 0 || !$deadlineTimestamp || $deadlineTimestamp <= time()
    ) {

        $_SESSION['flash'] = [
            "type" => "error",
            "message" => "Please complete all required fields."
        ];

    } else {

        $result = createProject(
            $title,
            $description,
            $budget,
            $deadline,
            $priority,
            $requiredDeliverables,
            $deadlineAtForDb
        );

        if ($result['ok']) {
            $ownerId = (int)(function_exists('currentBusinessOwnerId') ? (currentBusinessOwnerId() ?? 0) : 0);
            $actorId = (int)($__currentUser['id'] ?? 0);
            if ($ownerId > 0) {
                if (function_exists('simLog')) {
                    simLog($ownerId, $actorId, 'expense', 'Project Budget Allocated', 'Budget reserved for project: '.$title, -(float)$budget);
                }
                // Notify the studio owner and every currently hired teammate that the
                // project is published to their shared project workspace.
                if (function_exists('businessNotify')) {
                    $message = 'A new project, "'.$title.'", is now available in Project Management. Budget: ₱'.number_format($budget, 0).'; fixed deadline: '.date('M j, Y g:i A', strtotime($deadlineAtForDb)).'.';
                    businessNotify($conn, $ownerId, 'New project published', $message, 'project_management.php');
                    if (tableExists('business_employment')) {
                        $workersStmt = $conn->prepare("SELECT worker_id FROM business_employment WHERE owner_id=? AND status='hired'");
                        if ($workersStmt) {
                            $workersStmt->bind_param('i', $ownerId);
                            $workersStmt->execute();
                            foreach ($workersStmt->get_result()->fetch_all(MYSQLI_ASSOC) as $workerRow) {
                                $workerId = (int)$workerRow['worker_id'];
                                if ($workerId > 0 && $workerId !== $ownerId) {
                                    businessNotify($conn, $workerId, 'New team project', $message, 'project_management.php');
                                }
                            }
                            $workersStmt->close();
                        }
                    }
                }
                if (function_exists('businessLog')) {
                    businessLog($conn, $ownerId, $actorId, 'Project Published', 'Created and distributed project: '.$title);
                }
            }

            $_SESSION['flash'] = [
                "type" => "success",
                "message" => "Project created and published. The studio owner and hired teammates have been notified."
            ];

            header("Location: project_management.php");
            exit;

        } else {

            $_SESSION['flash'] = [
                "type" => "error",
                "message" => $result['error']
            ];

        }
    }

}

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$game = getGameState();
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>
Create New Project
</title>

<script src="https://cdn.tailwindcss.com"></script>

<script src="https://unpkg.com/lucide@latest"></script>

<link rel="stylesheet" href="assets/theme.css">

</head>

<body class="bg-slate-900 text-white">

<div class="w-full max-w-4xl mx-auto py-5 sm:py-8 px-3 sm:px-6 lg:px-8">

<div class="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4 mb-6">

<div>

<h1 class="text-2xl sm:text-4xl font-bold">

Create New Project

</h1>

<p class="text-slate-400 mt-2">

Create a simulated client or internal software development project for your studio.

</p>

</div>

<a
href="project_management.php"
class="bg-slate-700 hover:bg-slate-600 px-5 py-3 rounded-lg">

Back

</a>

</div>

<?php if($flash): ?>

<div class="mb-6 rounded-lg p-4
<?= $flash['type']=="success"
    ? "bg-green-600"
    : "bg-red-600" ?>">

<?= htmlspecialchars($flash['message']) ?>

</div>

<?php endif; ?>

<div class="bg-slate-800 rounded-xl p-4 sm:p-6 md:p-8 border border-slate-700">

<form method="post" id="create-project-form"><?= appCsrfField() ?>

<div class="grid gap-4 sm:gap-6">

<div>

<label class="block mb-2">

Project Title

</label>

<input
type="text"
name="title"
required
class="w-full bg-slate-700 rounded-lg p-3">

</div>

<div>

<label class="block mb-2">

Description

</label>

<textarea
name="description"
rows="5"
required
class="w-full bg-slate-700 rounded-lg p-3"></textarea>

</div>

<div>
<label class="block mb-2">Required Deliverables</label>
<textarea name="required_deliverables" rows="3" required placeholder="Chapter 1, Chapter 2, Chapter 3" class="w-full bg-slate-700 rounded-lg p-3"></textarea>
<p class="text-xs text-slate-400 mt-2">Separate each required deliverable with a comma or new line. Project progress updates as required files are submitted.</p>
</div>

<div class="grid md:grid-cols-2 gap-6">

<div>

<label class="block mb-2">

Budget (₱)

</label>

<input
type="number"
name="budget"
required
min="1"
class="w-full bg-slate-700 rounded-lg p-3">

</div>

<div>

<label class="block mb-2">

Fixed Deadline (Date &amp; Time)

</label>

<input
type="datetime-local"
name="deadline_at"
required
class="w-full bg-slate-700 rounded-lg p-3">
<p class="text-xs text-slate-400 mt-2">Choose the exact date and time. Once the project is published, this deadline is locked and cannot be changed.</p>

</div>

</div>

<div>

<label class="block mb-2">

Priority

</label>

<select
name="priority"
class="w-full bg-slate-700 rounded-lg p-3">

<option>Low</option>
<option selected>Medium</option>
<option>High</option>
<option>Critical</option>

</select>

</div>

<div class="flex flex-col-reverse sm:flex-row sm:justify-end gap-3 pt-2">
<a href="project_management.php" class="text-center rounded-lg border border-slate-600 px-5 py-3 hover:bg-slate-700">Cancel</a>
<button type="button" id="review-project" class="rounded-lg bg-teal-400 hover:bg-teal-300 text-slate-950 font-bold px-5 py-3">Review &amp; Confirm Project</button>
</div>

</div>
</form>

</div>

</div>

<div id="project-confirm-modal" class="fixed inset-0 z-50 hidden items-center justify-center bg-slate-950/80 p-3 sm:p-5" role="dialog" aria-modal="true" aria-labelledby="confirm-project-title">
  <section class="w-full max-w-xl max-h-[90vh] overflow-y-auto rounded-xl border border-slate-600 bg-slate-900 p-5 sm:p-6 shadow-2xl">
    <div class="flex items-start justify-between gap-4"><div><p class="text-xs uppercase tracking-widest text-teal-300">Publish project</p><h2 id="confirm-project-title" class="text-2xl font-bold mt-1">Confirm project details</h2><p class="text-sm text-slate-400 mt-2">Confirming saves the project and notifies the studio owner and all hired teammates.</p></div><button type="button" id="close-project-confirm" class="text-2xl text-slate-400" aria-label="Close confirmation">×</button></div>
    <dl class="grid gap-3 mt-5 text-sm">
      <div class="rounded-lg bg-slate-800 p-3"><dt class="text-slate-400">Project title</dt><dd id="confirm-title" class="font-semibold mt-1 break-words">—</dd></div>
      <div class="rounded-lg bg-slate-800 p-3"><dt class="text-slate-400">Description</dt><dd id="confirm-description" class="mt-1 whitespace-pre-wrap break-words">—</dd></div>
      <div class="grid grid-cols-1 sm:grid-cols-3 gap-3"><div class="rounded-lg bg-slate-800 p-3"><dt class="text-slate-400">Budget</dt><dd id="confirm-budget" class="font-semibold mt-1">—</dd></div><div class="rounded-lg bg-slate-800 p-3"><dt class="text-slate-400">Fixed deadline</dt><dd id="confirm-deadline" class="font-semibold mt-1">—</dd></div><div class="rounded-lg bg-slate-800 p-3"><dt class="text-slate-400">Priority</dt><dd id="confirm-priority" class="font-semibold mt-1">—</dd></div></div>
      <div class="rounded-lg bg-slate-800 p-3"><dt class="text-slate-400">Required deliverables</dt><dd id="confirm-deliverables" class="mt-1 whitespace-pre-wrap break-words">—</dd></div>
    </dl>
    <div class="flex flex-col-reverse sm:flex-row sm:justify-end gap-3 mt-6"><button type="button" id="edit-project-confirm" class="rounded-lg border border-slate-600 px-5 py-3 hover:bg-slate-800">Back to edit</button><button type="button" id="submit-project-confirm" class="rounded-lg bg-teal-400 text-slate-950 font-bold px-5 py-3 hover:bg-teal-300">Confirm &amp; Distribute Project</button></div>
  </section>
</div>
<script>
(function(){
 const form=document.getElementById('create-project-form'), modal=document.getElementById('project-confirm-modal');
 if(!form||!modal)return;
 const field=name=>form.querySelector('[name="'+name+'"]');
 const val=name=>(field(name)?.value||'').trim();
 const show=(id,text)=>{const el=document.getElementById(id);if(el)el.textContent=text||'—';};
 function openReview(){
   if(!form.reportValidity())return;
   const budget=Number(val('budget'));
   const deadlineValue=val('deadline_at');
   const deadlineDate=new Date(deadlineValue);
   if(budget<1||!deadlineValue||Number.isNaN(deadlineDate.getTime())||deadlineDate.getTime()<=Date.now()){alert('Please choose a future deadline date and time.');return;}
   show('confirm-title',val('title'));show('confirm-description',val('description'));
   show('confirm-budget','₱'+budget.toLocaleString('en-PH'));show('confirm-deadline',deadlineDate.toLocaleString());
   show('confirm-priority',val('priority'));show('confirm-deliverables',val('required_deliverables'));
   modal.classList.remove('hidden');modal.classList.add('flex');document.getElementById('submit-project-confirm').focus();
 }
 function closeReview(){modal.classList.add('hidden');modal.classList.remove('flex');}
 document.getElementById('review-project').addEventListener('click',openReview);
 document.getElementById('close-project-confirm').addEventListener('click',closeReview);
 document.getElementById('edit-project-confirm').addEventListener('click',closeReview);
 modal.addEventListener('click',e=>{if(e.target===modal)closeReview();});
 document.addEventListener('keydown',e=>{if(e.key==='Escape')closeReview();});
 document.getElementById('submit-project-confirm').addEventListener('click',()=>{const b=document.getElementById('submit-project-confirm');b.disabled=true;b.textContent='Publishing…';form.submit();});
})();
if(window.lucide)lucide.createIcons();
</script>

</body>

</html>
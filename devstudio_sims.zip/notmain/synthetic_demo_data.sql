-- OPTIONAL SYNTHETIC DEMO DATA for DEVSTUDIO SIMS
-- Select devstudio_sims first. Intended only for the fictional cheeseBoss demo account.
-- Back up the database first. This inserts sample projects only when a matching title is absent.
SET @demo_owner_id := (SELECT id FROM users WHERE username='cheeseBoss' AND role='owner' ORDER BY id LIMIT 1);

INSERT INTO projects (title, description, budget, deadline, priority, progress, risk, status, business_owner_id, required_deliverables)
SELECT 'Studio Portfolio Website', 'Build a responsive public portfolio website with project showcases and a contact form.', 12000, 21, 'High', 0, 'Low', 'In Progress', @demo_owner_id, 'Requirements, UI Design, Frontend, QA Report'
WHERE @demo_owner_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM projects WHERE business_owner_id=@demo_owner_id AND title='Studio Portfolio Website');

INSERT INTO projects (title, description, budget, deadline, priority, progress, risk, status, business_owner_id, required_deliverables)
SELECT 'Inventory Dashboard Prototype', 'Create a dashboard prototype for tracking stock levels, categories, and low-stock alerts.', 8500, 14, 'Medium', 0, 'Low', 'In Progress', @demo_owner_id, 'Wireframes, Dashboard UI, Data Table, Test Notes'
WHERE @demo_owner_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM projects WHERE business_owner_id=@demo_owner_id AND title='Inventory Dashboard Prototype');

INSERT INTO projects (title, description, budget, deadline, priority, progress, risk, status, business_owner_id, required_deliverables)
SELECT 'Appointment Booking Web App', 'Prototype a simple appointment booking flow with calendar slots and confirmation states.', 15000, 28, 'Critical', 0, 'Medium', 'In Progress', @demo_owner_id, 'User Flow, Booking Form, Calendar View, QA Report'
WHERE @demo_owner_id IS NOT NULL AND NOT EXISTS (SELECT 1 FROM projects WHERE business_owner_id=@demo_owner_id AND title='Appointment Booking Web App');

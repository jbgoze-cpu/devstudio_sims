<?php
session_start();
require_once 'db.php';
require_once 'simulation_helpers.php';
requireLogin();
verifyAppCsrfPost();
$me = currentUser();
$error = '';
$success = '';
$isCheatOwner = (($me['role'] ?? '') === 'owner');
$cheatOwnerId = $isCheatOwner ? (int)$me['id'] : 0;
if ($isCheatOwner) {
    $conn->query("CREATE TABLE IF NOT EXISTS simulation_studio_wallets (owner_id INT NOT NULL PRIMARY KEY, coins INT UNSIGNED NOT NULL DEFAULT 0, updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $walletInit = $conn->prepare("INSERT IGNORE INTO simulation_studio_wallets (owner_id, coins) VALUES (?, 0)");
    if ($walletInit) { $walletInit->bind_param('i', $cheatOwnerId); $walletInit->execute(); $walletInit->close(); }
}
// Load the profile image separately so the settings page can show and update it.
$pictureStmt = $conn->prepare('SELECT profile_picture FROM users WHERE id=? LIMIT 1');
$pictureStmt->bind_param('i', $me['id']);
$pictureStmt->execute();
$pictureRow = $pictureStmt->get_result()->fetch_assoc();
$profilePicture = $pictureRow['profile_picture'] ?? '';
$pictureStmt->close();
function settingH($value) { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['settings_action'] ?? '';
    if (in_array($action, ['cheat_add_coins', 'cheat_add_exp'], true)) {
        if (!$isCheatOwner) {
            $error = 'Cheats are available only for owner accounts.';
        } else {
            $amount = filter_var($_POST['cheat_amount'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 10000]]);
            if ($amount === false || $amount === null) {
                $error = 'Enter a whole number between 1 and 10,000.';
            } elseif ($action === 'cheat_add_coins') {
                $stmt = $conn->prepare('UPDATE simulation_studio_wallets SET coins = coins + ? WHERE owner_id = ?');
                if ($stmt) {
                    $stmt->bind_param('ii', $amount, $cheatOwnerId);
                    if ($stmt->execute() && $stmt->affected_rows > 0) $success = 'Cheat applied: +' . number_format($amount) . ' Studio Coins added to your owner account.';
                    else $error = 'Could not add Studio Coins. Please try again.';
                    $stmt->close();
                } else $error = 'Could not prepare the Studio Coins update.';
            } else {
                simEnsureTables();
                $state = simState($cheatOwnerId);
                $stmt = $conn->prepare('UPDATE simulation_business_state SET points = points + ? WHERE owner_id = ?');
                if ($stmt) {
                    $stmt->bind_param('ii', $amount, $cheatOwnerId);
                    if ($stmt->execute()) $success = 'Cheat applied: +' . number_format($amount) . ' EXP added to your owner account.';
                    else $error = 'Could not add EXP. Please try again.';
                    $stmt->close();
                } else $error = 'Could not prepare the EXP update.';
            }
        }
    } elseif ($action === 'profile_picture') {
        if (!isset($_FILES['profile_picture']) || ($_FILES['profile_picture']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
            $error = 'Choose an image to upload.';
        } elseif ($_FILES['profile_picture']['error'] !== UPLOAD_ERR_OK) {
            $error = 'The image could not be uploaded. Please try again.';
        } elseif ((int)$_FILES['profile_picture']['size'] > 3 * 1024 * 1024) {
            $error = 'Profile pictures must be 3 MB or smaller.';
        } else {
            $tmp = $_FILES['profile_picture']['tmp_name'];
            $imageInfo = @getimagesize($tmp);
            $mime = '';
            if (class_exists('finfo')) { $finfo = new finfo(FILEINFO_MIME_TYPE); $mime = $finfo->file($tmp) ?: ''; }
            $allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
            if (!$imageInfo || !isset($allowed[$mime])) {
                $error = 'Please upload a valid JPG, PNG, or WebP image.';
            } else {
                $uploadDir = __DIR__ . '/uploads/profile_pictures';
                if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true) && !is_dir($uploadDir)) {
                    $error = 'The upload folder is not available. Please contact the site administrator.';
                } else {
                    $newFile = 'user_' . (int)$me['id'] . '_' . bin2hex(random_bytes(12)) . '.' . $allowed[$mime];
                    $destination = $uploadDir . '/' . $newFile;
                    if (!move_uploaded_file($tmp, $destination)) {
                        $error = 'Could not save your profile picture. Please try again.';
                    } else {
                        $relativePath = 'uploads/profile_pictures/' . $newFile;
                        $savePicture = $conn->prepare('UPDATE users SET profile_picture=? WHERE id=?');
                        $savePicture->bind_param('si', $relativePath, $me['id']);
                        if ($savePicture->execute()) {
                            if ($profilePicture && strpos($profilePicture, 'uploads/profile_pictures/') === 0) {
                                $oldPath = __DIR__ . '/' . $profilePicture;
                                if (is_file($oldPath) && realpath($oldPath) !== realpath($destination)) @unlink($oldPath);
                            }
                            $profilePicture = $relativePath;
                            $success = 'Profile picture updated successfully.';
                        } else {
                            @unlink($destination);
                            $error = 'Could not update your profile picture. Please try again.';
                        }
                        $savePicture->close();
                    }
                }
            }
        }
    } elseif ($action === 'birthday') {
        // Validate the submitted date, then verify that the database actually stores it.
        $birthday = trim((string)($_POST['birthday'] ?? ''));
        $validBirthday = $birthday === '' || (
            preg_match('/^\d{4}-\d{2}-\d{2}$/', $birthday) === 1
            && checkdate((int)substr($birthday, 5, 2), (int)substr($birthday, 8, 2), (int)substr($birthday, 0, 4))
            && $birthday <= date('Y-m-d')
        );
        if (!$validBirthday) {
            $error = 'Please enter a valid birthday that is not in the future.';
        } else {
            $stmt = $conn->prepare('UPDATE users SET birthday = ? WHERE id = ?');
            if (!$stmt) {
                $error = 'Could not prepare the birthday update. Please try again.';
            } else {
                $userId = (int)$me['id'];
                $birthdayValue = ($birthday === '') ? null : $birthday;
                $stmt->bind_param('si', $birthdayValue, $userId);
                if ($stmt->execute()) {
                    // Confirm the saved value rather than relying only on execute() returning true.
                    $checkBirthday = $conn->prepare('SELECT birthday FROM users WHERE id = ? LIMIT 1');
                    if ($checkBirthday) {
                        $checkBirthday->bind_param('i', $userId);
                        $checkBirthday->execute();
                        $savedBirthdayRow = $checkBirthday->get_result()->fetch_assoc();
                        $checkBirthday->close();
                        $savedBirthday = $savedBirthdayRow['birthday'] ?? null;
                        if (($birthdayValue === null && ($savedBirthday === null || $savedBirthday === '')) || ($birthdayValue !== null && $savedBirthday === $birthdayValue)) {
                            $success = 'Birthday saved successfully.';
                        } else {
                            $error = 'Your birthday was not updated. Please try again.';
                        }
                    } else {
                        $error = 'Birthday update could not be verified. Please refresh and check your account details.';
                    }
                } else {
                    $error = 'Could not save your birthday. Please try again.';
                }
                $stmt->close();
            }
        }
    } elseif ($action === 'location') {
        $location = trim($_POST['personal_location'] ?? '');
        if (strlen($location) > 255) $error = 'Location must be 255 characters or fewer.';
        else {
            $stmt = $conn->prepare("UPDATE users SET personal_location = NULLIF(?, '') WHERE id = ?");
            $stmt->bind_param('si', $location, $me['id']);
            if ($stmt->execute()) $success = 'Location saved successfully.'; else $error = 'Could not save your location. Please try again.';
        }
    }
    $me = currentUser();
}
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Settings | DEVSTUDIO SIMS</title><script src="https://cdn.tailwindcss.com"></script><link rel="stylesheet" href="assets/theme.css"><style>
/* Compact desktop settings dashboard: use the available width and avoid page scrolling. */
@media (min-width: 1101px) {
  .ds-app-shell > .ds-main { padding: 14px 20px 12px; }
  .settings-hero { max-width: none; padding: 12px 18px; margin: 0 0 10px !important; min-height: 0; }
  .settings-hero h1 { font-size: 1.65rem; line-height: 1.15; }
  .settings-hero p { margin-top: 4px !important; font-size: .82rem; }
  .settings-hero-mark { width: 44px; height: 44px; flex-basis: 44px; font-size: 23px; border-radius: 12px; }
  .settings-grid { max-width: none; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 10px; }
  .settings-grid > section { grid-column: span 1; padding: 12px; }
  .settings-grid > section:nth-of-type(1), .settings-grid > section:nth-of-type(2),
  .settings-grid > section#appearance, .settings-grid > section#cheats,
  .settings-grid > section:last-child { grid-column: span 2; }
  .settings-card-wide { grid-column: span 2; }
  .settings-card-heading { gap: 8px; }
  .settings-card .text-xl { font-size: .96rem; margin-bottom: 2px; }
  .settings-card .text-slate-400 { font-size: .76rem; line-height: 1.3; }
  .settings-card .mb-4 { margin-bottom: 8px !important; }
  .settings-icon { width: 32px; height: 32px; flex-basis: 32px; font-size: 16px; }
  .profile-picture-editor { gap: 10px; }
  .profile-picture-preview { width: 60px; height: 60px; flex-basis: 60px; font-size: 23px; }
  .profile-picture-form label, .settings-card label { font-size: .75rem; margin-bottom: 4px; }
  .profile-picture-form input[type=file] { padding: 5px; font-size: 10px; }
  .settings-card .ds-input { min-height: 34px; padding: 6px 9px; font-size: .82rem; }
  .settings-card .ds-btn { min-height: 32px; padding: 6px 10px; font-size: .78rem; }
  .settings-card .mt-3 { margin-top: 7px !important; }
  .settings-card .p-4 { padding: 10px !important; }
  .settings-card .gap-4 { gap: 8px !important; }
  .settings-card .mb-3 { margin-bottom: 6px !important; }
  .theme-choice { padding: 8px !important; }
  .theme-preview { height: 24px !important; }
  #cheats .text-xs { font-size: 10px; line-height: 1.25; }
  #cheats .mt-3 { margin-top: 6px !important; }
  .ds-alert { margin-bottom: 8px !important; padding: 8px 12px; }
}
</style></head>
<body class="bg-slate-900 text-white"><div class="ds-app-shell"><?php include 'partial_nav.php'; ?><main class="ds-main">
<header class="settings-hero mb-3"><div><div class="ds-eyebrow">ACCOUNT CENTER</div><h1 class="text-3xl font-bold">Settings</h1><p class="text-slate-400 mt-2">Your account, your preferences. Manage everything in one place.</p></div><div class="settings-hero-mark" aria-hidden="true">⚙</div></header>
<?php if ($error): ?><div class="ds-alert error mb-4 max-w-3xl" role="alert"><?=settingH($error)?></div><?php endif; ?>
<?php if ($success): ?><div class="ds-alert success mb-4 max-w-3xl" role="status"><?=settingH($success)?></div><?php endif; ?>
<div class="settings-grid">
<section class="ds-panel settings-card settings-card-profile"><div class="settings-card-heading mb-4"><span class="settings-icon">📷</span><div><h2 class="text-xl font-bold mb-1">Profile Picture</h2><p class="text-slate-400">Upload a clear photo for your account. JPG, PNG, or WebP, up to 3 MB.</p></div></div><div class="profile-picture-editor"><div class="profile-picture-preview" aria-label="Current profile picture"><?php if ($profilePicture): ?><img src="<?=settingH($profilePicture)?>?v=<?=@filemtime(__DIR__ . '/' . $profilePicture) ?: time()?>" alt="Your profile picture"><?php else: ?><span aria-hidden="true">👤</span><?php endif; ?></div><form method="post" enctype="multipart/form-data" class="profile-picture-form"><?= appCsrfField() ?><input type="hidden" name="settings_action" value="profile_picture"><label for="profile_picture" class="block text-sm mb-2">Choose a picture</label><input id="profile_picture" name="profile_picture" type="file" accept="image/jpeg,image/png,image/webp" required class="ds-input w-full"><button type="submit" class="ds-btn primary mt-3">Upload Picture</button></form></div></section>
<section class="ds-panel settings-card settings-card-profile"><div class="settings-card-heading"><span class="settings-icon">👤</span><div><h2 class="text-xl font-bold mb-1">Edit User</h2><p class="text-slate-400">Change your username, email, password, or business details.</p></div><a href="profile.php" class="ds-btn primary">Edit User <span aria-hidden="true">→</span></a></div></section>
<section class="ds-panel settings-card" id="appearance"><div class="settings-card-heading mb-4"><span class="settings-icon">🎨</span><div><h2 class="text-xl font-bold mb-1">Change Theme</h2><p class="text-slate-400">Choose how DEVSTUDIO SIMS looks on this device.</p></div><span id="theme-status" class="text-sm text-slate-400" aria-live="polite">Choose a theme below.</span></div><div class="grid sm:grid-cols-2 gap-4"><button type="button" class="theme-choice" data-theme-choice="dark"><span class="theme-preview theme-preview-dark"></span><span><strong>Dark mode</strong><small>Dark panels and light text</small></span><span class="theme-check" aria-hidden="true">✓</span></button><button type="button" class="theme-choice" data-theme-choice="light"><span class="theme-preview theme-preview-light"></span><span><strong>Light mode</strong><small>Light panels and dark text</small></span><span class="theme-check" aria-hidden="true">✓</span></button></div></section>
<section class="ds-panel settings-card"><div class="settings-card-heading mb-4"><span class="settings-icon">🎂</span><div><h2 class="text-xl font-bold mb-1">Set Birthday</h2><p class="text-slate-400">Add or update your birthday in your account details.</p></div></div><form method="post" class="flex flex-col sm:flex-row gap-3 sm:items-end"><?= appCsrfField() ?><input type="hidden" name="settings_action" value="birthday"><div class="flex-1"><label for="birthday" class="block text-sm mb-2">Birthday</label><input id="birthday" name="birthday" type="date" max="<?=date('Y-m-d')?>" value="<?=settingH($me['birthday'] ?? '')?>" class="ds-input w-full"></div><button type="submit" class="ds-btn primary">Save Birthday</button></form></section>
<section class="ds-panel settings-card"><div class="settings-card-heading mb-4"><span class="settings-icon">📍</span><div><h2 class="text-xl font-bold mb-1">Set Location</h2><p class="text-slate-400">Enter the city, town, or area where you live. This is separate from your business location.</p></div></div><form method="post" class="flex flex-col sm:flex-row gap-3 sm:items-end"><?= appCsrfField() ?><input type="hidden" name="settings_action" value="location"><div class="flex-1"><label for="personal_location" class="block text-sm mb-2">Where you live</label><input id="personal_location" name="personal_location" maxlength="255" value="<?=settingH($me['personal_location'] ?? '')?>" placeholder="City / town / area" class="ds-input w-full"></div><button type="submit" class="ds-btn primary">Save Location</button></form></section>
<?php if ($isCheatOwner): ?>
<section class="ds-panel settings-card settings-card-wide" id="cheats"><div class="settings-card-heading mb-4"><span class="settings-icon">🕹️</span><div><h2 class="text-xl font-bold mb-1">Cheats</h2><p class="text-slate-400">Testing tools for your owner account. Add Studio Coins to shop or EXP to level up. Maximum 10,000 per action.</p></div><span class="text-xs rounded-full px-3 py-1 bg-amber-500/15 text-amber-300 border border-amber-400/30">Experiment</span></div><div class="grid md:grid-cols-2 gap-4"><form method="post" class="rounded-xl border border-slate-700 bg-slate-800/60 p-4"><?= appCsrfField() ?><input type="hidden" name="settings_action" value="cheat_add_coins"><h3 class="font-bold text-lg mb-1">🪙 Add Studio Coins</h3><p class="text-slate-400 text-sm mb-3">Use coins to purchase decorations and themes in Studio (3D).</p><label for="cheat_coins" class="block text-sm mb-2">Amount</label><input id="cheat_coins" name="cheat_amount" type="number" min="1" max="10000" step="1" required value="100" class="ds-input w-full"><button type="submit" class="ds-btn primary mt-3">Add Coins</button></form><form method="post" class="rounded-xl border border-slate-700 bg-slate-800/60 p-4"><?= appCsrfField() ?><input type="hidden" name="settings_action" value="cheat_add_exp"><h3 class="font-bold text-lg mb-1">⚡ Add EXP</h3><p class="text-slate-400 text-sm mb-3">Increase your Studio progression points and level.</p><label for="cheat_exp" class="block text-sm mb-2">Amount</label><input id="cheat_exp" name="cheat_amount" type="number" min="1" max="10000" step="1" required value="100" class="ds-input w-full"><button type="submit" class="ds-btn primary mt-3">Add EXP</button></form></div><p class="text-xs text-slate-500 mt-3">Cheats apply only to the currently signed-in owner’s business. They do not affect workers or other owners.</p></section>
<?php endif; ?>
<section class="ds-panel settings-card settings-card-wide"><div class="settings-card-heading"><span class="settings-icon">↪</span><div><h2 class="text-xl font-bold mb-1">Account</h2><p class="text-slate-400">Sign out of your DEVSTUDIO SIMS account.</p></div><a href="logout.php" class="ds-btn" style="display:inline-flex;background:#7f1d1d;color:#fff;border:1px solid #991b1b">Log out</a></div></section>
</div></main></div>
<script>
(function(){
 const key='devstudio-theme';
 function applyTheme(theme){document.documentElement.dataset.theme=theme;document.body.dataset.theme=theme;document.querySelectorAll('[data-theme-choice]').forEach(b=>{const active=b.dataset.themeChoice===theme;b.classList.toggle('selected',active);b.setAttribute('aria-pressed',active?'true':'false');});const status=document.getElementById('theme-status');if(status)status.textContent='Current theme: '+(theme==='light'?'Light mode':'Dark mode')+'.';}
 let saved='dark';try{saved=localStorage.getItem(key)||'dark';}catch(e){}applyTheme(saved);
 document.querySelectorAll('[data-theme-choice]').forEach(b=>b.addEventListener('click',()=>{const theme=b.dataset.themeChoice;try{localStorage.setItem(key,theme);}catch(e){}applyTheme(theme);}));
})();
</script></body></html>

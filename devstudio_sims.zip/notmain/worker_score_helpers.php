<?php
/** Idempotent score ledger for project deadlines and on-time completions. */
if (!function_exists('ensureWorkerProjectScoreEvents')) {
function ensureWorkerProjectScoreEvents(mysqli $conn): void {
    $conn->query("CREATE TABLE IF NOT EXISTS worker_project_score_events (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        project_id INT NOT NULL,
        owner_id INT NOT NULL,
        user_id INT NOT NULL,
        event_type VARCHAR(32) NOT NULL,
        points_change INT NOT NULL,
        event_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_project_user_event (project_id, user_id, event_type),
        INDEX idx_score_owner_user_date (owner_id, user_id, event_at),
        INDEX idx_score_owner_date (owner_id, event_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}
}
if (!function_exists('syncWorkerProjectScoreEvents')) {
function syncWorkerProjectScoreEvents(mysqli $conn, int $ownerId): void {
    if ($ownerId < 1) return;
    ensureWorkerProjectScoreEvents($conn);
    $conn->query("CREATE TABLE IF NOT EXISTS project_completions (project_id INT NOT NULL PRIMARY KEY, user_id INT NOT NULL, points_awarded INT NOT NULL DEFAULT 1, completed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, INDEX idx_project_completions_user (user_id), INDEX idx_project_completions_date (completed_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $conn->query("CREATE TABLE IF NOT EXISTS project_submissions (id INT AUTO_INCREMENT PRIMARY KEY, project_id INT NOT NULL, user_id INT NOT NULL, original_name VARCHAR(255) NOT NULL DEFAULT '', stored_name VARCHAR(255) NOT NULL DEFAULT '', submitted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, review_status VARCHAR(32) NOT NULL DEFAULT 'pending_review', review_feedback TEXT NULL, reviewed_by INT NULL, reviewed_at DATETIME NULL, INDEX idx_project_submissions_project (project_id), INDEX idx_project_submissions_user (user_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $conn->query("CREATE TABLE IF NOT EXISTS project_worker_assignments (id INT AUTO_INCREMENT PRIMARY KEY, project_id INT NOT NULL, worker_id INT NOT NULL, assigned_by INT NOT NULL DEFAULT 0, assigned_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY uniq_project_worker (project_id, worker_id), INDEX idx_pwa_worker (worker_id), INDEX idx_pwa_project (project_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    // Keep fixed deadline fields available even if this page is the first page opened after an update.
    if (function_exists('columnExists') && !columnExists('projects', 'deadline_started_at')) $conn->query("ALTER TABLE projects ADD COLUMN deadline_started_at DATETIME NULL DEFAULT NULL");
    if (function_exists('columnExists') && !columnExists('projects', 'deadline_at')) $conn->query("ALTER TABLE projects ADD COLUMN deadline_at DATETIME NULL DEFAULT NULL");
    if (function_exists('columnExists') && columnExists('projects', 'deadline_started_at') && columnExists('projects', 'deadline_at') && columnExists('projects', 'deadline')) {
        $conn->query("UPDATE projects SET deadline_at=DATE_ADD(deadline_started_at, INTERVAL deadline DAY) WHERE deadline_at IS NULL AND deadline_started_at IS NOT NULL");
        $conn->query("UPDATE projects SET deadline_started_at=NOW() WHERE deadline_started_at IS NULL");
        $close = $conn->prepare("UPDATE projects p SET p.status='Missed Deadline', p.progress=100 WHERE p.business_owner_id=? AND LOWER(COALESCE(p.status,'')) NOT IN ('completed','missed deadline') AND COALESCE(p.deadline_at, DATE_ADD(p.deadline_started_at, INTERVAL p.deadline DAY)) < NOW() AND NOT EXISTS (SELECT 1 FROM project_submissions ps WHERE ps.project_id=p.id AND ps.submitted_at <= COALESCE(p.deadline_at, DATE_ADD(p.deadline_started_at, INTERVAL p.deadline DAY)))");
        if ($close) { $close->bind_param('i', $ownerId); $close->execute(); $close->close(); }
    }
    // Backfill historical on-time completion credits into the score ledger.
    $backfillDone = $conn->prepare("INSERT IGNORE INTO worker_project_score_events (project_id, owner_id, user_id, event_type, points_change, event_at) SELECT pc.project_id, p.business_owner_id, pc.user_id, 'on_time_completion', GREATEST(1, pc.points_awarded), pc.completed_at FROM project_completions pc JOIN projects p ON p.id=pc.project_id WHERE p.business_owner_id=?");
    if ($backfillDone) { $backfillDone->bind_param('i', $ownerId); $backfillDone->execute(); $backfillDone->close(); }
    // Every assigned worker receives one penalty for each missed project; UNIQUE prevents repeat deductions.
    $backfillMissed = $conn->prepare("INSERT IGNORE INTO worker_project_score_events (project_id, owner_id, user_id, event_type, points_change, event_at) SELECT p.id, p.business_owner_id, pwa.worker_id, 'missed_deadline', -1, COALESCE(p.deadline_at, NOW()) FROM projects p JOIN project_worker_assignments pwa ON pwa.project_id=p.id WHERE p.business_owner_id=? AND LOWER(COALESCE(p.status,''))='missed deadline'");
    if ($backfillMissed) { $backfillMissed->bind_param('i', $ownerId); $backfillMissed->execute(); $backfillMissed->close(); }
}
}

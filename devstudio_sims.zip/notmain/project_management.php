<?php
session_start();
require_once "db.php";
require_once "business_helpers.php";
require_once "worker_score_helpers.php";

requireLogin();
verifyAppCsrfPost();

// Store the start time once so deadline countdowns use elapsed time, not page visits.
if (!columnExists('projects', 'deadline_started_at')) {
    $conn->query("ALTER TABLE projects ADD COLUMN deadline_started_at DATETIME NULL DEFAULT NULL");
}
if (!columnExists('projects', 'deadline_at')) {
    $conn->query("ALTER TABLE projects ADD COLUMN deadline_at DATETIME NULL DEFAULT NULL");
}
// Preserve existing projects by translating their previous day-based deadline into a fixed timestamp once.
$conn->query("UPDATE projects SET deadline_at=DATE_ADD(deadline_started_at, INTERVAL deadline DAY) WHERE deadline_at IS NULL AND deadline_started_at IS NOT NULL");
// Existing projects start their countdown on first load after this feature is installed.
$conn->query("UPDATE projects SET deadline_started_at=NOW() WHERE deadline_started_at IS NULL");

if (!columnExists('projects', 'required_deliverables')) {
    $conn->query("ALTER TABLE projects ADD COLUMN required_deliverables TEXT NULL");
}
$__projectUser = currentUser();
$__projectRole = $__projectUser['role'] ?? '';
$__businessRole = businessRoleForUser($conn, $__projectUser);
$isBusinessOwner = in_array($__businessRole, ['owner','manager'], true);
$isWorker = ($__projectRole === 'worker' && $__businessRole === 'worker');

// Store teammate submissions separately from project-management actions.
$conn->query("CREATE TABLE IF NOT EXISTS project_submissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    user_id INT NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    stored_name VARCHAR(255) NOT NULL,
    submitted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    review_status VARCHAR(32) NOT NULL DEFAULT 'pending_review',
    review_feedback TEXT NULL,
    reviewed_by INT NULL,
    reviewed_at DATETIME NULL,
    INDEX idx_project_submissions_project (project_id),
    INDEX idx_project_submissions_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
// Add review fields safely on existing installations without deleting submission history.
$submissionColumns = [];
$submissionColumnResult = $conn->query("SHOW COLUMNS FROM project_submissions");
if ($submissionColumnResult) { while ($submissionColumn = $submissionColumnResult->fetch_assoc()) $submissionColumns[$submissionColumn['Field']] = true; }
if (!isset($submissionColumns['review_status'])) $conn->query("ALTER TABLE project_submissions ADD COLUMN review_status VARCHAR(32) NOT NULL DEFAULT 'pending_review'");
if (!isset($submissionColumns['review_feedback'])) $conn->query("ALTER TABLE project_submissions ADD COLUMN review_feedback TEXT NULL");
if (!isset($submissionColumns['reviewed_by'])) $conn->query("ALTER TABLE project_submissions ADD COLUMN reviewed_by INT NULL");
if (!isset($submissionColumns['reviewed_at'])) $conn->query("ALTER TABLE project_submissions ADD COLUMN reviewed_at DATETIME NULL");
$conn->query("CREATE TABLE IF NOT EXISTS project_completions (
    project_id INT NOT NULL PRIMARY KEY,
    user_id INT NOT NULL,
    points_awarded INT NOT NULL DEFAULT 1,
    completed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_project_completions_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Explicit assignment records link real hired workers (users) to projects.
// This is separate from the legacy simulated employees/project_team table.
$conn->query("CREATE TABLE IF NOT EXISTS project_worker_assignments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    worker_id INT NOT NULL,
    assigned_by INT NOT NULL,
    assigned_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_project_worker (project_id, worker_id),
    INDEX idx_pwa_worker (worker_id),
    INDEX idx_pwa_project (project_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

/*======================================
    PROJECT MANAGEMENT
======================================*/

// Close projects automatically when their deadline passes without any on-time submission.
// Projects submitted on time remain available for owner/manager review.
$deadlineOwnerId = (int)(function_exists('projectBusinessOwnerId') ? projectBusinessOwnerId() : 0);
if ($deadlineOwnerId > 0) {
    $deadlineCloseSql = "UPDATE projects p
        SET p.status='Missed Deadline', p.progress=100
        WHERE p.business_owner_id=?
          AND LOWER(COALESCE(p.status,'')) NOT IN ('completed','missed deadline')
          AND COALESCE(p.deadline_at, DATE_ADD(p.deadline_started_at, INTERVAL p.deadline DAY)) < NOW()
          AND NOT EXISTS (
              SELECT 1 FROM project_submissions ps
              WHERE ps.project_id=p.id
                AND ps.submitted_at <= COALESCE(p.deadline_at, DATE_ADD(p.deadline_started_at, INTERVAL p.deadline DAY))
          )";
    if ($deadlineCloseStmt = $conn->prepare($deadlineCloseSql)) {
        $deadlineCloseStmt->bind_param('i', $deadlineOwnerId);
        $deadlineCloseStmt->execute();
        $deadlineCloseStmt->close();
    }
    syncWorkerProjectScoreEvents($conn, $deadlineOwnerId);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $action = $_POST['action'] ?? '';
    $id     = (int)($_POST['id'] ?? 0);

    if ($action === 'submit_file') {
        if (!$isWorker && !$isBusinessOwner) {
            http_response_code(403);
            exit('You do not have permission to submit project files.');
        }
        // Confirm the project belongs to the teammate's current team context.
        $submissionProject = getProject($id);
        if (!$submissionProject) {
            http_response_code(403);
            exit('This project is not available to your team.');
        }
        // Workers may submit files/notes only after the owner or manager explicitly assigns them.
        // Enforce this on the server so bypassing the UI or posting directly cannot submit work.
        if ($isWorker) {
            $submitterId = (int)($__projectUser['id'] ?? 0);
            $assignmentCheck = $conn->prepare('SELECT id FROM project_worker_assignments WHERE project_id=? AND worker_id=? LIMIT 1');
            if (!$assignmentCheck) { http_response_code(500); exit('Could not verify project assignment.'); }
            $assignmentCheck->bind_param('ii', $id, $submitterId);
            $assignmentCheck->execute();
            if (!$assignmentCheck->get_result()->fetch_assoc()) {
                http_response_code(403);
                exit("Your not assign to this Project");
            }
        }
        if (in_array(strtolower((string)($submissionProject['status'] ?? '')), ['completed', 'missed deadline'], true)) {
            $_SESSION['flash'] = ["type" => "warning", "message" => strtolower((string)($submissionProject['status'] ?? '')) === 'missed deadline' ? "The deadline passed without an on-time submission. This project is closed." : "This project is already completed."];
            header("Location: project_management.php");
            exit;
        }
        if (empty($_FILES['submission_file']) || $_FILES['submission_file']['error'] !== UPLOAD_ERR_OK) {
            $_SESSION['flash'] = ["type" => "error", "message" => "Choose a file to submit and try again."];
            header("Location: project_management.php");
            exit;
        }
        $file = $_FILES['submission_file'];
        $maxSize = 10 * 1024 * 1024;
        $originalName = basename(str_replace('\\', '/', $file['name']));
        $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
        $allowedExtensions = ['pdf','doc','docx','ppt','pptx','xls','xlsx','zip','txt','png','jpg','jpeg'];
        $allowedMimeTypes = [
            'pdf' => ['application/pdf'],
            'doc' => ['application/msword', 'application/vnd.ms-office', 'application/octet-stream'],
            'docx' => ['application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/zip', 'application/octet-stream'],
            'ppt' => ['application/vnd.ms-powerpoint', 'application/octet-stream'],
            'pptx' => ['application/vnd.openxmlformats-officedocument.presentationml.presentation', 'application/zip', 'application/octet-stream'],
            'xls' => ['application/vnd.ms-excel', 'application/octet-stream'],
            'xlsx' => ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/zip', 'application/octet-stream'],
            'zip' => ['application/zip', 'application/x-zip-compressed', 'application/octet-stream'],
            'txt' => ['text/plain'],
            'png' => ['image/png'],
            'jpg' => ['image/jpeg'],
            'jpeg' => ['image/jpeg']
        ];
        $detectedMime = '';
        if (is_uploaded_file($file['tmp_name']) && class_exists('finfo')) {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $detectedMime = (string)$finfo->file($file['tmp_name']);
        }
        $mimeAllowed = isset($allowedMimeTypes[$extension]) && in_array($detectedMime, $allowedMimeTypes[$extension], true);
        if ($file['size'] < 1 || $file['size'] > $maxSize || !in_array($extension, $allowedExtensions, true) || !is_uploaded_file($file['tmp_name']) || !$mimeAllowed) {
            $_SESSION['flash'] = ["type" => "error", "message" => "Use a supported document/image/archive file up to 10 MB."];
            header("Location: project_management.php");
            exit;
        }
        $uploadDir = __DIR__ . '/uploads/submissions';
        if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true) && !is_dir($uploadDir)) {
            $_SESSION['flash'] = ["type" => "error", "message" => "Upload folder could not be created."];
            header("Location: project_management.php");
            exit;
        }
        $storedName = bin2hex(random_bytes(16)) . '.' . $extension;
        if (!move_uploaded_file($file['tmp_name'], $uploadDir . '/' . $storedName)) {
            $_SESSION['flash'] = ["type" => "error", "message" => "File upload failed. Please try again."];
            header("Location: project_management.php");
            exit;
        }
        $stmt = $conn->prepare("INSERT INTO project_submissions (project_id, user_id, original_name, stored_name) VALUES (?, ?, ?, ?)");
        $userId = (int)($__projectUser['id'] ?? 0);
        $stmt->bind_param('iiss', $id, $userId, $originalName, $storedName);
        $stmt->execute();

        // Submission is pending review; completion points are awarded only after approval.
        $earnedCompletionPoint = false;

        // Notify the project owner that this project has been submitted and completed.
        $conn->query("CREATE TABLE IF NOT EXISTS business_notifications (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            title VARCHAR(255) NOT NULL,
            body TEXT NOT NULL,
            link_url VARCHAR(500) NOT NULL DEFAULT 'evaluation.php',
            is_read TINYINT(1) NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_business_notifications_user (user_id, created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $projectTitle = trim((string)($submissionProject['title'] ?? $submissionProject['project_title'] ?? $submissionProject['name'] ?? 'Project'));
        $ownerId = (int)($submissionProject['business_owner_id'] ?? 0);
        if ($ownerId > 0 && $ownerId !== (int)($__projectUser['id'] ?? 0)) {
            $notificationTitle = 'Project submission needs review';
            $notificationBody = $projectTitle . ' has been submitted by ' . (string)($__projectUser['username'] ?? 'a teammate') . '. Review the submission before awarding completion points.';
            $notificationLink = 'evaluation.php';
            $notifyStmt = $conn->prepare("INSERT INTO business_notifications (user_id, title, body, link_url) VALUES (?, ?, ?, ?)");
            $notifyStmt->bind_param('isss', $ownerId, $notificationTitle, $notificationBody, $notificationLink);
            $notifyStmt->execute();
        }

        // Save the shared Project Canvas along with the file submission.
        $conn->query("CREATE TABLE IF NOT EXISTS project_canvas (project_id INT PRIMARY KEY, content MEDIUMTEXT NOT NULL, updated_by INT NULL, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $canvasContent = trim($_POST['canvas_content'] ?? '');
        $canvasStmt = $conn->prepare("INSERT INTO project_canvas (project_id, content, updated_by) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE content=VALUES(content), updated_by=VALUES(updated_by), updated_at=CURRENT_TIMESTAMP");
        $canvasStmt->bind_param('isi', $id, $canvasContent, $userId);
        $canvasStmt->execute();

        // Keep the project active until an Owner/Manager approves the submission.
        $reviewStmt = $conn->prepare("UPDATE projects SET status='Pending Review' WHERE id=?");
        $reviewStmt->bind_param('i', $id);
        $reviewStmt->execute();
        $deliverables = array_values(array_filter(array_map('trim', preg_split('/[,\n\r]+/', (string)($submissionProject['required_deliverables'] ?? '')))));
        if ($deliverables) {
            $subStmt = $conn->prepare("SELECT original_name FROM project_submissions WHERE project_id=?");
            $subStmt->bind_param('i', $id); $subStmt->execute();
            $names = [];
            foreach ($subStmt->get_result()->fetch_all(MYSQLI_ASSOC) as $row) $names[] = strtolower(preg_replace('/[^a-z0-9]+/i', ' ', pathinfo($row['original_name'], PATHINFO_FILENAME)));
            $done = 0;
            foreach ($deliverables as $deliverable) {
                $needle = strtolower(trim(preg_replace('/[^a-z0-9]+/i', ' ', $deliverable)));
                foreach ($names as $name) { if ($needle !== '' && (strpos($name, $needle) !== false || strpos($needle, $name) !== false)) { $done++; break; } }
            }
        }
        $_SESSION['flash'] = ["type" => "success", "message" => "Work submitted successfully and sent for Owner/Manager review. Points will be awarded only after approval."];
        header("Location: project_management.php");
        exit;
    }

    if (in_array($action, ['approve_submission', 'request_revision', 'reject_submission'], true)) {
        if (!$isBusinessOwner) { http_response_code(403); exit('Only the Owner/Manager can review submissions.'); }
        $submissionId = (int)($_POST['submission_id'] ?? 0);
        $reviewNote = trim((string)($_POST['review_feedback'] ?? ''));
        $reviewLookup = $conn->prepare("SELECT id, project_id, user_id, review_status FROM project_submissions WHERE id=? LIMIT 1");
        $reviewLookup->bind_param('i', $submissionId); $reviewLookup->execute(); $submissionToReview = $reviewLookup->get_result()->fetch_assoc();
        if (!$submissionToReview || !getProject((int)$submissionToReview['project_id'])) { http_response_code(404); exit('Submission not found for your business.'); }
        if (in_array((string)$submissionToReview['review_status'], ['approved','rejected'], true)) {
            $_SESSION['flash'] = ['type'=>'warning','message'=>'This submission has already been finalized.'];
            header('Location: project_management.php'); exit;
        }
        $reviewerId = (int)($__projectUser['id'] ?? 0);
        if ($action === 'approve_submission') {
            $updateReview = $conn->prepare("UPDATE project_submissions SET review_status='approved', review_feedback=?, reviewed_by=?, reviewed_at=NOW() WHERE id=?");
            $updateReview->bind_param('sii', $reviewNote, $reviewerId, $submissionId); $updateReview->execute();
            $projectId = (int)$submissionToReview['project_id']; $workerId = (int)$submissionToReview['user_id'];
            $award = $conn->prepare("INSERT IGNORE INTO project_completions (project_id, user_id, points_awarded) VALUES (?, ?, 1)");
            $award->bind_param('ii', $projectId, $workerId); $award->execute();
            if ($award->affected_rows > 0) {
                ensureWorkerProjectScoreEvents($conn);
                $scoreOwnerId = (int)(function_exists('businessOwnerForUser') ? (businessOwnerForUser($conn, $__projectUser) ?? 0) : 0);
                if ($scoreOwnerId < 1) $scoreOwnerId = (int)(function_exists('projectBusinessOwnerId') ? projectBusinessOwnerId() : 0);
                $scoreEvent = $conn->prepare("INSERT IGNORE INTO worker_project_score_events (project_id, owner_id, user_id, event_type, points_change, event_at) VALUES (?, ?, ?, 'on_time_completion', 1, NOW())");
                if ($scoreEvent) { $scoreEvent->bind_param('iii', $projectId, $scoreOwnerId, $workerId); $scoreEvent->execute(); $scoreEvent->close(); }
            }
            $projectUpdate = $conn->prepare("UPDATE projects SET progress=100, status='Completed' WHERE id=?"); $projectUpdate->bind_param('i', $projectId); $projectUpdate->execute();
            $_SESSION['flash'] = ['type'=>'success','message'=> $award->affected_rows > 0 ? 'Submission approved. Project completed and 1 leaderboard point awarded.' : 'Submission approved. This project already has a completion credit, so no duplicate points were awarded.'];
            if (function_exists('businessNotify')) businessNotify($conn, (int)$submissionToReview['user_id'], 'Project approved', 'Your project submission has been approved. Completion points have been processed.', 'project_management.php');
        } else {
            $status = $action === 'request_revision' ? 'revision_required' : 'rejected';
            if ($reviewNote === '') $reviewNote = $action === 'request_revision' ? 'Please revise your submission and resubmit.' : 'Submission was not approved.';
            $updateReview = $conn->prepare("UPDATE project_submissions SET review_status=?, review_feedback=?, reviewed_by=?, reviewed_at=NOW() WHERE id=?");
            $updateReview->bind_param('ssii', $status, $reviewNote, $reviewerId, $submissionId); $updateReview->execute();
            $projectId = (int)$submissionToReview['project_id'];
            $projectUpdate = $conn->prepare("UPDATE projects SET status='In Progress' WHERE id=? AND status<>'Completed'"); $projectUpdate->bind_param('i', $projectId); $projectUpdate->execute();
            $_SESSION['flash'] = ['type'=>'warning','message'=> $action === 'request_revision' ? 'Revision requested. The worker can submit corrected work; no points were awarded.' : 'Submission rejected. No points were awarded.'];
            if (function_exists('businessNotify')) businessNotify($conn, (int)$submissionToReview['user_id'], $action === 'request_revision' ? 'Revision requested' : 'Submission rejected', $reviewNote, 'project_management.php');
        }
        header('Location: project_management.php'); exit;
    }

    if ($action === 'save_canvas') {
        $canvasProject = getProject($id);
        if (!$canvasProject) { http_response_code(404); exit('Project not found.'); }
        if ($isWorker) {
            $submitterId = (int)($__projectUser['id'] ?? 0);
            $assignmentCheck = $conn->prepare('SELECT id FROM project_worker_assignments WHERE project_id=? AND worker_id=? LIMIT 1');
            if (!$assignmentCheck) { http_response_code(500); exit('Could not verify project assignment.'); }
            $assignmentCheck->bind_param('ii', $id, $submitterId);
            $assignmentCheck->execute();
            if (!$assignmentCheck->get_result()->fetch_assoc()) {
                http_response_code(403);
                exit("Your not assign to this Project");
            }
        }
        $conn->query("CREATE TABLE IF NOT EXISTS project_canvas (project_id INT PRIMARY KEY, content MEDIUMTEXT NOT NULL, updated_by INT NULL, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $content = trim($_POST['canvas_content'] ?? '');
        $uid = (int)($__projectUser['id'] ?? 0);
        $stmt = $conn->prepare("INSERT INTO project_canvas (project_id, content, updated_by) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE content=VALUES(content), updated_by=VALUES(updated_by), updated_at=CURRENT_TIMESTAMP");
        $stmt->bind_param('isi', $id, $content, $uid); $stmt->execute();
        $_SESSION['flash'] = ["type" => "success", "message" => "Project Canvas saved."];
        header("Location: project_management.php"); exit;
    }

    if (!$isBusinessOwner) {
        http_response_code(403);
        exit('Only studio owners and managers can manage projects. Workers can submit project files.');
    }

    switch ($action) {

        case 'assign_worker':
            $assignProject = getProject($id);
            $workerId = (int)($_POST['worker_id'] ?? 0);
            $actorId = (int)($__projectUser['id'] ?? 0);
            $ownerId = (int)($assignProject['business_owner_id'] ?? 0);
            if (!$assignProject || $workerId < 1 || $ownerId < 1) {
                $_SESSION['flash'] = ['type'=>'error', 'message'=>'Project or worker selection is invalid.'];
                break;
            }
            // Verify the selected user is actively hired by this exact studio.
            $validWorker = false;
            if (tableExists('business_employment')) {
                $workerCheck = $conn->prepare("SELECT worker_id FROM business_employment WHERE owner_id=? AND worker_id=? AND status='hired' LIMIT 1");
                if ($workerCheck) {
                    $workerCheck->bind_param('ii', $ownerId, $workerId);
                    $workerCheck->execute();
                    $validWorker = (bool)$workerCheck->get_result()->fetch_assoc();
                }
            }
            if (!$validWorker) {
                $_SESSION['flash'] = ['type'=>'error', 'message'=>'That person is not currently a hired worker in your studio.'];
                break;
            }
            // Enforce availability on the server: a worker cannot be assigned to another unfinished project in this business.
            $busyCheck = $conn->prepare("SELECT p.title FROM project_worker_assignments pwa JOIN projects p ON p.id=pwa.project_id WHERE pwa.worker_id=? AND p.business_owner_id=? AND p.id<>? AND LOWER(COALESCE(p.status, '')) NOT IN ('completed','missed deadline') LIMIT 1");
            if (!$busyCheck) {
                $_SESSION['flash'] = ['type'=>'error', 'message'=>'Could not verify worker availability. Please try again.'];
                break;
            }
            $busyCheck->bind_param('iii', $workerId, $ownerId, $id);
            $busyCheck->execute();
            $busyProject = $busyCheck->get_result()->fetch_assoc();
            $busyCheck->close();
            if ($busyProject) {
                $_SESSION['flash'] = ['type'=>'error', 'message'=>'This worker is already assigned to an unfinished project (' . (string)$busyProject['title'] . ') and cannot be assigned again until that project is completed.'];
                break;
            }
            $assignStmt = $conn->prepare("INSERT INTO project_worker_assignments (project_id, worker_id, assigned_by) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE assigned_by=VALUES(assigned_by), assigned_at=CURRENT_TIMESTAMP");
            $assignStmt->bind_param('iii', $id, $workerId, $actorId);
            if ($assignStmt->execute()) {
                $workerName = 'your worker';
                $nameStmt = $conn->prepare("SELECT username FROM users WHERE id=? LIMIT 1");
                $nameStmt->bind_param('i', $workerId); $nameStmt->execute();
                $nameRow = $nameStmt->get_result()->fetch_assoc();
                if ($nameRow && !empty($nameRow['username'])) $workerName = $nameRow['username'];
                if (function_exists('businessNotify')) businessNotify($conn, $workerId, 'Project assigned to you', 'You have been assigned to project: ' . (string)$assignProject['title'] . '.', 'project_management.php');
                $_SESSION['flash'] = ['type'=>'success', 'message'=>htmlspecialchars($workerName, ENT_QUOTES, 'UTF-8') . ' assigned to project successfully.'];
            } else {
                $_SESSION['flash'] = ['type'=>'error', 'message'=>'Could not assign this worker. Please try again.'];
            }
        break;

        case 'assign_team':
            // Backward-compatible action for older forms: retain the legacy team simulation.
            $result = assignTeamToProject($id);
            $_SESSION['flash'] = $result['ok']
                ? ["type" => "success", "message" => "Team simulation updated. Choose a specific worker below to assign them to this project."]
                : ["type" => "error", "message" => $result['error']];
        break;

        case 'delete':
            if (($__me = currentUser()) && $__me['role'] === 'owner') {
                deleteProject($id);
                $_SESSION['flash'] = ["type" => "warning", "message" => "Project deleted."];
            } else {
                $_SESSION['flash'] = ["type" => "error", "message" => "Only the owner can delete projects."];
            }
        break;
    }

    header("Location: project_management.php");
    exit;
}

// Flash Message
$flash = $_SESSION['flash'] ?? null;
$__me = currentUser();
unset($_SESSION['flash']);

// Current Game State
$game = getGameState();
$isBusinessOwner = in_array(businessRoleForUser($conn, $__me), ['owner','manager'], true);
$isWorker = (($__me['role'] ?? '') === 'worker');
$displayStudioCash = $isWorker ? 0 : (int)($game['cash'] ?? 0);

// All Projects
$projects = getProjects();

// Only show currently hired workers belonging to this studio in assignment dropdowns.
$assignableWorkers = [];
if ($isBusinessOwner && tableExists('business_employment')) {
    $assignOwnerId = (int)(function_exists('currentBusinessOwnerId') ? (currentBusinessOwnerId() ?? 0) : 0);
    if ($assignOwnerId < 1 && function_exists('projectBusinessOwnerId')) $assignOwnerId = (int)projectBusinessOwnerId();
    if ($assignOwnerId > 0) {
        $workersQuery = $conn->prepare("SELECT u.id, u.username FROM business_employment be JOIN users u ON u.id=be.worker_id WHERE be.owner_id=? AND be.status='hired' AND NOT EXISTS (SELECT 1 FROM project_worker_assignments pwa JOIN projects p ON p.id=pwa.project_id WHERE pwa.worker_id=u.id AND p.business_owner_id=be.owner_id AND LOWER(COALESCE(p.status, '')) NOT IN ('completed','missed deadline')) ORDER BY u.username ASC");
        if ($workersQuery) {
            $workersQuery->bind_param('i', $assignOwnerId);
            $workersQuery->execute();
            $assignableWorkers = $workersQuery->get_result()->fetch_all(MYSQLI_ASSOC);
        }
    }
}

// Worker list for the Project Management quick-view popup (current business only).
$studioWorkersForPopup = [];
$popupOwnerId = (int)(function_exists('currentBusinessOwnerId') ? (currentBusinessOwnerId() ?? 0) : 0);
if ($popupOwnerId < 1 && function_exists('projectBusinessOwnerId')) $popupOwnerId = (int)projectBusinessOwnerId();
if ($popupOwnerId > 0 && tableExists('business_employment')) {
    // A worker is busy while assigned to any project in this business that has not been completed.
    // Pending-review projects still count as occupied until the project is marked completed.
    $popupWorkersQuery = $conn->prepare("SELECT u.id, u.username, COALESCE(be.employment_role, 'worker') AS employment_role, active.active_project_titles FROM business_employment be JOIN users u ON u.id=be.worker_id LEFT JOIN (SELECT pwa.worker_id, GROUP_CONCAT(DISTINCT p.title ORDER BY p.title SEPARATOR ', ') AS active_project_titles FROM project_worker_assignments pwa JOIN projects p ON p.id=pwa.project_id WHERE p.business_owner_id=? AND LOWER(COALESCE(p.status, '')) NOT IN ('completed','missed deadline') GROUP BY pwa.worker_id) active ON active.worker_id=u.id WHERE be.owner_id=? AND be.status='hired' ORDER BY u.username ASC");
    if ($popupWorkersQuery) {
        $popupWorkersQuery->bind_param('ii', $popupOwnerId, $popupOwnerId);
        $popupWorkersQuery->execute();
        $studioWorkersForPopup = $popupWorkersQuery->get_result()->fetch_all(MYSQLI_ASSOC);
        $popupWorkersQuery->close();
    }
}

// Recalculate progress from the required deliverables and submitted filenames
// each time the board loads, so the Overall Progress bar never relies on stale data.
foreach ($projects as &$project) {
    if (in_array(strtolower((string)($project['status'] ?? '')), ['completed', 'missed deadline'], true)) {
        $project['progress'] = 100;
        continue;
    }
    if (strtolower((string)($project['status'] ?? '')) === 'pending review') {
        continue;
    }
    $deliverables = array_values(array_filter(array_map('trim', preg_split('/[,\n\r]+/', (string)($project['required_deliverables'] ?? '')))));
    if (!$deliverables) {
        $project['progress'] = 0;
        continue;
    }
    $submissionStmt = $conn->prepare("SELECT original_name FROM project_submissions WHERE project_id=?");
    $pid = (int)$project['id'];
    $submissionStmt->bind_param('i', $pid);
    $submissionStmt->execute();
    $submittedNames = [];
    foreach ($submissionStmt->get_result()->fetch_all(MYSQLI_ASSOC) as $submission) {
        $submittedNames[] = strtolower(trim(preg_replace('/[^a-z0-9]+/i', ' ', pathinfo($submission['original_name'], PATHINFO_FILENAME))));
    }
    $done = 0;
    foreach ($deliverables as $deliverable) {
        $needle = strtolower(trim(preg_replace('/[^a-z0-9]+/i', ' ', $deliverable)));
        if ($needle === '') continue;
        foreach ($submittedNames as $submittedName) {
            if ($submittedName !== '' && (strpos($submittedName, $needle) !== false || strpos($needle, $submittedName) !== false)) {
                $done++;
                break;
            }
        }
    }
    $calculatedProgress = (int)round(($done / count($deliverables)) * 100);
    $project['progress'] = $calculatedProgress;
    $project['status'] = 'In Progress';
    $ownerId = (int)($project['business_owner_id'] ?? 0);
    $progressStmt = $conn->prepare("UPDATE projects SET progress=?, status='In Progress' WHERE id=?");
    $progressStmt->bind_param('ii', $calculatedProgress, $pid);
    $progressStmt->execute();
}
unset($project);

// Statistics
$totalProjects = count($projects);

$completedProjects = 0;
$activeProjects = 0;
$totalBudget = 0;

foreach($projects as $project){

    $totalBudget += $project['budget'];

    if($project['status']=="Completed"){
        $completedProjects++;
    }

    if($project['status']=="In Progress"){
        $activeProjects++;
    }

}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>
DEVSTUDIO SIMS | Project Management
</title>

<script src="https://cdn.tailwindcss.com"></script>

<script src="https://unpkg.com/lucide@latest"></script>

<link rel="stylesheet" href="assets/theme.css">
<style>
:root{color-scheme:dark}
body{background:#080d19!important;background-image:radial-gradient(ellipse at 12% 0%,rgba(37,99,235,.13),transparent 38%),radial-gradient(ellipse at 100% 20%,rgba(8,145,178,.08),transparent 30%)!important}
.ds-main{min-width:0}
.pm-header{background:rgba(15,23,42,.82);border-bottom:1px solid rgba(148,163,184,.15);backdrop-filter:blur(14px)}
.pm-container{width:100%;max-width:none;box-sizing:border-box;margin:0 auto;padding:10px clamp(8px,1vw,14px) 16px}
.pm-page-title{font-size:clamp(1.65rem,2.5vw,2.25rem);letter-spacing:-.04em;line-height:1.15}
.pm-subtitle{margin-top:4px;color:#94a3b8;font-size:.84rem}
.pm-top-link{display:inline-flex;align-items:center;gap:8px;padding:10px 14px;border-radius:11px;border:1px solid rgba(148,163,184,.18);background:rgba(30,41,59,.72);font-size:.875rem;font-weight:600;color:#dbeafe;transition:.18s ease}
.pm-top-link:hover{background:#263449;border-color:rgba(96,165,250,.45);transform:translateY(-1px)}
.pm-stat-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}
.pm-stat{position:relative;overflow:hidden;min-width:0;padding:12px;border-radius:17px;background:linear-gradient(145deg,rgba(30,41,59,.96),rgba(15,23,42,.96));border:1px solid rgba(148,163,184,.15);box-shadow:0 12px 28px rgba(0,0,0,.12)}
.pm-stat:after{content:"";position:absolute;right:-22px;top:-25px;width:76px;height:76px;border-radius:50%;background:var(--accent,rgba(59,130,246,.13));filter:blur(1px)}
.pm-stat-label{font-size:.78rem;color:#94a3b8;font-weight:600;letter-spacing:.02em}
.pm-stat-value{position:relative;z-index:1;margin-top:5px;font-size:clamp(1.15rem,1.7vw,1.5rem);font-weight:750;letter-spacing:-.04em;line-height:1.1;overflow-wrap:anywhere}
.pm-section-heading{display:flex;align-items:flex-end;justify-content:space-between;gap:10px;margin:10px 0 7px}
.pm-section-heading h2{font-size:1.35rem;font-weight:750;letter-spacing:-.025em}
.pm-section-heading p{font-size:.84rem;color:#94a3b8;margin-top:5px}
.pm-create-btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;background:linear-gradient(135deg,#059669,#0d9488);padding:11px 16px;border-radius:12px;font-size:.9rem;font-weight:700;box-shadow:0 8px 20px rgba(5,150,105,.18);transition:.2s}
.pm-create-btn:hover{filter:brightness(1.1);transform:translateY(-1px)}
.pm-workspace-grid{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:16px;align-items:start;margin-top:18px}.pm-workspace-column{min-width:0;margin-top:0!important}.pm-workspace-grid:not(:has(> .pm-workspace-column:nth-child(2)))>.pm-workspace-column{grid-column:1/-1}.pm-workspace-grid:not(:has(> .pm-workspace-column:nth-child(2)))>.pm-workspace-column .pm-project-card{max-width:100%;}.pm-workspace-column .pm-project-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,520px),1fr));gap:12px;align-items:start;width:100%}.pm-workspace-column .pm-section-heading{margin-top:0}.pm-workspace-column .pm-empty{min-height:230px;padding:30px 16px}
.pm-project-card{min-width:0;width:100%;box-sizing:border-box;padding:9px;border-radius:14px;border:1px solid rgba(148,163,184,.16);background:linear-gradient(155deg,rgba(30,41,59,.96),rgba(15,23,42,.98));box-shadow:0 16px 34px rgba(0,0,0,.15);transition:border-color .2s,transform .2s}
.pm-project-card:hover{border-color:rgba(96,165,250,.38);transform:translateY(-2px)}
.pm-active-project-details{width:100%}
.pm-active-project-summary{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;cursor:pointer;list-style:none}
.pm-active-project-summary::-webkit-details-marker{display:none}
.pm-active-project-summary>.pm-project-head{flex:1;min-width:0}
.pm-active-project-details[open] .pm-expand-closed{display:none}
.pm-active-project-details:not([open]) .pm-expand-open{display:none}
.pm-active-project-content{padding-top:10px}
.pm-finished-project-details{width:100%}
.pm-finished-project-summary{display:flex;align-items:center;justify-content:space-between;gap:12px;cursor:pointer;list-style:none}
.pm-finished-project-summary::-webkit-details-marker{display:none}
.pm-expand-label{flex-shrink:0;border:1px solid rgba(34,211,238,.32);border-radius:8px;padding:7px 10px;color:#67e8f9;font-size:12px;font-weight:700;white-space:nowrap}
.pm-expand-open{display:none}
.pm-finished-project-details[open] .pm-expand-closed{display:none}
.pm-finished-project-details[open] .pm-expand-open{display:inline}
.pm-finished-project-content{padding-top:2px}
@media(max-width:640px){.pm-finished-project-summary{align-items:flex-start;flex-direction:column}.pm-active-project-summary{flex-direction:column}.pm-active-project-summary>.pm-project-head{width:100%}.pm-expand-label{align-self:flex-start}}

.pm-project-head{display:flex;align-items:flex-start;justify-content:space-between;gap:14px}
.pm-project-title{font-size:1rem;line-height:1.4;font-weight:750;overflow-wrap:anywhere}
.pm-project-description{font-size:.76rem;color:#94a3b8;line-height:1.45;margin-top:4px;white-space:pre-line;overflow-wrap:anywhere}
.pm-status.pm-missed-deadline{border-color:rgba(248,113,113,.5);background:rgba(127,29,29,.4);color:#fca5a5}
.pm-finished-project-card.pm-missed-deadline-card{border-color:rgba(248,113,113,.48);background:linear-gradient(145deg,rgba(127,29,29,.22),rgba(15,23,42,.92))}
.pm-missed-deadline-banner{margin-top:12px;border:1px solid rgba(248,113,113,.42);background:rgba(127,29,29,.28);color:#fecaca;border-radius:12px;padding:12px;font-size:.82rem;font-weight:700}
.pm-status{flex-shrink:0;border:1px solid rgba(96,165,250,.22);background:rgba(37,99,235,.15);color:#bfdbfe;border-radius:999px;padding:4px 8px;font-size:.68rem;font-weight:700;white-space:nowrap}
.pm-meta-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(90px,1fr));gap:6px;margin-top:7px}
.pm-meta{min-width:0;padding:8px;border-radius:12px;background:rgba(2,6,23,.3);border:1px solid rgba(148,163,184,.09)}
.pm-meta-label{font-size:.72rem;color:#94a3b8;font-weight:600}
.pm-meta-value{margin-top:3px;font-size:.88rem;font-weight:750;overflow-wrap:anywhere}
.pm-budget-form{display:flex;flex-wrap:wrap;gap:7px;margin-top:10px}
.pm-budget-form input{width:100px;max-width:100%;min-width:0;background:#080d19;border:1px solid #334155;border-radius:8px;padding:8px 9px;color:#f8fafc}
.pm-mini-btn{border-radius:8px;padding:8px 10px;font-size:.76rem;font-weight:700;transition:.18s}
.pm-progress{margin-top:7px}
.pm-progress-top{display:flex;align-items:center;justify-content:space-between;gap:10px;font-size:.78rem;color:#94a3b8;margin-bottom:8px}
.pm-progress-track{height:6px;overflow:hidden;background:#0b1220;border-radius:99px;border:1px solid rgba(148,163,184,.1)}
.pm-progress-fill{height:100%;border-radius:99px;background:linear-gradient(90deg,#3b82f6,#22d3ee);transition:width .3s}
.pm-actions{display:flex;flex-wrap:wrap;gap:7px;margin-top:10px}
.pm-action{display:inline-flex;align-items:center;justify-content:center;gap:6px;border-radius:8px;padding:7px 10px;font-size:.82rem;font-weight:700;transition:.18s}
.pm-action:hover{filter:brightness(1.12);transform:translateY(-1px)}
.pm-upload{margin-top:18px;padding:16px;border:1px solid rgba(34,211,238,.18);border-radius:13px;background:rgba(8,145,178,.06)}
.pm-upload input[type=file]{width:100%;min-width:0;color:#cbd5e1;font-size:.8rem}
.pm-canvas{margin-top:10px;padding:10px;border-radius:10px;background:rgba(2,6,23,.24);border:1px solid rgba(148,163,184,.13)}
.pm-canvas textarea{min-height:58px;resize:vertical;line-height:1.45}
.pm-empty{padding:42px 20px;text-align:center;border:1px dashed rgba(148,163,184,.3);border-radius:18px;background:rgba(15,23,42,.5)}
.pm-flash{margin:18px auto 0;width:100%;padding:13px 16px;border-radius:12px;font-size:.9rem}
@media(max-width:1100px){.pm-stat-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.pm-workspace-grid{grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:12px}}
@media(max-width:760px){.pm-workspace-grid{grid-template-columns:minmax(0,1fr)}}
.pm-modal-backdrop{position:fixed;inset:0;z-index:10000;display:flex;align-items:center;justify-content:center;padding:18px;background:rgba(2,6,23,.78);backdrop-filter:blur(4px)}.pm-modal-backdrop[hidden]{display:none!important}.pm-modal{width:min(100%,480px);max-height:90vh;overflow-y:auto;border:1px solid #334155;border-radius:18px;background:#0f172a;padding:24px;box-shadow:0 24px 80px rgba(0,0,0,.5)}.pm-modal-close{width:34px;height:34px;border-radius:9px;background:#1e293b;color:#cbd5e1;font-size:25px;line-height:1}.pm-modal-close:hover{background:#334155;color:#fff}
@media(max-width:680px){.pm-stat-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:7px}.pm-stat{padding:9px}.pm-section-heading{align-items:flex-start;flex-direction:column}.pm-project-head{flex-direction:column}.pm-status{align-self:flex-start}.pm-meta-grid{gap:9px}.pm-container{padding-top:20px}.pm-actions>*{flex:1 1 140px}.pm-top-links{display:flex;flex-wrap:wrap}}
</style>

</head>

<body class="bg-slate-900 text-white">
 <div class="ds-shell ds-unified-shell">
<?php include "partial_nav.php"; ?>
<div class="ds-main ds-unified-main">


<!-- ===================================
HEADER
=================================== -->

<header class="pm-header">
<div class="pm-container !py-5 flex flex-wrap justify-between items-center gap-5">

<div>

<h1 class="pm-page-title font-bold">

Project Management

</h1>

<p class="pm-subtitle">Plan projects, track deliverables, and collaborate with your team.</p>

</div>

<nav class="pm-top-links flex flex-wrap gap-2">
<a href="demo.php" class="pm-top-link"><i data-lucide="layout-dashboard" class="w-4 h-4"></i>Dashboard</a>
<a href="team.php" class="pm-top-link"><i data-lucide="users" class="w-4 h-4"></i>Team</a>
<a href="evaluation.php" class="pm-top-link"><i data-lucide="clipboard-check" class="w-4 h-4"></i>Evaluation</a>
</nav>

<?php if($__me): ?>
<div class="text-right text-sm">
<span class="text-slate-400"><?= htmlspecialchars($__me['username']) ?></span>
&middot;
</div>
<?php endif; ?>

</div>

</header>

<!-- ===================================
FLASH MESSAGE
=================================== -->

<main class="pm-container">

<?php if($flash): ?>

<div class="pm-flash <?= $flash['type']=="success" ? "border border-emerald-500/30 bg-emerald-950 text-emerald-200" : ($flash['type']=="warning" ? "border border-amber-500/30 bg-amber-950 text-amber-200" : "border border-rose-500/30 bg-rose-950 text-rose-200") ?>">

<?= htmlspecialchars($flash['message']) ?>

</div>

<?php endif; ?>

<!-- ===================================
STATS
=================================== -->

<div class="pm-stat-grid">

<div class="pm-stat" style="--accent:rgba(59,130,246,.15)">

<div class="pm-stat-label">Projects

</div>

<div class="pm-stat-value text-blue-300">

<?= $totalProjects ?>

</div>

</div>

<div class="pm-stat" style="--accent:rgba(34,211,238,.14)">

<div class="pm-stat-label">Active

</div>

<div class="pm-stat-value text-cyan-300">

<?= $activeProjects ?>

</div>

</div>

<div class="pm-stat" style="--accent:rgba(250,204,21,.13)">

<div class="pm-stat-label">Completed

</div>

<div class="pm-stat-value text-yellow-300">

<?= $completedProjects ?>

</div>

</div>

<div class="pm-stat" style="--accent:rgba(168,85,247,.14)">

<div class="pm-stat-label">Budget

</div>

<div class="pm-stat-value text-purple-300">

&#8369;<?= number_format($displayStudioCash) ?>

</div>

</div>

</div>

<!-- Active and finished projects share a responsive two-column workspace. -->
<div class="pm-workspace-grid">
<section class="pm-workspace-column">
<div class="pm-section-heading">
<div><h2>Projects</h2><p>Your team’s project workspace and submission progress.</p></div>
<div class="flex flex-wrap items-center gap-3">
<button type="button" class="pm-create-btn" style="background:linear-gradient(135deg,#2563eb,#4f46e5)" onclick="openAssignWorkerModal('view-workers-modal')"><i data-lucide="users" class="w-5 h-5"></i>View Workers</button>
<?php if ($isBusinessOwner): ?>
<a href="new_project.php" class="pm-create-btn"><i data-lucide="plus" class="w-5 h-5"></i>Create New Project</a>
<?php endif; ?>
</div>
</div>
<div id="view-workers-modal" class="pm-modal-backdrop" hidden onclick="if(event.target===this) closeAssignWorkerModal(this.id)">
  <div class="pm-modal" role="dialog" aria-modal="true" aria-labelledby="view-workers-title" style="width:min(100%,560px)">
    <div class="flex items-start justify-between gap-4 mb-5">
      <div><h3 id="view-workers-title" class="text-xl font-bold text-white">Workers in Your Business</h3><p class="mt-1 text-sm text-slate-400">Hired workers connected to this business.</p></div>
      <button type="button" class="pm-modal-close" aria-label="Close" onclick="closeAssignWorkerModal('view-workers-modal')">&times;</button>
    </div>
    <?php if ($studioWorkersForPopup): ?>
      <div class="space-y-2">
      <?php foreach ($studioWorkersForPopup as $studioWorker): ?>
        <div class="flex items-center gap-3 rounded-xl border border-slate-700 bg-slate-800/70 p-3">
          <div class="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-blue-500/15 text-blue-300"><i data-lucide="user-round" class="h-5 w-5"></i></div>
          <div class="min-w-0 flex-1"><p class="font-semibold text-white"><?= htmlspecialchars((string)$studioWorker['username']) ?></p><p class="text-xs capitalize text-slate-400"><?= htmlspecialchars((string)$studioWorker['employment_role']) ?></p>
            <?php if (!empty($studioWorker['active_project_titles'])): ?><p class="mt-1 text-xs text-amber-300">Assigned to: <?= htmlspecialchars((string)$studioWorker['active_project_titles']) ?></p><?php else: ?><p class="mt-1 text-xs text-emerald-300">Available for a project</p><?php endif; ?>
          </div>
          <?php if (!empty($studioWorker['active_project_titles'])): ?><span class="rounded-full border border-amber-500/30 bg-amber-500/10 px-2.5 py-1 text-xs text-amber-300">Busy</span><?php else: ?><span class="rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2.5 py-1 text-xs text-emerald-300">Available</span><?php endif; ?>
        </div>
      <?php endforeach; ?>
      </div>
    <?php else: ?>
      <div class="rounded-xl border border-slate-700 bg-slate-800/60 p-6 text-center"><i data-lucide="users" class="mx-auto mb-3 h-8 w-8 text-slate-500"></i><p class="font-semibold text-slate-200">No hired workers yet</p><p class="mt-1 text-sm text-slate-400">Workers who join and are approved for this business will appear here.</p></div>
    <?php endif; ?>
    <div class="mt-5 flex justify-end"><button type="button" class="pm-action bg-slate-700 hover:bg-slate-600" onclick="closeAssignWorkerModal('view-workers-modal')">Close</button></div>
  </div>
</div>
<?php $activeProjectsForDisplay = array_values(array_filter($projects, static fn($p) => !in_array(strtolower((string)($p['status'] ?? '')), ['completed','missed deadline'], true))); ?>
<?php if(count($activeProjectsForDisplay)==0): ?>
<div class="pm-empty"><div class="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-slate-800 text-blue-300"><i data-lucide="folder-open" class="h-7 w-7"></i></div><h3 class="text-lg font-bold">No projects yet</h3><p class="mx-auto mt-2 max-w-md text-sm leading-6 text-slate-400">Projects posted by your studio owner will appear here. Create a project to start organizing deliverables and team submissions.</p><?php if ($isBusinessOwner): ?><a href="new_project.php" class="pm-create-btn mt-5">Create your first project</a><?php endif; ?></div>
<?php else: ?>
<div class="pm-project-grid">
<?php foreach($activeProjectsForDisplay as $project): ?>

<article class="pm-project-card pm-active-project-card">
<details class="pm-active-project-details">
<summary class="pm-active-project-summary">
<div class="pm-project-head">

<div>

<h3 class="pm-project-title">

<?= htmlspecialchars($project['title']) ?>

</h3>

<p class="pm-project-description">

<?= htmlspecialchars($project['description']) ?>

</p>

</div>

<span class="pm-status">

<?= $project['status'] ?>

</span>

</div>
<span class="pm-expand-label"><span class="pm-expand-closed">Expand ＋</span><span class="pm-expand-open">Collapse −</span></span>
</summary>
<div class="pm-active-project-content">
<div class="pm-meta-grid">

<div>

<div class="pm-meta-label">

Progress

</div>

<div class="pm-meta-value text-cyan-300">

<?= $project['progress'] ?>%

</div>

</div>

<div>

<div class="pm-meta-label">

Budget

</div>

<div class="pm-meta-value text-green-300">
&#8369;<?= number_format($project['budget']) ?>
</div>
<p class="mt-2 text-xs text-slate-400">Fixed project budget</p>

</div>

<div>

<div class="pm-meta-label">

Deadline

</div>

<?php $projectDeadlineTs = !empty($project['deadline_at']) ? strtotime((string)$project['deadline_at']) : (!empty($project['deadline_started_at']) ? (strtotime((string)$project['deadline_started_at']) + ((int)$project['deadline'] * 86400)) : 0); $projectSecondsLeft = $projectDeadlineTs - time(); ?>
<div class="pm-meta-value <?= $projectSecondsLeft <= 86400 ? 'text-amber-300' : 'text-slate-100' ?>">
<?= $projectDeadlineTs ? 'Due '.htmlspecialchars(date('M j, Y g:i A', $projectDeadlineTs)) : ((int)$project['deadline'].' day(s) total') ?>
</div>
<p class="mt-1 text-xs <?= $projectSecondsLeft <= 86400 ? 'text-amber-300' : 'text-slate-400' ?>">
<?php if ($projectSecondsLeft > 86400): ?><?= (int)floor($projectSecondsLeft / 86400) ?> day(s), <?= (int)floor(($projectSecondsLeft % 86400) / 3600) ?> hour(s) remaining<?php elseif ($projectSecondsLeft > 0): ?><?= (int)floor($projectSecondsLeft / 3600) ?>h <?= (int)floor(($projectSecondsLeft % 3600) / 60) ?>m remaining<?php else: ?>Deadline passed — closing project<?php endif; ?>
</p>

</div>

<div>

<div class="pm-meta-label">

Priority

</div>

<div class="pm-meta-value text-yellow-300">

<?= $project['priority'] ?>

</div>

</div>

<div>

<div class="pm-meta-label">

Risk

</div>

<div class="pm-meta-value text-rose-300">

<?= $project['risk'] ?>

</div>

</div>

</div>

<div class="pm-progress">
<div class="pm-progress-top"><span>Overall progress</span><strong class="text-slate-200"><?= (int)$project['progress'] ?>%</strong></div>
<div class="pm-progress-track">

<div class="pm-progress-fill" style="width:<?= max(0,min(100,(int)$project['progress'])) ?>%"></div>
</div>
</div>

<?php
$assignedWorkers = [];
$assignedQuery = $conn->prepare("SELECT u.id, u.username FROM project_worker_assignments pwa JOIN users u ON u.id=pwa.worker_id WHERE pwa.project_id=? ORDER BY u.username ASC");
$assignedProjectId = (int)$project['id'];
if ($assignedQuery) { $assignedQuery->bind_param('i', $assignedProjectId); $assignedQuery->execute(); $assignedWorkers = $assignedQuery->get_result()->fetch_all(MYSQLI_ASSOC); }
$currentWorkerAssigned = !$isWorker;
if ($isWorker) {
    foreach ($assignedWorkers as $assignedWorker) {
        if ((int)$assignedWorker['id'] === (int)($__projectUser['id'] ?? 0)) { $currentWorkerAssigned = true; break; }
    }
}
?>
<?php if ($assignedWorkers): ?><div class="mt-3 mb-2 text-sm text-slate-300"><span class="font-semibold text-slate-200">Assigned worker<?= count($assignedWorkers) === 1 ? '' : 's' ?>:</span> <?= htmlspecialchars(implode(', ', array_column($assignedWorkers, 'username'))) ?></div><?php elseif ($isBusinessOwner): ?><div class="mt-3 mb-2 text-xs text-amber-300">No worker assigned yet.</div><?php endif; ?>
<div class="pm-actions">
<?php if ($isBusinessOwner): ?>

<button type="button" class="pm-action bg-indigo-600 hover:bg-indigo-500" onclick="openAssignWorkerModal('assign-worker-modal-<?= (int)$project['id'] ?>')">Assign Worker</button>
<?php if (!in_array(strtolower((string)($project['status'] ?? '')), ['completed','pending review'], true) && ($isWorker || $isBusinessOwner)): ?>
<button type="button" class="pm-action bg-cyan-600 hover:bg-cyan-500" onclick="const d=document.getElementById('project-work-<?= (int)$project['id'] ?>'); if(d){d.open=true; d.scrollIntoView({behavior:'smooth',block:'center'}); const f=d.querySelector('input[type=file]'); if(f) setTimeout(()=>f.focus(),350);}">Submit File</button>
<?php endif; ?>
<?php endif; ?>
</div>
<?php if ($isBusinessOwner): ?>
<div id="assign-worker-modal-<?= (int)$project['id'] ?>" class="pm-modal-backdrop" hidden onclick="if(event.target===this) closeAssignWorkerModal(this.id)">
  <div class="pm-modal" role="dialog" aria-modal="true" aria-labelledby="assign-worker-title-<?= (int)$project['id'] ?>">
    <div class="flex items-start justify-between gap-4 mb-4">
      <div><h3 id="assign-worker-title-<?= (int)$project['id'] ?>" class="text-xl font-bold text-white">Assign Worker</h3><p class="mt-1 text-sm text-slate-400">Choose an available hired worker for <strong class="text-slate-200"><?= htmlspecialchars((string)$project['title']) ?></strong>. Workers assigned to unfinished projects are excluded.</p></div>
      <button type="button" class="pm-modal-close" aria-label="Close" onclick="closeAssignWorkerModal('assign-worker-modal-<?= (int)$project['id'] ?>')">&times;</button>
    </div>
    <?php if ($assignableWorkers): ?>
    <form method="post" class="space-y-4"><?= appCsrfField() ?><input type="hidden" name="action" value="assign_worker"><input type="hidden" name="id" value="<?= (int)$project['id'] ?>">
      <label for="assign-worker-select-<?= (int)$project['id'] ?>" class="block text-sm font-semibold text-slate-200">Your hired workers</label>
      <select id="assign-worker-select-<?= (int)$project['id'] ?>" name="worker_id" required class="w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-3 text-white"><option value="">Select a worker…</option><?php foreach ($assignableWorkers as $assignableWorker): ?><option value="<?= (int)$assignableWorker['id'] ?>"><?= htmlspecialchars((string)$assignableWorker['username']) ?></option><?php endforeach; ?></select>
      <div class="flex flex-wrap justify-end gap-2"><button type="button" class="pm-action bg-slate-700 hover:bg-slate-600" onclick="closeAssignWorkerModal('assign-worker-modal-<?= (int)$project['id'] ?>')">Cancel</button><button type="submit" class="pm-action bg-indigo-600 hover:bg-indigo-500">Assign to Project</button></div>
    </form>
    <?php else: ?><div class="rounded-lg border border-amber-500/30 bg-amber-950/30 p-4 text-sm text-amber-200">You don't have any available workers right now. Workers already assigned to unfinished projects cannot be assigned again. They will become available when their projects are completed.</div><div class="mt-4 flex justify-end"><button type="button" class="pm-action bg-slate-700 hover:bg-slate-600" onclick="closeAssignWorkerModal('assign-worker-modal-<?= (int)$project['id'] ?>')">Close</button></div><?php endif; ?>
  </div>
</div>
<?php endif; ?>
<?php
$conn->query("CREATE TABLE IF NOT EXISTS project_canvas (project_id INT PRIMARY KEY, content MEDIUMTEXT NOT NULL, updated_by INT NULL, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$canvasStmt = $conn->prepare("SELECT content, updated_at FROM project_canvas WHERE project_id=?");
$canvasProjectId = (int)$project['id']; $canvasStmt->bind_param('i', $canvasProjectId); $canvasStmt->execute(); $canvasData = $canvasStmt->get_result()->fetch_assoc() ?: ['content'=>'','updated_at'=>null];
?>
<details id="project-work-<?= (int)$project['id'] ?>" class="pm-canvas"><summary class="cursor-pointer flex flex-wrap items-center justify-between gap-2 font-bold"><span>Project Work &amp; Notes</span><span class="text-xs font-normal text-slate-400">Click to expand</span></summary><p class="text-xs text-slate-400 mt-2 mb-3">Add final notes and attach the completed work. Submissions are reviewed by the Owner/Manager. Points are awarded only after approval.</p>
<?php if ($isWorker && !$currentWorkerAssigned): ?>
<p class="mt-3 rounded-lg border border-amber-500/30 bg-amber-950/30 p-4 text-sm text-amber-200">Your not assign to this Project</p>
<?php elseif (($isWorker || $isBusinessOwner) && !in_array(strtolower((string)($project['status'] ?? '')), ['completed','pending review'], true)): ?>
<form method="post" enctype="multipart/form-data" class="space-y-3"><?= appCsrfField() ?><input type="hidden" name="action" value="submit_file"><input type="hidden" name="id" value="<?= (int)$project['id'] ?>"><textarea name="canvas_content" rows="3" class="w-full rounded-lg bg-slate-900 border border-slate-700 p-3 text-slate-100" placeholder="Add notes about your completed work (optional)..."><?= htmlspecialchars($canvasData['content']) ?></textarea><div class="space-y-2"><label class="block text-sm font-semibold" for="submission-<?= (int)$project['id'] ?>">Choose file to submit</label><input id="submission-<?= (int)$project['id'] ?>" type="file" name="submission_file" required accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.zip,.txt,.png,.jpg,.jpeg" class="block w-full max-w-full text-sm text-slate-300"><p class="text-xs text-slate-400">PDF, Office documents, ZIP, TXT, or images · 10 MB maximum</p></div><div class="flex flex-wrap justify-between items-center gap-3"><span class="text-xs text-slate-500"><?= $canvasData['updated_at'] ? 'Last notes saved: '.htmlspecialchars($canvasData['updated_at']) : 'Notes will be saved with your submission' ?></span><button type="submit" class="pm-action bg-emerald-600 hover:bg-emerald-500">Submit Work for Review</button></div></form>
<?php elseif ($isBusinessOwner): ?>
<form method="post" class="space-y-2"><?= appCsrfField() ?><input type="hidden" name="action" value="save_canvas"><input type="hidden" name="id" value="<?= (int)$project['id'] ?>"><textarea name="canvas_content" rows="3" class="w-full rounded-lg bg-slate-900 border border-slate-700 p-3 text-slate-100" placeholder="Write shared project notes here..."><?= htmlspecialchars($canvasData['content']) ?></textarea><div class="flex justify-between items-center gap-3"><span class="text-xs text-slate-500"><?= $canvasData['updated_at'] ? 'Last saved: '.htmlspecialchars($canvasData['updated_at']) : 'Not saved yet' ?></span><button type="submit" class="pm-action bg-indigo-600 hover:bg-indigo-500">Save Notes</button></div></form>
<?php elseif (strtolower((string)($project['status'] ?? '')) === 'completed'): ?><p class="text-sm text-emerald-300 mt-3">This project is completed. See the completion credit below.</p><?php endif; ?></details>
<?php
$submissionStmt = $conn->prepare("SELECT ps.id, ps.original_name, ps.submitted_at, ps.review_status, ps.review_feedback, u.username FROM project_submissions ps JOIN users u ON u.id=ps.user_id WHERE ps.project_id=? ORDER BY ps.submitted_at DESC LIMIT 5");
$submissionProjectId = (int)$project['id'];
$submissionStmt->bind_param('i', $submissionProjectId);
$submissionStmt->execute();
$projectSubmissions = $submissionStmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>
<?php if ($projectSubmissions): ?>
<div class="mt-4 border-t border-slate-700 pt-4"><h4 class="font-semibold mb-2">Submitted Files &amp; Review</h4><p class="text-xs text-slate-400 mb-2">Points are awarded only after an Owner/Manager approves a submission.</p><?php foreach ($projectSubmissions as $submission): $reviewStatus = (string)($submission['review_status'] ?? 'pending_review'); ?><div class="my-3 rounded-lg border border-slate-700 bg-slate-900/60 p-3"><div class="flex flex-wrap items-center gap-2 text-sm text-slate-300"><strong><?= htmlspecialchars($submission['username']) ?></strong> submitted <a class="text-cyan-400 hover:underline" href="download_submission.php?id=<?= (int)$submission['id'] ?>"><?= htmlspecialchars($submission['original_name']) ?></a><span class="rounded-full px-2 py-1 text-xs <?= $reviewStatus === 'approved' ? 'bg-emerald-500/15 text-emerald-300' : ($reviewStatus === 'revision_required' ? 'bg-amber-500/15 text-amber-300' : ($reviewStatus === 'rejected' ? 'bg-rose-500/15 text-rose-300' : 'bg-sky-500/15 text-sky-300')) ?>"><?= htmlspecialchars(ucwords(str_replace('_',' ',$reviewStatus))) ?></span><span class="text-slate-500">· <?= htmlspecialchars($submission['submitted_at']) ?></span></div><?php if (!empty($submission['review_feedback'])): ?><p class="mt-2 text-sm text-amber-200">Review note: <?= htmlspecialchars($submission['review_feedback']) ?></p><?php endif; ?><?php if ($isBusinessOwner && !in_array($reviewStatus, ['approved','rejected'], true)): ?><form method="post" class="mt-3 space-y-2"><?= appCsrfField() ?><input type="hidden" name="id" value="<?= (int)$project['id'] ?>"><input type="hidden" name="submission_id" value="<?= (int)$submission['id'] ?>"><textarea name="review_feedback" rows="2" class="w-full rounded-lg bg-slate-950 border border-slate-700 p-2 text-sm text-slate-100" placeholder="Optional note, or explain what needs revision"></textarea><div class="flex flex-wrap gap-2"><button name="action" value="approve_submission" class="pm-action bg-emerald-600 hover:bg-emerald-500">Approve &amp; Award Point</button><button name="action" value="request_revision" class="pm-action bg-amber-600 hover:bg-amber-500">Request Revision</button><button name="action" value="reject_submission" class="pm-action bg-rose-700 hover:bg-rose-600">Reject</button></div></form><?php endif; ?></div><?php endforeach; ?></div>
<?php else: ?>
<div class="mt-4 border-t border-slate-700 pt-4"><h4 class="font-semibold mb-1">Saved Project Files</h4><p class="text-sm text-slate-400">No files submitted yet. Submitted files will appear here for the project team.</p></div>
<?php endif; ?>
</div>
</details>
</article>

<?php endforeach; ?>

</div>
<?php endif; ?>
</section>

<?php $completedProjectsForDisplay = array_values(array_filter($projects, static fn($p) => in_array(strtolower((string)($p['status'] ?? '')), ['completed','missed deadline'], true))); ?>
<?php if ($completedProjectsForDisplay): ?>
<section class="pm-workspace-column">
  <div class="pm-section-heading"><div><h2>Finished Projects</h2><p>Completed submissions and the person who finished each project.</p></div></div>
  <div class="pm-project-grid">
  <?php foreach ($completedProjectsForDisplay as $finishedProject):
    $finishStmt = $conn->prepare("SELECT pc.user_id, pc.points_awarded, pc.completed_at, u.username FROM project_completions pc JOIN users u ON u.id=pc.user_id WHERE pc.project_id=? LIMIT 1");
    $finishedId = (int)$finishedProject['id']; $finishStmt->bind_param('i', $finishedId); $finishStmt->execute(); $finishInfo = $finishStmt->get_result()->fetch_assoc();
  ?>
    <article class="pm-project-card pm-finished-project-card <?= strtolower((string)($finishedProject['status'] ?? '')) === 'missed deadline' ? 'pm-missed-deadline-card' : '' ?>">
      <details class="pm-finished-project-details">
        <summary class="pm-finished-project-summary">
          <div class="min-w-0 flex-1">
            <div class="flex flex-wrap items-center gap-2"><h3 class="pm-project-title"><?= htmlspecialchars($finishedProject['title']) ?></h3><?php if (strtolower((string)($finishedProject['status'] ?? '')) === 'missed deadline'): ?><span class="pm-status pm-missed-deadline">Missed Deadline</span><?php else: ?><span class="pm-status">Completed</span><?php endif; ?></div>
            <p class="pm-project-description mt-1"><?= htmlspecialchars($finishedProject['description']) ?></p>
          </div>
          <span class="pm-expand-label"><span class="pm-expand-closed">View details ＋</span><span class="pm-expand-open">Hide details −</span></span>
        </summary>
        <div class="pm-finished-project-content">
          <?php $finishSubStmt = $conn->prepare("SELECT id, original_name, submitted_at FROM project_submissions WHERE project_id=? ORDER BY submitted_at DESC LIMIT 5"); $finishSubStmt->bind_param('i', $finishedId); $finishSubStmt->execute(); $finishFiles = $finishSubStmt->get_result()->fetch_all(MYSQLI_ASSOC); ?>
          <?php if (strtolower((string)($finishedProject['status'] ?? '')) === 'missed deadline'): ?>
          <div class="pm-missed-deadline-banner">MISSED DEADLINE — Automatically closed because no work was submitted before the deadline. No completion points were awarded.</div>
          <?php else: ?>
          <div class="mt-3 rounded-lg border border-emerald-500/20 bg-emerald-950/30 p-3 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div class="min-w-0">
              <p class="font-semibold text-emerald-300">Done by <?= htmlspecialchars($finishInfo['username'] ?? 'Unknown teammate') ?></p>
              <p class="mt-1 text-xs text-slate-400"><?= !empty($finishInfo['completed_at']) ? 'Completed '.htmlspecialchars($finishInfo['completed_at']) : 'Completion date unavailable' ?> · <?= (int)($finishInfo['points_awarded'] ?? 0) ?> point<?= (int)($finishInfo['points_awarded'] ?? 0) === 1 ? '' : 's' ?> earned</p>
              <?php if (!$finishFiles): ?><p class="mt-2 text-xs text-slate-400">No files were attached to this finished project.</p><?php endif; ?>
            </div>
            <?php if ($finishFiles): ?>
              <div class="flex shrink-0 flex-col items-stretch gap-2 sm:items-end">
                <?php foreach ($finishFiles as $finishFile): ?>
                  <div class="flex items-center justify-end gap-2">
                    <span class="mr-1 max-w-[180px] truncate text-xs text-slate-300" title="<?= htmlspecialchars($finishFile['original_name']) ?>"><?= htmlspecialchars($finishFile['original_name']) ?></span>
                    <a class="inline-flex items-center justify-center rounded-md border border-cyan-500/40 px-3 py-2 text-xs font-semibold text-cyan-300 transition hover:bg-cyan-500/10" href="view_submission.php?id=<?= (int)$finishFile['id'] ?>" target="_blank" rel="noopener">View</a>
                    <a class="inline-flex items-center justify-center rounded-md bg-cyan-600 px-3 py-2 text-xs font-semibold text-white transition hover:bg-cyan-500" href="download_submission.php?id=<?= (int)$finishFile['id'] ?>">Download</a>
                  </div>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>
          </div>
          <?php endif; ?>
        </div>
      </details>
    </article>
  <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>
</div>
</main>

<script>
function openAssignWorkerModal(id){const modal=document.getElementById(id);if(!modal)return;modal.hidden=false;document.body.style.overflow='hidden';const select=modal.querySelector('select');if(select)setTimeout(()=>select.focus(),50);}
function closeAssignWorkerModal(id){const modal=document.getElementById(id);if(!modal)return;modal.hidden=true;document.body.style.overflow='';}
document.addEventListener('keydown',function(event){if(event.key==='Escape'){document.querySelectorAll('.pm-modal-backdrop:not([hidden])').forEach(function(modal){closeAssignWorkerModal(modal.id);});}});
lucide.createIcons();
</script>

</div></div>
</body>

</html>
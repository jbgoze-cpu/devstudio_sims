-- Worker skill-training catalogue for DEVSTUDIO SIMS
CREATE TABLE IF NOT EXISTS worker_training_courses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(150) NOT NULL,
  description TEXT NOT NULL,
  skill_name VARCHAR(100) NOT NULL,
  duration_hours INT NOT NULL DEFAULT 1,
  website_url VARCHAR(500) NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS worker_training_enrollments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  course_id INT NOT NULL,
  selected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY unique_user_course (user_id, course_id),
  CONSTRAINT fk_training_course FOREIGN KEY (course_id) REFERENCES worker_training_courses(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO worker_training_courses (title, description, skill_name, duration_hours) VALUES
('Web Development Fundamentals','Learn the basics of HTML, CSS, responsive layouts, and website structure.','Web Development',4),
('PHP and Database Basics','Practice PHP forms, safe database queries, and CRUD operations.','Backend Development',5),
('UI/UX Design Essentials','Learn wireframes, user flows, accessibility, and interface prototyping.','UI/UX Design',3),
('Software Quality Assurance','Practice test cases, bug reports, and regression testing.','Quality Assurance',3),
('Git and Team Collaboration','Learn version control, branches, commits, and pull requests.','Collaboration',2),
('Cybersecurity Awareness','Learn secure passwords, common web risks, and safe data handling.','Cybersecurity',2)
ON DUPLICATE KEY UPDATE description=VALUES(description);

-- Topic-specific official learning websites
UPDATE worker_training_courses SET website_url = CASE title
  WHEN 'Web Development Fundamentals' THEN 'https://developer.mozilla.org/en-US/docs/Learn'
  WHEN 'PHP and Database Basics' THEN 'https://www.php.net/manual/en/'
  WHEN 'UI/UX Design Essentials' THEN 'https://help.figma.com/hc/en-us/categories/360002051613-Get-started'
  WHEN 'Software Quality Assurance' THEN 'https://www.atlassian.com/software-testing'
  WHEN 'Git and Team Collaboration' THEN 'https://skills.github.com/'
  WHEN 'Cybersecurity Awareness' THEN 'https://www.cisa.gov/secure-our-world'
  ELSE website_url END
WHERE website_url IS NULL OR website_url = '';

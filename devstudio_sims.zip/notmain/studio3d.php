<?php
session_start();
require_once "db.php";
require_once "simulation_helpers.php";

requireLogin();

/*======================================
    3D STUDIO VIEW
    A live scene built from real game
    state: desks = employees, tower
    height = cash tier, orbiting
    trophies = achievements, light
    warmth = morale, beacons = projects
    coloured by risk.
======================================*/

$game = getGameState();
$employees = getEmployees();
$projects = getProjects();
$team = teamStatistics();
$viewer = currentUser();
$studioOwnerId = (int)(function_exists('currentBusinessOwnerId') ? (currentBusinessOwnerId() ?? 0) : 0);
$simState = $studioOwnerId > 0 ? simState($studioOwnerId) : ['points'=>0];
$studioBusinessRole = businessRoleForUser($conn, $viewer);
$canSeeStudioCash = in_array($studioBusinessRole, ['owner','manager'], true);
$studioCash = ($canSeeStudioCash && $studioOwnerId > 0) ? simCash($studioOwnerId) : 0;
$achievementRows = [];
if ($studioOwnerId > 0) {
    $achievementStmt = $conn->prepare("SELECT COUNT(*) total FROM simulation_business_achievements WHERE owner_id=?");
    if ($achievementStmt) {
        $achievementStmt->bind_param('i', $studioOwnerId);
        $achievementStmt->execute();
        $achievementRows = $achievementStmt->get_result()->fetch_assoc() ?: [];
        $achievementStmt->close();
    }
}

// Owner-only studio progression: quests reward XP once per business milestone.
$conn->query("CREATE TABLE IF NOT EXISTS simulation_studio_quest_claims (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    owner_id INT NOT NULL,
    quest_key VARCHAR(60) NOT NULL,
    xp_awarded INT UNSIGNED NOT NULL DEFAULT 0,
    claimed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_studio_owner_quest (owner_id, quest_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
// Persistent Studio Coins and purchased items for each business owner.
$conn->query("CREATE TABLE IF NOT EXISTS simulation_studio_wallets (
    owner_id INT NOT NULL PRIMARY KEY,
    coins INT UNSIGNED NOT NULL DEFAULT 0,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$conn->query("CREATE TABLE IF NOT EXISTS simulation_studio_inventory (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    owner_id INT NOT NULL,
    item_key VARCHAR(60) NOT NULL,
    purchased_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_studio_owner_item (owner_id, item_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$isStudioOwner = (($viewer['role'] ?? '') === 'owner' && $studioOwnerId > 0);
$studioShopItems = [
    'plant' => ['name'=>'Studio Plant','description'=>'A leafy decoration for your headquarters grounds.','price'=>60,'icon'=>'🌿','type'=>'decoration','location'=>'outside'],
    'neon_sign' => ['name'=>'Neon Studio Sign','description'=>'A glowing sign for your headquarters exterior.','price'=>120,'icon'=>'💡','type'=>'decoration','location'=>'outside'],
    'workstation' => ['name'=>'Pro Workstation','description'=>'A premium workstation display.','price'=>180,'icon'=>'🖥️','type'=>'decoration','location'=>'outside','level'=>2],
    'gold_theme' => ['name'=>'Golden HQ Theme','description'=>'Give your headquarters a gold finish.','price'=>250,'icon'=>'✨','type'=>'theme','location'=>'outside','level'=>3],
    'fountain' => ['name'=>'Mini Fountain','description'=>'A fountain feature for your studio grounds.','price'=>350,'icon'=>'⛲','type'=>'decoration','location'=>'outside','level'=>4],
    'trophy_case' => ['name'=>'Trophy Display','description'=>'Show off your first team milestone.','price'=>200,'icon'=>'🏆','type'=>'decoration','location'=>'outside','unlock'=>'first_employee'],
    'rooftop_garden' => ['name'=>'Rooftop Garden','description'=>'Add a green rooftop feature to your headquarters.','price'=>260,'icon'=>'🌳','type'=>'decoration','location'=>'outside','unlock'=>'first_project'],
    'satellite_dish' => ['name'=>'Satellite Dish','description'=>'A high-tech communications upgrade.','price'=>320,'icon'=>'🛰️','type'=>'decoration','location'=>'outside','unlock'=>'first_decision'],
    'crystal_trophy' => ['name'=>'Crystal Achievement Award','description'=>'A premium outdoor achievement sculpture.','price'=>400,'icon'=>'💎','type'=>'decoration','location'=>'outside','unlock'=>'first_achievement'],
    'executive_lounge' => ['name'=>'Executive Lounge','description'=>'A lounge feature for the headquarters grounds.','price'=>500,'icon'=>'🛋️','type'=>'decoration','location'=>'outside','unlock'=>'team_of_three'],
    'meeting_table' => ['name'=>'Boardroom Table','description'=>'A polished meeting table for the office interior.','price'=>220,'icon'=>'🪑','type'=>'decoration','location'=>'inside','unlock'=>'first_project'],
    'coffee_corner' => ['name'=>'Coffee Corner','description'=>'A coffee station for quick team breaks.','price'=>160,'icon'=>'☕','type'=>'decoration','location'=>'inside'],
    'server_rack' => ['name'=>'Server Rack','description'=>'A glowing server rack for your tech office.','price'=>380,'icon'=>'🗄️','type'=>'decoration','location'=>'inside','unlock'=>'first_decision'],
    'wall_art' => ['name'=>'Modern Wall Art','description'=>'A colorful feature wall for the office.','price'=>140,'icon'=>'🖼️','type'=>'decoration','location'=>'inside','level'=>2],
    'floor_lamp' => ['name'=>'Designer Floor Lamp','description'=>'Warm lighting beside the lounge area.','price'=>110,'icon'=>'💡','type'=>'decoration','location'=>'inside','level'=>2],
    'office_sofa' => ['name'=>'Office Sofa','description'=>'A comfortable sofa for the reception.','price'=>240,'icon'=>'🛋️','type'=>'decoration','location'=>'inside','unlock'=>'first_employee'],
    'line_lighting' => ['name'=>'LED Line Lighting','description'=>'Install sleek glowing LED strips along the office ceiling and walls.','price'=>290,'icon'=>'💡','type'=>'decoration','location'=>'inside','unlock'=>'first_project'],
    'garden_tree' => ['name'=>'Ornamental Tree','description'=>'A decorative tree for the headquarters grounds.','price'=>190,'icon'=>'🌲','type'=>'decoration','location'=>'outside','level'=>3],
    'flagpole' => ['name'=>'Company Flagpole','description'=>'Put your company colors on display outside.','price'=>280,'icon'=>'🚩','type'=>'decoration','location'=>'outside','unlock'=>'first_employee'],
    'parking_bay' => ['name'=>'Executive Parking Bay','description'=>'A marked parking bay outside your HQ.','price'=>300,'icon'=>'🚗','type'=>'decoration','location'=>'outside','unlock'=>'team_of_three'],
    'path_lights' => ['name'=>'Pathway Lights','description'=>'Light up the walkway around your headquarters.','price'=>210,'icon'=>'✨','type'=>'decoration','location'=>'outside','level'=>3],
];
if ($isStudioOwner) {
    $walletInit = $conn->prepare("INSERT IGNORE INTO simulation_studio_wallets (owner_id, coins) VALUES (?, 0)");
    if ($walletInit) { $walletInit->bind_param('i', $studioOwnerId); $walletInit->execute(); $walletInit->close(); }
}
$studioCoins = 0;
$ownedStudioItems = [];
if ($isStudioOwner) {
    $walletStmt = $conn->prepare("SELECT coins FROM simulation_studio_wallets WHERE owner_id=?");
    if ($walletStmt) { $walletStmt->bind_param('i', $studioOwnerId); $walletStmt->execute(); $walletStmt->bind_result($walletCoins); if ($walletStmt->fetch()) $studioCoins=(int)$walletCoins; $walletStmt->close(); }
    $inventoryStmt = $conn->prepare("SELECT item_key FROM simulation_studio_inventory WHERE owner_id=?");
    if ($inventoryStmt) { $inventoryStmt->bind_param('i', $studioOwnerId); $inventoryStmt->execute(); $inventoryResult=$inventoryStmt->get_result(); while ($inventoryRow=$inventoryResult->fetch_assoc()) $ownedStudioItems[]=$inventoryRow['item_key']; $inventoryStmt->close(); }
}
$activeEmployeeCount = count($employees);
$projectCount = count($projects);
$decisionCount = (int)($simState['decisions_made'] ?? 0);
$achievementCount = (int)($achievementRows['total'] ?? 0);
$studioQuests = [
    ['key'=>'first_employee','title'=>'Build your crew','description'=>'Have at least one active employee in your business.','xp'=>25,'done'=>$activeEmployeeCount >= 1],
    ['key'=>'first_project','title'=>'Launch a project','description'=>'Create your first business project.','xp'=>30,'done'=>$projectCount >= 1],
    ['key'=>'first_decision','title'=>'Make the call','description'=>'Record your first business decision.','xp'=>25,'done'=>$decisionCount >= 1],
    ['key'=>'first_achievement','title'=>'Earn a badge','description'=>'Unlock your first business achievement.','xp'=>40,'done'=>$achievementCount >= 1],
    ['key'=>'team_of_three','title'=>'Grow the crew','description'=>'Reach three active employees.','xp'=>50,'done'=>$activeEmployeeCount >= 3],
];
$claimedQuestKeys = [];
if ($studioOwnerId > 0) {
    $claimedStmt = $conn->prepare("SELECT quest_key FROM simulation_studio_quest_claims WHERE owner_id=?");
    if ($claimedStmt) {
        $claimedStmt->bind_param('i', $studioOwnerId);
        $claimedStmt->execute();
        $claimedResult = $claimedStmt->get_result();
        while ($claimedRow = $claimedResult->fetch_assoc()) $claimedQuestKeys[] = $claimedRow['quest_key'];
        $claimedStmt->close();
    }
}

if ($isStudioOwner && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['claim_studio_quest'])) {
    $postedToken = (string)($_POST['sim_csrf'] ?? '');
    if (!hash_equals((string)($_SESSION['sim_csrf'] ?? ''), $postedToken)) {
        $_SESSION['flash'] = ['message'=>'Security check failed. Please try again.','type'=>'error'];
    } else {
        $questKey = (string)$_POST['claim_studio_quest'];
        foreach ($studioQuests as $quest) {
            if ($quest['key'] !== $questKey) continue;
            if (!$quest['done']) {
                $_SESSION['flash'] = ['message'=>'Complete the quest requirement before claiming its XP.','type'=>'error'];
                break;
            }
            $claimStmt = $conn->prepare("INSERT IGNORE INTO simulation_studio_quest_claims (owner_id, quest_key, xp_awarded) VALUES (?,?,?)");
            $claimStmt->bind_param('isi', $studioOwnerId, $questKey, $quest['xp']);
            $claimStmt->execute();
            $claimedNow = $claimStmt->affected_rows > 0;
            $claimStmt->close();
            if ($claimedNow) {
                $xp = (int)$quest['xp'];
                $xpStmt = $conn->prepare("UPDATE simulation_business_state SET points=points+? WHERE owner_id=?");
                $xpStmt->bind_param('ii', $xp, $studioOwnerId);
                $xpStmt->execute();
                $xpStmt->close();
                $coinReward = max(10, (int)round($xp * 1.5));
                $coinStmt = $conn->prepare("UPDATE simulation_studio_wallets SET coins=coins+? WHERE owner_id=?");
                if ($coinStmt) { $coinStmt->bind_param('ii', $coinReward, $studioOwnerId); $coinStmt->execute(); $coinStmt->close(); }
                if (function_exists('simLog')) simLog($studioOwnerId, (int)($viewer['id'] ?? 0), 'achievement', 'Studio quest: '.$quest['title'], 'Claimed '.$xp.' XP and '.$coinReward.' Studio Coins for a business milestone.', 0, 0, 0, 0, $xp);
                $_SESSION['flash'] = ['message'=>'Quest completed! +'.$xp.' XP and +'.$coinReward.' Studio Coins earned.','type'=>'success'];
            } else {
                $_SESSION['flash'] = ['message'=>'You have already claimed this quest.','type'=>'info'];
            }
            break;
        }
    }
    header('Location: studio3d.php');
    exit;
}
$studioUnlockXP = (int)($simState['points'] ?? 0);
$studioUnlockLevel = max(1, (int)floor($studioUnlockXP / 100) + 1);

// Buy items with earned Studio Coins. Purchases are permanent and cannot be duplicated.
if ($isStudioOwner && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['buy_studio_item'])) {
    $postedToken = (string)($_POST['sim_csrf'] ?? '');
    $itemKey = (string)$_POST['buy_studio_item'];
    if (!hash_equals((string)($_SESSION['sim_csrf'] ?? ''), $postedToken)) {
        $_SESSION['flash'] = ['message'=>'Security check failed. Please try again.','type'=>'error'];
    } elseif (!isset($studioShopItems[$itemKey])) {
        $_SESSION['flash'] = ['message'=>'That studio item is not available.','type'=>'error'];
    } elseif (isset($studioShopItems[$itemKey]['unlock']) && !in_array($studioShopItems[$itemKey]['unlock'], $claimedQuestKeys, true)) {
        $_SESSION['flash'] = ['message'=>'Complete and claim the required Quest Board mission to unlock this item.','type'=>'error'];
    } elseif (isset($studioShopItems[$itemKey]['level']) && $studioUnlockLevel < (int)$studioShopItems[$itemKey]['level']) {
        $_SESSION['flash'] = ['message'=>'Reach Studio Level '.(int)$studioShopItems[$itemKey]['level'].' to unlock this item.','type'=>'error'];
    } else {
        $item = $studioShopItems[$itemKey];
        $conn->begin_transaction();
        try {
            $check = $conn->prepare("SELECT coins FROM simulation_studio_wallets WHERE owner_id=? FOR UPDATE");
            $check->bind_param('i', $studioOwnerId); $check->execute(); $check->bind_result($currentCoins); $hasWallet=$check->fetch(); $check->close();
            $ownedCheck = $conn->prepare("SELECT id FROM simulation_studio_inventory WHERE owner_id=? AND item_key=?");
            $ownedCheck->bind_param('is', $studioOwnerId, $itemKey); $ownedCheck->execute(); $ownedCheck->store_result(); $alreadyOwned=$ownedCheck->num_rows > 0; $ownedCheck->close();
            if ($alreadyOwned) {
                $_SESSION['flash'] = ['message'=>'You already own this item.','type'=>'info'];
            } elseif (!$hasWallet || (int)$currentCoins < (int)$item['price']) {
                $_SESSION['flash'] = ['message'=>'Not enough Studio Coins for this item yet.','type'=>'error'];
            } else {
                $deduct = $conn->prepare("UPDATE simulation_studio_wallets SET coins=coins-? WHERE owner_id=? AND coins>=?");
                $price=(int)$item['price']; $deduct->bind_param('iii', $price, $studioOwnerId, $price); $deduct->execute();
                if ($deduct->affected_rows === 1) {
                    $deduct->close();
                    $add = $conn->prepare("INSERT INTO simulation_studio_inventory (owner_id, item_key) VALUES (?,?)");
                    $add->bind_param('is', $studioOwnerId, $itemKey); $add->execute(); $add->close();
                    $_SESSION['flash'] = ['message'=>$item['name'].' purchased! It is now part of your studio.','type'=>'success'];
                } else { $deduct->close(); $_SESSION['flash'] = ['message'=>'Purchase could not be completed. Please try again.','type'=>'error']; }
            }
            $conn->commit();
        } catch (Throwable $e) {
            $conn->rollback();
            error_log('Studio shop purchase failed: '.$e->getMessage());
            $_SESSION['flash'] = ['message'=>'The purchase could not be completed. Please try again.','type'=>'error'];
        }
    }
    header('Location: studio3d.php');
    exit;
}

$studioXP = (int)($simState['points'] ?? 0);
$studioLevel = max(1, (int)floor($studioXP / 100) + 1);
$xpIntoLevel = $studioXP % 100;
$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

$sceneData = [
    "employees" => count($employees),
    "cash" => (int)$studioCash,
    "morale" => (int)($simState['morale'] ?? 0),
    "efficiency" => (int)($simState['efficiency'] ?? 0),
    "achievements" => (int)($achievementRows['total'] ?? 0),
    "level" => $studioLevel,
    "ownedItems" => $ownedStudioItems,
    "projects" => array_map(function ($p) {
        return ["risk" => $p['risk'], "progress" => intval($p['progress'])];
    }, array_slice($projects, 0, 12)),
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Studio (3D) | DEVSTUDIO SIMS</title>
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>
<link rel="stylesheet" href="assets/theme.css">
<style>
  html, body { height:100%; }
  body { overflow:hidden; }
  .ds-shell { height:100vh; min-height:0; overflow:hidden; }
  .ds-main.studio-main { width:0; max-width:none; min-width:0; height:100vh; overflow:hidden; box-sizing:border-box; padding:16px 22px; display:flex; flex-direction:column; gap:10px; }
  .studio-header { display:flex; align-items:center; justify-content:space-between; gap:14px; flex:0 0 auto; }
  .studio-title { margin:0; font-size:clamp(1.35rem,2vw,1.85rem); line-height:1.15; font-weight:800; }
  .studio-subtitle { margin:4px 0 0; color:#94a3b8; font-size:.8rem; }
  .studio-level-chip { display:flex; align-items:center; gap:12px; border:1px solid var(--line); background:var(--panel); border-radius:12px; padding:8px 12px; white-space:nowrap; font-size:.75rem; }
  .studio-level-chip span { color:#fbbf24; font-weight:800; } .studio-level-chip strong { font-size:1rem; }
  .studio-progression { flex:0 0 auto; padding:8px 12px; border:1px solid var(--line); background:var(--panel); border-radius:10px; }
  .studio-progress-top { display:flex; justify-content:space-between; gap:10px; color:#cbd5e1; font-size:.72rem; margin-bottom:6px; }
  .studio-progress-track { height:7px; border-radius:99px; overflow:hidden; background:#202938; }
  .studio-progress-track div { height:100%; border-radius:99px; background:linear-gradient(90deg,#38bdf8,#a78bfa); }
  .studio-flash { margin-top:5px; font-size:.72rem; color:#86efac; }
  .studio-workspace { flex:1 1 auto; min-height:0; display:grid; grid-template-columns:minmax(290px, .82fr) minmax(0, 1.45fr); gap:12px; }
  .studio-workspace.no-quests { grid-template-columns:minmax(0,1fr); }
  .studio-quest-panel, .studio-scene-panel { min-width:0; min-height:0; border:1px solid var(--line); border-radius:12px; background:var(--panel); padding:12px; }
  .studio-quest-panel { display:flex; flex-direction:column; overflow:hidden; }
  .studio-section-heading { display:flex; align-items:center; justify-content:space-between; gap:8px; padding-bottom:8px; border-bottom:1px solid var(--line); flex:0 0 auto; }
  .studio-section-heading h2 { margin:0; font-size:1.05rem; font-weight:800; }
  .studio-section-heading > span { color:#94a3b8; font-size:.68rem; white-space:nowrap; }
  .studio-quest-list { display:flex; flex-direction:column; min-height:0; }
  .studio-quest-row { display:flex; align-items:center; justify-content:space-between; gap:8px; padding:10px 0; border-bottom:1px solid var(--line); }
  .studio-quest-row:last-child { border-bottom:0; }
  .studio-quest-copy { min-width:0; }
  .studio-quest-title { display:flex; flex-wrap:wrap; align-items:center; gap:6px; font-size:.78rem; font-weight:750; }
  .studio-quest-title span { color:#fbbf24; font-size:.68rem; white-space:nowrap; }
  .studio-quest-copy p { margin:3px 0 0; color:#94a3b8; font-size:.68rem; line-height:1.3; }
  .studio-quest-action { flex:0 0 auto; }
  .studio-quest-action button { padding:6px 9px; border-radius:7px; background:#2563eb; color:white; font-size:.68rem; font-weight:750; }
  .studio-claimed, .studio-locked { font-size:.65rem; white-space:nowrap; }
  .studio-claimed { color:#86efac; } .studio-locked { color:#94a3b8; }
  .studio-scene-panel { display:flex; flex-direction:column; gap:9px; overflow:hidden; }
  .studio-scene-toolbar { display:flex; align-items:center; gap:7px; flex:0 0 auto; }
  .studio-scene-mode { border:1px solid var(--line); background:rgba(255,255,255,.035); color:#cbd5e1; border-radius:8px; padding:7px 12px; font-size:.72rem; font-weight:800; cursor:pointer; }
  .studio-scene-mode[aria-pressed="true"] { background:#2563eb; border-color:#3b82f6; color:#fff; box-shadow:0 0 0 1px rgba(59,130,246,.15) inset; }
  .studio-scene-mode-note { margin-left:auto; color:#94a3b8; font-size:.65rem; }
  .studio-stats { display:grid; grid-template-columns:repeat(3,minmax(0,1fr)); gap:8px; flex:0 0 auto; }
  .studio-stats > div { min-width:0; border:1px solid var(--line); border-radius:8px; padding:7px 10px; background:rgba(255,255,255,.02); }
  .studio-stats span { display:block; color:#94a3b8; font-size:.66rem; }
  .studio-stats strong { display:block; margin-top:2px; font-size:1rem; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
  #canvas-wrap { position:relative; flex:1 1 auto; min-height:0; width:100%; border-radius:8px; overflow:hidden; border:1px solid var(--line); background:radial-gradient(circle at 50% 20%,#1B2130,#0B0D13); }
  #canvas-wrap canvas { display:block; width:100%; height:100%; }
  .scene-hint { position:absolute; bottom:8px; left:8px; font-family:'IBM Plex Mono',monospace; font-size:.62rem; color:var(--text-muted); background:rgba(16,19,26,.72); padding:5px 7px; border-radius:4px; }
  .scene-loading { position:absolute; inset:0; display:flex; align-items:center; justify-content:center; font-family:'IBM Plex Mono',monospace; color:var(--text-muted); font-size:.85rem; }
  .studio-header-actions { display:flex; align-items:center; gap:8px; flex-wrap:wrap; justify-content:flex-end; }
  .studio-coin-chip,.studio-shop-open { display:flex; align-items:center; gap:7px; border:1px solid var(--line); background:var(--panel); border-radius:10px; padding:9px 12px; font-size:.76rem; white-space:nowrap; }
  .studio-coin-chip strong { color:#fbbf24; font-size:.95rem; }
  .studio-shop-open { background:#7c3aed; border-color:#8b5cf6; font-weight:800; cursor:pointer; }
  .studio-shop-overlay { position:fixed; inset:0; z-index:1000; display:flex; align-items:center; justify-content:center; padding:18px; background:rgba(3,7,18,.78); backdrop-filter:blur(6px); }
  .studio-shop-overlay[hidden] { display:none; }
  .studio-shop-modal { width:min(760px,100%); max-height:min(650px,calc(100vh - 36px)); overflow:auto; background:#111827; border:1px solid #374151; border-radius:16px; box-shadow:0 24px 80px rgba(0,0,0,.5); padding:18px; }
  .studio-shop-modal-head { display:flex; align-items:flex-start; gap:12px; padding-bottom:14px; border-bottom:1px solid #273244; }
  .studio-shop-modal-head h2 { margin:2px 0 0; font-size:1.35rem; font-weight:850; }
  .studio-shop-modal-head p,.studio-shop-note { margin:4px 0 0; color:#94a3b8; font-size:.75rem; }
  .studio-shop-balance { margin-left:auto; padding:8px 10px; border:1px solid #66521c; background:#292313; border-radius:9px; color:#fbbf24; font-weight:800; white-space:nowrap; }
  .studio-shop-close { border:0; background:transparent; color:#cbd5e1; font-size:1.7rem; line-height:1; cursor:pointer; padding:0 4px; }
  .studio-shop-tabs { display:flex; gap:8px; padding-top:14px; }
  .studio-shop-tab { flex:1; border:1px solid #334155; background:#172033; color:#cbd5e1; border-radius:9px; padding:9px 12px; font-size:.78rem; font-weight:800; cursor:pointer; }
  .studio-shop-tab.active { background:#4338ca; color:#fff; border-color:#6366f1; }
  .studio-shop-grid { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:10px; padding:10px 0; }
  .studio-shop-item[hidden] { display:none; }
  .studio-shop-item { display:flex; align-items:center; gap:10px; min-width:0; border:1px solid #2b3546; background:#151e2d; border-radius:12px; padding:11px; }
  .studio-shop-item-icon { display:grid; place-items:center; flex:0 0 42px; height:42px; border-radius:10px; background:#263247; font-size:1.4rem; }
  .studio-shop-item-copy { min-width:0; flex:1; }
  .studio-shop-item-copy strong { display:block; font-size:.78rem; }
  .studio-shop-item-copy .studio-shop-unlock-requirement { margin-top:6px; padding:6px 8px; border-radius:7px; border:1px solid rgba(251,191,36,.25); background:rgba(251,191,36,.07); color:#fbbf24; font-size:.72rem; line-height:1.4; }
  .studio-shop-item-copy .studio-shop-unlock-requirement strong { color:inherit; }
  .studio-shop-item-copy p { margin:3px 0; color:#94a3b8; font-size:.67rem; line-height:1.3; }
  .studio-shop-item-copy span { color:#fbbf24; font-size:.7rem; font-weight:750; }
  .studio-shop-item-action button { border:0; border-radius:7px; background:#2563eb; color:white; padding:7px 10px; font-size:.7rem; font-weight:800; cursor:pointer; }
  .studio-shop-item-action button:disabled { background:#374151; color:#9ca3af; cursor:not-allowed; }
  .studio-shop-note { padding-top:10px; border-top:1px solid #273244; }
  @media (max-width:1050px) { .ds-main.studio-main { padding:12px; } .studio-workspace { grid-template-columns:minmax(260px,.9fr) minmax(0,1.1fr); } .studio-quest-row { padding:7px 0; } }
  @media (max-height:700px) { .ds-main.studio-main { padding-top:8px; padding-bottom:8px; gap:7px; } .studio-quest-panel,.studio-scene-panel { padding:8px; } .studio-quest-row { padding:6px 0; } .studio-quest-copy p { font-size:.63rem; } }
  @media (max-width:760px) { body { overflow:auto; } .ds-shell { height:auto; min-height:100vh; overflow:visible; } .ds-main.studio-main { width:100%; height:auto; min-height:calc(100vh - 70px); overflow:visible; } .studio-workspace,.studio-workspace.no-quests { grid-template-columns:minmax(0,1fr); } .studio-quest-panel { overflow:visible; } .studio-scene-panel { min-height:420px; } #canvas-wrap { min-height:340px; } }
</style>
<script type="importmap">
{
  "imports": {
    "three": "https://unpkg.com/three@0.160.0/build/three.module.js",
    "three/addons/": "https://unpkg.com/three@0.160.0/examples/jsm/"
  }
}
</script>
</head>
<body class="bg-slate-900 text-white">

<div class="ds-shell">

<?php include "partial_nav.php"; ?>

<div class="ds-main studio-main">

<div class="studio-header">
  <div><div class="ds-eyebrow">LIVE BUSINESS SIMULATION</div><h1 class="studio-title">Studio (3D)</h1><p class="studio-subtitle">Complete business milestones, earn XP, and grow your headquarters.</p></div>
  <?php if ($isStudioOwner): ?><div class="studio-header-actions"><div class="studio-level-chip"><span>🏆 LEVEL <?= $studioLevel ?></span><strong><?= number_format($studioXP) ?> XP</strong></div><div class="studio-coin-chip">🪙 <strong><?= number_format($studioCoins) ?></strong> Coins</div><button type="button" class="studio-shop-open" id="open-studio-shop">🛍️ Studio Shop</button></div><?php endif; ?>
</div>

<?php if ($isStudioOwner): ?>
<section class="studio-progression" aria-label="Studio progression">
  <div class="studio-progress-top"><span><?= $xpIntoLevel ?>/100 XP to Level <?= $studioLevel + 1 ?></span><span><?= 100 - $xpIntoLevel ?> XP remaining</span></div>
  <div class="studio-progress-track"><div style="width:<?= $xpIntoLevel ?>%"></div></div>
  <?php if ($flash): ?><div class="studio-flash"><?= htmlspecialchars((string)($flash['message'] ?? ''), ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?>
</section>
<?php endif; ?>

<?php if ($isStudioOwner): ?>
<div class="studio-shop-overlay" id="studio-shop-overlay" hidden>
  <section class="studio-shop-modal" role="dialog" aria-modal="true" aria-labelledby="studio-shop-title">
    <div class="studio-shop-modal-head"><div><div class="ds-eyebrow">SPEND YOUR REWARDS</div><h2 id="studio-shop-title">Studio Shop</h2><p>Buy decorations and upgrades with Studio Coins earned from quests.</p></div><div class="studio-shop-balance">🪙 <?= number_format($studioCoins) ?></div><button type="button" class="studio-shop-close" id="close-studio-shop" aria-label="Close shop">×</button></div>
    <div class="studio-shop-tabs" role="tablist" aria-label="Shop location">
      <button type="button" class="studio-shop-tab active" data-shop-filter="inside" aria-pressed="false">🏢 Inside</button>
      <button type="button" class="studio-shop-tab" data-shop-filter="outside" aria-pressed="true">🌳 Outside</button>
    </div>
    <div class="studio-shop-grid">
      <?php foreach ($studioShopItems as $itemKey => $item): $owned = in_array($itemKey, $ownedStudioItems, true); $requiredQuest = $item['unlock'] ?? null; $requiredLevel = isset($item['level']) ? (int)$item['level'] : null; $questUnlocked = !$requiredQuest || in_array($requiredQuest, $claimedQuestKeys, true); $levelUnlocked = $requiredLevel === null || $studioLevel >= $requiredLevel; $itemUnlocked = $questUnlocked && $levelUnlocked; $requiredQuestTitle = ''; if ($requiredQuest) { foreach ($studioQuests as $q) { if ($q['key'] === $requiredQuest) { $requiredQuestTitle = $q['title']; break; } } } ?>
      <article class="studio-shop-item" data-shop-location="<?= htmlspecialchars($item['location'] ?? 'outside', ENT_QUOTES, 'UTF-8') ?>" style="<?= !$itemUnlocked ? 'opacity:.72;' : '' ?>"><div class="studio-shop-item-icon"><?= htmlspecialchars($item['icon'], ENT_QUOTES, 'UTF-8') ?></div><div class="studio-shop-item-copy"><strong><?= htmlspecialchars($item['name'], ENT_QUOTES, 'UTF-8') ?></strong><p><?= htmlspecialchars($item['description'], ENT_QUOTES, 'UTF-8') ?></p><span>🪙 <?= number_format((int)$item['price']) ?> coins</span><?php if (!$itemUnlocked): ?><?php if (!$levelUnlocked): ?><p class="studio-shop-unlock-requirement">🔒 Level requirement: <strong>Reach Studio Level <?= $requiredLevel ?></strong>. You are currently Level <?= $studioLevel ?>.</p><?php endif; ?><?php if (!$questUnlocked): ?><p class="studio-shop-unlock-requirement">🔒 Quest to unlock: <strong><?= htmlspecialchars($requiredQuestTitle !== '' ? $requiredQuestTitle : 'Required Quest Board mission', ENT_QUOTES, 'UTF-8') ?></strong>. Complete and claim this quest to unlock the item.</p><?php endif; ?><?php endif; ?></div><div class="studio-shop-item-action"><?php if ($owned): ?><span class="studio-claimed">✓ Owned</span><?php elseif (!$itemUnlocked): ?><button type="button" disabled>Locked</button><?php else: ?><form method="post"><input type="hidden" name="sim_csrf" value="<?= htmlspecialchars((string)($_SESSION['sim_csrf'] ?? ''), ENT_QUOTES, 'UTF-8') ?>"><button type="submit" name="buy_studio_item" value="<?= htmlspecialchars($itemKey, ENT_QUOTES, 'UTF-8') ?>" <?= $studioCoins < $item['price'] ? 'disabled' : '' ?>>Buy</button></form><?php endif; ?></div></article>
      <?php endforeach; ?>
    </div>
    <p class="studio-shop-note">Unlock some items by completing and claiming Quest Board missions, and others by reaching higher Studio Levels. Purchased decorations appear in your 3D studio.</p>
  </section>
</div>
<?php endif; ?>

<div class="studio-workspace <?= $isStudioOwner ? 'has-quests' : 'no-quests' ?>">
  <?php if ($isStudioOwner): ?>
  <section class="studio-quest-panel" aria-label="Business quests">
    <div class="studio-section-heading"><div><div class="ds-eyebrow">YOUR MISSIONS</div><h2>Quest Board</h2></div><span><?= count($claimedQuestKeys) ?>/<?= count($studioQuests) ?> claimed</span></div>
    <div class="studio-quest-list">
    <?php foreach ($studioQuests as $quest): $claimed = in_array($quest['key'], $claimedQuestKeys, true); ?>
      <article class="studio-quest-row">
        <div class="studio-quest-copy"><div class="studio-quest-title"><?= htmlspecialchars($quest['title'], ENT_QUOTES, 'UTF-8') ?><span>+<?= (int)$quest['xp'] ?> XP</span></div><p><?= htmlspecialchars($quest['description'], ENT_QUOTES, 'UTF-8') ?></p></div>
        <div class="studio-quest-action">
          <?php if ($claimed): ?><span class="studio-claimed">✓ Claimed</span>
          <?php elseif ($quest['done']): ?><form method="post"><input type="hidden" name="sim_csrf" value="<?= htmlspecialchars((string)($_SESSION['sim_csrf'] ?? ''), ENT_QUOTES, 'UTF-8') ?>"><button type="submit" name="claim_studio_quest" value="<?= htmlspecialchars($quest['key'], ENT_QUOTES, 'UTF-8') ?>">Claim</button></form>
          <?php else: ?><span class="studio-locked">In progress</span><?php endif; ?>
        </div>
      </article>
    <?php endforeach; ?>
    </div>
  </section>
  <?php endif; ?>

  <section class="studio-scene-panel" aria-label="Interactive 3D studio">
    <div class="studio-stats">
      <div><span>Employees</span><strong><?= $sceneData['employees'] ?></strong></div>
      <div><span>Business Cash</span><strong><?= $canSeeStudioCash ? '₱'.number_format($sceneData['cash']) : '—' ?></strong></div>
      <div><span>Achievements</span><strong><?= $sceneData['achievements'] ?></strong></div>
    </div>
    <div class="studio-scene-toolbar" role="group" aria-label="Studio view">
      <button class="studio-scene-mode" id="view-outside" type="button" aria-pressed="true">🌳 Outside</button>
      <button class="studio-scene-mode" id="view-inside" type="button" aria-pressed="false">🏢 Inside</button>
      <span class="studio-scene-mode-note" id="scene-mode-note">Headquarters exterior</span>
    </div>
    <div id="canvas-wrap"><div class="scene-loading" id="scene-loading">Booting scene…</div><div class="scene-hint">Drag to orbit · Scroll to zoom · Switch between exterior and interior</div></div>
  </section>
</div>

</div>
</div>

<script id="scene-data" type="application/json"><?= json_encode($sceneData) ?></script>

<script type="module">
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

const data = JSON.parse(document.getElementById('scene-data').textContent);
const wrap = document.getElementById('canvas-wrap');

const scene = new THREE.Scene();
scene.fog = new THREE.Fog(0x0b0d13, 20, 70);

const camera = new THREE.PerspectiveCamera(45, wrap.clientWidth / wrap.clientHeight, 0.1, 200);
camera.position.set(16, 14, 20);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(wrap.clientWidth, wrap.clientHeight);
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
wrap.appendChild(renderer.domElement);

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.dampingFactor = 0.08;
controls.autoRotate = true;
controls.autoRotateSpeed = 0.6;
controls.minDistance = 8;
controls.maxDistance = 45;
controls.maxPolarAngle = Math.PI / 2.1;
controls.target.set(0, 2, 0);

// ---------- lighting driven by morale ----------
const moraleT = Math.max(0, Math.min(100, data.morale)) / 100;
const warmColor = new THREE.Color(0xffb15e);
const coolColor = new THREE.Color(0x5b6ea8);
const lightColor = coolColor.clone().lerp(warmColor, moraleT);

const ambient = new THREE.AmbientLight(lightColor, 0.55 + moraleT * 0.3);
scene.add(ambient);

const sun = new THREE.DirectionalLight(lightColor, 0.9 + moraleT * 0.6);
sun.position.set(10, 18, 8);
scene.add(sun);

// ---------- ground ----------
const ground = new THREE.Mesh(
  new THREE.CircleGeometry(26, 48),
  new THREE.MeshStandardMaterial({ color: 0x141926, roughness: 0.95 })
);
ground.rotation.x = -Math.PI / 2;
scene.add(ground);

const grid = new THREE.GridHelper(52, 26, 0x2A3142, 0x1D2330);
grid.position.y = 0.01;
scene.add(grid);

// ---------- HQ tower (height from cash) ----------
const cashScore = Math.log10(Math.max(1000, data.cash)) - 2; // ~1 at ₱1k, ~3 at ₱1M
const towerHeight = Math.max(3, Math.min(18, cashScore * 3.2 + Math.max(0, (data.level || 1) - 1) * 0.65));
const hasGoldTheme = data.ownedItems.includes('gold_theme');
const towerColor = hasGoldTheme ? new THREE.Color(0xD4AF37) : new THREE.Color(0x37C6BE).lerp(new THREE.Color(0xE8A33D), Math.max(0, 1 - cashScore / 3));

const tower = new THREE.Mesh(
  new THREE.BoxGeometry(3.2, towerHeight, 3.2),
  new THREE.MeshStandardMaterial({ color: towerColor, roughness: 0.4, metalness: 0.2 })
);
tower.position.set(0, towerHeight / 2, 0);
scene.add(tower);

// Purchased studio decorations are rendered in the live 3D scene.
if (data.ownedItems.includes('plant')) {
  const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.28,0.22,0.42,12), new THREE.MeshStandardMaterial({color:0x9a5b35,roughness:0.8}));
  pot.position.set(4.3,0.21,3.5); scene.add(pot);
  const leaves = new THREE.Mesh(new THREE.SphereGeometry(0.62,12,10), new THREE.MeshStandardMaterial({color:0x3fa66b,roughness:0.7}));
  leaves.position.set(4.3,0.82,3.5); leaves.scale.set(0.8,1.1,0.8); scene.add(leaves);
}
if (data.ownedItems.includes('neon_sign')) {
  const sign = new THREE.Mesh(new THREE.BoxGeometry(2.4,0.65,0.12), new THREE.MeshStandardMaterial({color:0x22d3ee,emissive:0x0891b2,emissiveIntensity:1.8,metalness:0.2}));
  sign.position.set(0,towerHeight+0.65,0); scene.add(sign);
}
if (data.ownedItems.includes('workstation')) {
  const desk = new THREE.Mesh(new THREE.BoxGeometry(1.7,0.16,0.9), new THREE.MeshStandardMaterial({color:0x64748b,metalness:0.35,roughness:0.4}));
  desk.position.set(4.2,0.85,-1.2); scene.add(desk);
  const screen = new THREE.Mesh(new THREE.BoxGeometry(0.8,0.65,0.08), new THREE.MeshStandardMaterial({color:0x60a5fa,emissive:0x1d4ed8,emissiveIntensity:0.7}));
  screen.position.set(4.2,1.25,-1.45); scene.add(screen);
}
if (data.ownedItems.includes('fountain')) {
  const basin = new THREE.Mesh(new THREE.CylinderGeometry(1.05,1.15,0.28,24), new THREE.MeshStandardMaterial({color:0x64748b,metalness:0.5,roughness:0.25}));
  basin.position.set(-5,0.14,5); scene.add(basin);
  const water = new THREE.Mesh(new THREE.CylinderGeometry(0.78,0.78,0.08,24), new THREE.MeshStandardMaterial({color:0x38bdf8,emissive:0x0369a1,emissiveIntensity:0.45,transparent:true,opacity:0.85}));
  water.position.set(-5,0.3,5); scene.add(water);
}
if (data.ownedItems.includes('trophy_case')) {
  const stand = new THREE.Mesh(new THREE.BoxGeometry(1.5,0.55,0.65), new THREE.MeshStandardMaterial({color:0x475569,metalness:0.45,roughness:0.35}));
  stand.position.set(-4.3,0.28,-2.5); scene.add(stand);
  const cup = new THREE.Mesh(new THREE.CylinderGeometry(0.18,0.28,0.42,12), new THREE.MeshStandardMaterial({color:0xfbbf24,metalness:0.7,roughness:0.22}));
  cup.position.set(-4.3,0.76,-2.5); scene.add(cup);
}
if (data.ownedItems.includes('rooftop_garden')) {
  const roof = new THREE.Mesh(new THREE.BoxGeometry(3.5,0.16,3.5), new THREE.MeshStandardMaterial({color:0x3f7d45,roughness:0.85}));
  roof.position.set(0,towerHeight+0.12,0); scene.add(roof);
  for (let i=0;i<5;i++) { const shrub = new THREE.Mesh(new THREE.SphereGeometry(0.22,10,8), new THREE.MeshStandardMaterial({color:0x4ade80,roughness:0.8})); shrub.position.set(-1.2+i*0.6,towerHeight+0.38,0.7); scene.add(shrub); }
}
if (data.ownedItems.includes('satellite_dish')) {
  const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.07,0.09,1.5,10), new THREE.MeshStandardMaterial({color:0x94a3b8,metalness:0.65}));
  mast.position.set(4.8,0.75,-3.7); scene.add(mast);
  const dish = new THREE.Mesh(new THREE.SphereGeometry(0.65,16,10,0,Math.PI*2,0,Math.PI/2), new THREE.MeshStandardMaterial({color:0x60a5fa,metalness:0.65,roughness:0.25,side:THREE.DoubleSide}));
  dish.position.set(4.8,1.55,-3.7); dish.rotation.x=Math.PI/3; scene.add(dish);
}
if (data.ownedItems.includes('crystal_trophy')) {
  const crystal = new THREE.Mesh(new THREE.OctahedronGeometry(0.65), new THREE.MeshStandardMaterial({color:0xc4b5fd,emissive:0x7c3aed,emissiveIntensity:0.5,metalness:0.55,roughness:0.2}));
  crystal.position.set(-4.8,0.8,-4.5); scene.add(crystal);
}
if (data.ownedItems.includes('executive_lounge')) {
  const couch = new THREE.Mesh(new THREE.BoxGeometry(2.2,0.55,0.8), new THREE.MeshStandardMaterial({color:0x7c3aed,roughness:0.7}));
  couch.position.set(4.6,0.3,3.7); scene.add(couch);
  const back = new THREE.Mesh(new THREE.BoxGeometry(2.2,0.7,0.25), new THREE.MeshStandardMaterial({color:0x6d28d9,roughness:0.7}));
  back.position.set(4.6,0.82,4.05); scene.add(back);
}

// window lights on the tower
const windowMat = new THREE.MeshStandardMaterial({ color: lightColor, emissive: lightColor, emissiveIntensity: 0.8 });
const floors = Math.max(2, Math.floor(towerHeight));
for (let f = 0; f < floors; f++) {
  for (let side = 0; side < 4; side++) {
    const angle = side * Math.PI / 2;
    const w = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.35), windowMat);
    const r = 1.62;
    w.position.set(Math.sin(angle) * r, 0.6 + f * (towerHeight / floors), Math.cos(angle) * r);
    w.rotation.y = angle;
    scene.add(w);
  }
}

// ---------- desks (employees) ----------
const deskCount = Math.min(40, data.employees);
const deskColor = new THREE.Color(0xE1543D).lerp(new THREE.Color(0x5FBE7A), Math.max(0, Math.min(1, data.efficiency / 100)));
const cols = Math.ceil(Math.sqrt(deskCount || 1));
const spacing = 2.1;

for (let i = 0; i < deskCount; i++) {
  const row = Math.floor(i / cols);
  const col = i % cols;
  const x = (col - (cols - 1) / 2) * spacing;
  const z = 6 + row * spacing;

  const desk = new THREE.Mesh(
    new THREE.BoxGeometry(1.1, 0.5, 0.7),
    new THREE.MeshStandardMaterial({ color: 0x1D2330, roughness: 0.8 })
  );
  desk.position.set(x, 0.25, z);
  scene.add(desk);

  const monitor = new THREE.Mesh(
    new THREE.BoxGeometry(0.5, 0.35, 0.05),
    new THREE.MeshStandardMaterial({ color: deskColor, emissive: deskColor, emissiveIntensity: 0.5 })
  );
  monitor.position.set(x, 0.65, z - 0.2);
  scene.add(monitor);
}

// ---------- orbiting trophies (achievements) ----------
const trophyCount = Math.min(12, data.achievements);
const trophies = [];
for (let i = 0; i < trophyCount; i++) {
  const trophy = new THREE.Mesh(
    new THREE.OctahedronGeometry(0.35, 0),
    new THREE.MeshStandardMaterial({ color: 0xE8A33D, emissive: 0x5c3a08, metalness: 0.6, roughness: 0.3 })
  );
  const angle = (i / trophyCount) * Math.PI * 2;
  trophy.userData.angle = angle;
  trophy.userData.radius = 5 + (i % 3) * 0.6;
  trophy.userData.height = towerHeight + 1.5 + (i % 4) * 0.5;
  scene.add(trophy);
  trophies.push(trophy);
}

// ---------- project beacons (risk) ----------
const riskColor = { "Low": 0x5FBE7A, "Medium": 0xE8A33D, "High": 0xE1543D };
data.projects.forEach((p, i) => {
  const beacon = new THREE.Mesh(
    new THREE.CylinderGeometry(0.18, 0.18, 1 + (p.progress / 100) * 2, 12),
    new THREE.MeshStandardMaterial({
      color: riskColor[p.risk] || 0x8B93A6,
      emissive: riskColor[p.risk] || 0x8B93A6,
      emissiveIntensity: 0.3
    })
  );
  const h = 1 + (p.progress / 100) * 2;
  beacon.position.set(-6 - Math.floor(i / 4) * 1.6, h / 2, -3 + (i % 4) * 1.8);
  scene.add(beacon);
});

// ---------- switchable exterior and interior scenes ----------
// Move the existing outdoor scene into its own group so the view switch is instant
// and all existing purchased decorations, trophies, desks and project beacons remain.
const outsideGroup = new THREE.Group();
outsideGroup.name = 'Studio Exterior';
const existingVisuals = scene.children.filter((child) => !child.isLight && child !== outsideGroup);
existingVisuals.forEach((child) => outsideGroup.add(child));
scene.add(outsideGroup);

const insideGroup = new THREE.Group();
insideGroup.name = 'Studio Interior';
scene.add(insideGroup);
const mat = (color, roughness=0.75, metalness=0) => new THREE.MeshStandardMaterial({color, roughness, metalness});
const addBox = (group, w, h, d, color, x, y, z, materialOptions={}) => {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w,h,d), mat(color, materialOptions.roughness ?? 0.75, materialOptions.metalness ?? 0));
  mesh.position.set(x,y,z); group.add(mesh); return mesh;
};
// Spacious open-front office so the inside is easy to see from the default camera.
addBox(insideGroup, 17, .35, 13, 0x303b4b, 0, -.18, 0, {roughness:.9}); // foundation
addBox(insideGroup, 16.5, .12, 12.5, 0x9a8067, 0, .04, 0, {roughness:.88}); // floor
addBox(insideGroup, 16.5, 4.5, .22, 0x475569, 0, 2.25, -6.15);
addBox(insideGroup, .22, 4.5, 12.3, 0x475569, -8.15, 2.25, 0);
addBox(insideGroup, .22, 4.5, 12.3, 0x475569, 8.15, 2.25, 0);
// Bright windows and accent strips on the back and side walls.
for (let i=0;i<5;i++) {
  addBox(insideGroup, 2.35, 1.8, .06, 0x7dd3fc, -5.6+i*2.8, 2.7, -6.01, {roughness:.25,metalness:.1});
  addBox(insideGroup, 2.35, .08, .08, 0x1e293b, -5.6+i*2.8, 3.65, -5.96);
}
addBox(insideGroup, 16.3, .12, .18, 0x22d3ee, 0, 4.35, -6.0, {roughness:.35,metalness:.25});
// Reception counter and a glowing business sign.
addBox(insideGroup, 3.3, 1.05, .85, 0x334155, 0, .62, -4.35);
addBox(insideGroup, 3.35, .12, .9, 0x38bdf8, 0, 1.2, -4.35, {roughness:.3,metalness:.2});
addBox(insideGroup, 2.4, .55, .1, 0x0f172a, 0, 3.8, -5.94);
addBox(insideGroup, 1.9, .09, .12, 0x67e8f9, 0, 3.8, -5.85, {roughness:.25,metalness:.1});
// Workstations with monitors; employee count changes the number of desks shown.
const insideDeskCount = Math.min(12, Math.max(4, data.employees));
for (let i=0;i<insideDeskCount;i++) {
  const col=i%4, row=Math.floor(i/4), x=-5.1+col*3.4, z=-1.4+row*2.5;
  addBox(insideGroup, 1.65, .14, 1.05, 0x64748b, x, .95, z, {roughness:.45,metalness:.15});
  addBox(insideGroup, .12, .9, .12, 0x334155, x-.62, .48, z-.3);
  addBox(insideGroup, .12, .9, .12, 0x334155, x+.62, .48, z-.3);
  addBox(insideGroup, .72, .56, .08, 0x0f172a, x, 1.32, z-.28);
  addBox(insideGroup, .58, .39, .025, 0x38bdf8, x, 1.33, z-.225, {roughness:.3});
  addBox(insideGroup, .14, .34, .14, 0x475569, x, .69, z+.28);
}
// Meeting table and seats near the front of the room.
addBox(insideGroup, 3.6, .16, 1.7, 0x7c5a3b, 0, .95, 4.2, {roughness:.6});
for (const x of [-1.5,1.5]) for (const z of [3.25,5.15]) {
  addBox(insideGroup, .65, .16, .65, 0x475569, x, .55, z);
  addBox(insideGroup, .65, .55, .12, 0x64748b, x, .86, z+.26);
}
// Ceiling lights and indoor plants add depth without hiding the furniture.
for (const x of [-5,0,5]) {
  addBox(insideGroup, 2.0, .08, .55, 0xfef3c7, x, 4.48, -1.5, {roughness:.25});
}
for (const [x,z] of [[-7,4.5],[7,-3.5]]) {
  const pot = new THREE.Mesh(new THREE.CylinderGeometry(.25,.3,.4,12), mat(0x9a5b35)); pot.position.set(x,.25,z); insideGroup.add(pot);
  const leaves = new THREE.Mesh(new THREE.SphereGeometry(.55,12,10), mat(0x3fa66b)); leaves.position.set(x,.8,z); leaves.scale.set(.8,1.2,.8); insideGroup.add(leaves);
}
// Additional shop purchases are rendered in their matching scene.
if (data.ownedItems.includes('meeting_table')) {
  addBox(insideGroup, 2.8, .14, 1.25, 0x8b5e3c, -4.5, .95, 3.0);
  for (const [x,z] of [[-5.5,2.25],[-3.5,2.25],[-5.5,3.75],[-3.5,3.75]]) addBox(insideGroup, .5, .55, .5, 0x475569, x, .45, z);
}
if (data.ownedItems.includes('coffee_corner')) {
  addBox(insideGroup, 1.15, .95, .55, 0x7c4a2d, 6.6, .5, -3.9);
  addBox(insideGroup, .42, .42, .38, 0x111827, 6.6, 1.15, -3.9);
  addBox(insideGroup, .22, .16, .22, 0xd1d5db, 6.6, 1.44, -3.9);
}
if (data.ownedItems.includes('server_rack')) {
  for (let i=0;i<3;i++) { addBox(insideGroup, .72, 2.0, .7, 0x1e293b, -6.8+i*.82, 1.05, -4.65, {metalness:.35}); for (let j=0;j<4;j++) addBox(insideGroup, .42, .045, .025, 0x38bdf8, -6.8+i*.82, .4+j*.42, -4.28, {roughness:.3}); }
}
if (data.ownedItems.includes('wall_art')) {
  addBox(insideGroup, 2.0, 1.15, .08, 0x7c3aed, 5.0, 2.6, -6.0);
  addBox(insideGroup, 1.25, .55, .04, 0xfbbf24, 5.0, 2.6, -5.94);
}
if (data.ownedItems.includes('floor_lamp')) {
  addBox(insideGroup, .22, 2.0, .22, 0x475569, 6.5, 1.0, 4.2);
  const lampShade = new THREE.Mesh(new THREE.ConeGeometry(.48,.55,16), mat(0xfef3c7)); lampShade.position.set(6.5,2.15,4.2); insideGroup.add(lampShade);
}
if (data.ownedItems.includes('office_sofa')) {
  addBox(insideGroup, 2.2, .5, .85, 0x2563eb, -4.8, .35, -3.8);
  addBox(insideGroup, 2.2, .65, .2, 0x1d4ed8, -4.8, .85, -4.15);
  for (const x of [-5.6,-4.0]) addBox(insideGroup, .12, .25, .12, 0x334155, x, .1, -3.8);
}
if (data.ownedItems.includes('line_lighting')) {
  // Purchased LED line lighting: luminous ceiling perimeter and wall accents.
  const ledMaterial = new THREE.MeshStandardMaterial({ color: 0x67e8f9, emissive: 0x22d3ee, emissiveIntensity: 2.1, roughness: 0.25, metalness: 0.15 });
  const ledWarmMaterial = new THREE.MeshStandardMaterial({ color: 0xfef3c7, emissive: 0xf59e0b, emissiveIntensity: 1.35, roughness: 0.3 });
  const ledBars = [
    [15.5,.07,.09,0,4.34,-5.55], [15.5,.07,.09,0,4.34,5.55],
    [.08,.07,10.9,-7.65,4.34,0], [.08,.07,10.9,7.65,4.34,0],
    [7.0,.06,.08,-4.6,3.95,-6.0], [7.0,.06,.08,4.6,3.95,-6.0]
  ];
  for (const [w,h,d,x,y,z] of ledBars) {
    const strip = new THREE.Mesh(new THREE.BoxGeometry(w,h,d), ledMaterial);
    strip.position.set(x,y,z); insideGroup.add(strip);
  }
  // Warm linear accents above the reception counter.
  const receptionStrip = new THREE.Mesh(new THREE.BoxGeometry(3.4,.055,.08), ledWarmMaterial);
  receptionStrip.position.set(0,1.34,-4.35); insideGroup.add(receptionStrip);
}
// Exterior additions are attached to the exterior group so they stay hidden indoors.
const outsideItemGroup = new THREE.Group(); outsideItemGroup.name = 'Purchased Exterior Items'; outsideGroup.add(outsideItemGroup);
if (data.ownedItems.includes('garden_tree')) {
  for (const [x,z] of [[-7,-5],[7,5]]) { const trunk = new THREE.Mesh(new THREE.CylinderGeometry(.18,.24,1.3,10), mat(0x80512f)); trunk.position.set(x,.65,z); outsideItemGroup.add(trunk); const crown = new THREE.Mesh(new THREE.SphereGeometry(.9,12,10), mat(0x2f855a)); crown.position.set(x,1.65,z); outsideItemGroup.add(crown); }
}
if (data.ownedItems.includes('flagpole')) {
  addBox(outsideItemGroup, .12, 4.0, .12, 0xcbd5e1, -7, 2, -2.5, {metalness:.5});
  addBox(outsideItemGroup, 1.5, .8, .08, 0x2563eb, -6.2, 3.35, -2.5);
  addBox(outsideItemGroup, .8, .16, .1, 0xfbbf24, -6.2, 3.35, -2.43);
}
if (data.ownedItems.includes('parking_bay')) {
  addBox(outsideItemGroup, 4.4, .06, 2.6, 0x334155, 6, .04, 6.5);
  for (const x of [4.0,8.0]) addBox(outsideItemGroup, .08, .025, 2.3, 0xf8fafc, x, .085, 6.5);
  addBox(outsideItemGroup, 1.45, .45, .7, 0x2563eb, 6, .38, 6.5);
  addBox(outsideItemGroup, .75, .32, .58, 0x93c5fd, 6, .73, 6.5);
  for (const x of [5.55,6.45]) { const wheel = new THREE.Mesh(new THREE.CylinderGeometry(.16,.16,.12,12), mat(0x111827)); wheel.rotation.z=Math.PI/2; wheel.position.set(x,.22,6.85); outsideItemGroup.add(wheel); }
}
if (data.ownedItems.includes('path_lights')) {
  for (const [x,z] of [[-4,6],[-1,6],[2,6],[5,6]]) { addBox(outsideItemGroup, .12, .65, .12, 0x64748b, x, .32,z); const glow = new THREE.Mesh(new THREE.SphereGeometry(.18,10,8), new THREE.MeshStandardMaterial({color:0xfef3c7,emissive:0xfbbf24,emissiveIntensity:1.4})); glow.position.set(x,.72,z); outsideItemGroup.add(glow); }
}
insideGroup.visible = false;

const outsideButton = document.getElementById('view-outside');
const insideButton = document.getElementById('view-inside');
const modeNote = document.getElementById('scene-mode-note');
function setStudioView(mode) {
  const inside = mode === 'inside';
  outsideGroup.visible = !inside;
  insideGroup.visible = inside;
  outsideButton.setAttribute('aria-pressed', String(!inside));
  insideButton.setAttribute('aria-pressed', String(inside));
  modeNote.textContent = inside ? 'Office interior · desks, reception & meeting area' : 'Headquarters exterior · grounds & decorations';
  controls.target.set(0, inside ? 1.6 : 2, inside ? 0 : 0);
  const targetPosition = inside ? new THREE.Vector3(13, 10, 16) : new THREE.Vector3(16, 14, 20);
  camera.position.copy(targetPosition);
  controls.minDistance = inside ? 9 : 8;
  controls.maxDistance = inside ? 29 : 45;
  controls.maxPolarAngle = inside ? Math.PI / 2.02 : Math.PI / 2.1;
  controls.autoRotate = !inside;
  controls.update();
}
outsideButton.addEventListener('click', () => setStudioView('outside'));
insideButton.addEventListener('click', () => setStudioView('inside'));

// ---------- animation ----------
const orbitSpeed = 0.2 + (data.efficiency / 100) * 0.6;

function animate() {
  requestAnimationFrame(animate);
  const t = performance.now() / 1000;

  trophies.forEach((trophy) => {
    const a = trophy.userData.angle + t * orbitSpeed;
    trophy.position.set(
      Math.cos(a) * trophy.userData.radius,
      trophy.userData.height + Math.sin(t * 1.5 + trophy.userData.angle) * 0.2,
      Math.sin(a) * trophy.userData.radius
    );
    trophy.rotation.y += 0.02;
    trophy.rotation.x += 0.01;
  });

  controls.update();
  renderer.render(scene, camera);
}

document.getElementById('scene-loading').remove();
animate();

window.addEventListener('resize', () => {
  camera.aspect = wrap.clientWidth / wrap.clientHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(wrap.clientWidth, wrap.clientHeight);
});
</script>

<script>
(function(){
 const overlay=document.getElementById('studio-shop-overlay');
 const open=document.getElementById('open-studio-shop');
 const close=document.getElementById('close-studio-shop');
 if(!overlay||!open||!close)return;
 const tabs=[...overlay.querySelectorAll('[data-shop-filter]')];
 const items=[...overlay.querySelectorAll('[data-shop-location]')];
 function filterShop(location){
   tabs.forEach(tab=>{const active=tab.dataset.shopFilter===location;tab.classList.toggle('active',active);tab.setAttribute('aria-pressed',String(active));});
   items.forEach(item=>{item.hidden=item.dataset.shopLocation!==location;});
 }
 filterShop('outside');
 tabs.forEach(tab=>tab.addEventListener('click',()=>filterShop(tab.dataset.shopFilter)));
 open.addEventListener('click',()=>{overlay.hidden=false;});
 close.addEventListener('click',()=>{overlay.hidden=true;});
 overlay.addEventListener('click',e=>{if(e.target===overlay)overlay.hidden=true;});
 document.addEventListener('keydown',e=>{if(e.key==='Escape')overlay.hidden=true;});
})();
lucide.createIcons();
</script>
</body>
</html>

-- DEVSTUDIO SIMS: enforce project ownership per business.
-- Select the devstudio_sims database before running this migration.
-- Run once. If business_owner_id already exists, skip the ALTER TABLE line.
ALTER TABLE projects ADD COLUMN business_owner_id INT NULL;
CREATE INDEX idx_projects_business_owner ON projects (business_owner_id);

-- Preserve legacy projects by assigning them to the earliest registered owner.
UPDATE projects
SET business_owner_id = (
    SELECT owner_id FROM (
        SELECT id AS owner_id FROM users WHERE role = 'owner' ORDER BY created_at ASC, id ASC LIMIT 1
    ) AS first_owner
)
WHERE business_owner_id IS NULL;

-- New installs should ideally also use a foreign key after confirming all legacy
-- project records have valid owners. This migration intentionally avoids adding
-- a foreign key that could fail on older databases with legacy records.

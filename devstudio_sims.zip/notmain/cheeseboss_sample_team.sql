-- Optional one-time seed: adds a sample team to the existing CheeseBoss owner account.
-- Back up the database first. Requires employee_business_migration.sql to be applied.
-- Safe to re-run: each sample name is inserted only if it is not already assigned to CheeseBoss.

INSERT INTO employees (business_owner_id, name, role, salary, morale, efficiency, status)
SELECT u.id, seed.name, seed.role, seed.salary, 0, 0, 'active'
FROM users AS u
JOIN (
    SELECT 'Emily Santos' AS name, 'Backend Developer' AS role, 4500 AS salary
    UNION ALL SELECT 'John Carter', 'Frontend Developer', 4200
    UNION ALL SELECT 'Mia Reyes', 'UI/UX Designer', 4000
    UNION ALL SELECT 'Daniel Cruz', 'QA Tester', 3800
) AS seed
WHERE LOWER(u.username) = LOWER('cheeseBoss')
  AND LOWER(u.role) = 'owner'
  AND NOT EXISTS (
      SELECT 1
      FROM employees AS existing
      WHERE existing.business_owner_id = u.id
        AND LOWER(existing.name) = LOWER(seed.name)
  );

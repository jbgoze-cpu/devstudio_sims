<?php
session_start();
require_once 'db.php';
require_once 'simulation_helpers.php';
require_once 'business_helpers.php';
require_once 'worker_score_helpers.php';
requireLogin();
$me = currentUser();
$uid = (int)($me['id'] ?? 0);
$ownerId = (int)(function_exists('currentBusinessOwnerId') ? (currentBusinessOwnerId() ?? 0) : 0);
if ($ownerId > 0) simState($ownerId);
if ($ownerId > 0) syncWorkerProjectScoreEvents($conn, $ownerId);

// The project workflow awards one completion point per completed project.
// Create the same table here as a safety net if a worker opens the leaderboard first.
$conn->query("CREATE TABLE IF NOT EXISTS project_completions (
    project_id INT NOT NULL PRIMARY KEY,
    user_id INT NOT NULL,
    points_awarded INT NOT NULL DEFAULT 1,
    completed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_project_completions_user (user_id),
    INDEX idx_project_completions_date (completed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$period = (($_GET['period'] ?? 'month') === 'all') ? 'all' : 'month';
$periodFilterPc = $period === 'month' ? " AND pc.completed_at >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND pc.completed_at < DATE_FORMAT(DATE_ADD(CURDATE(), INTERVAL 1 MONTH), '%Y-%m-01')" : '';
$periodFilterSe = $period === 'month' ? " AND event_at >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND event_at < DATE_FORMAT(DATE_ADD(CURDATE(), INTERVAL 1 MONTH), '%Y-%m-01')" : '';
$workerRows = [];
if ($ownerId > 0) {
    $workerSql = "SELECT u.id AS user_id, u.username,
        COALESCE(pc.projects_completed,0) AS projects_completed,
        COALESCE(se.points,0) AS points,
        COALESCE(pc.month_projects,0) AS month_projects,
        pc.last_completed
        FROM users u
        INNER JOIN business_employment be ON be.worker_id=u.id AND be.owner_id=? AND be.status='hired'
        LEFT JOIN (SELECT pc.user_id, COUNT(pc.project_id) AS projects_completed,
            SUM(CASE WHEN pc.completed_at >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND pc.completed_at < DATE_FORMAT(DATE_ADD(CURDATE(), INTERVAL 1 MONTH), '%Y-%m-01') THEN 1 ELSE 0 END) AS month_projects,
            MAX(pc.completed_at) AS last_completed
            FROM project_completions pc JOIN projects p ON p.id=pc.project_id WHERE p.business_owner_id=? $periodFilterPc GROUP BY pc.user_id) pc ON pc.user_id=u.id
        LEFT JOIN (SELECT user_id, SUM(points_change) AS points FROM worker_project_score_events WHERE owner_id=? $periodFilterSe GROUP BY user_id) se ON se.user_id=u.id
        WHERE LOWER(u.role)='worker'
        GROUP BY u.id, u.username, pc.projects_completed, pc.month_projects, pc.last_completed, se.points
        ORDER BY points DESC, projects_completed DESC, last_completed DESC, u.username ASC LIMIT 100";
    $workerStmt = $conn->prepare($workerSql);
    if ($workerStmt) {
        $workerStmt->bind_param('iii', $ownerId, $ownerId, $ownerId);
        if ($workerStmt->execute()) { $workerResult = $workerStmt->get_result(); if ($workerResult) $workerRows = $workerResult->fetch_all(MYSQLI_ASSOC); }
        $workerStmt->close();
    }
}
$myRank = 0; $myStats = ['projects_completed'=>0,'points'=>0];
foreach ($workerRows as $i => $r) {
    if ((int)$r['user_id'] === $uid) { $myRank = $i + 1; $myStats = $r; break; }
}
// Count this month's completed projects for the monthly consistency badge.
$myMonthCount = 0;
$monthStmt = $conn->prepare("SELECT COUNT(*) AS total FROM project_completions pc JOIN projects p ON p.id=pc.project_id WHERE pc.user_id=? AND p.business_owner_id=? AND pc.completed_at >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND pc.completed_at < DATE_FORMAT(DATE_ADD(CURDATE(), INTERVAL 1 MONTH), '%Y-%m-01')");
if ($monthStmt) { $monthStmt->bind_param('ii', $uid, $ownerId); $monthStmt->execute(); $monthRow = $monthStmt->get_result()->fetch_assoc(); $myMonthCount = (int)($monthRow['total'] ?? 0); $monthStmt->close(); }

function lbEscape($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function lbBadgeCount(int $projects, int $monthProjects): array {
    $badges=[];
    if ($projects >= 1) $badges[]=['🚀','First Step'];
    if ($projects >= 5) $badges[]=['⭐','Rising Star'];
    if ($projects >= 10) $badges[]=['🏆','Project Champion'];
    if ($monthProjects >= 3) $badges[]=['💎','Consistent Contributor'];
    return $badges;
}
$myProjects = (int)($myStats['projects_completed'] ?? 0);
$myPoints = (int)($myStats['points'] ?? 0);
$nextMilestone = $myProjects < 1 ? 1 : ($myProjects < 5 ? 5 : ($myProjects < 10 ? 10 : 10));
$remaining = max(0, $nextMilestone - $myProjects);
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Studio Leaderboard | DEVSTUDIO SIMS</title><script src="https://cdn.tailwindcss.com"></script><link rel="stylesheet" href="assets/theme.css"><style>
/* Studio Leaderboard: scoped layout and readability fixes */
.lb-page{max-width:1180px!important;padding:28px clamp(12px,2.5vw,28px)!important}
.lb-hero{display:flex;align-items:flex-end;justify-content:space-between;gap:20px;margin-bottom:24px}
.lb-kicker{display:inline-flex;align-items:center;gap:7px;border:1px solid rgba(45,212,191,.25);background:rgba(45,212,191,.08);color:#5eead4;border-radius:999px;padding:5px 11px;font-size:11px;font-weight:800;letter-spacing:.13em}
.lb-hero h1{margin:10px 0 0!important;letter-spacing:-.035em}
.lb-hero p{max-width:660px;line-height:1.6}
.lb-panel{border:1px solid #334155!important;border-radius:20px!important;background:linear-gradient(145deg,rgba(30,41,59,.94),rgba(15,23,42,.92))!important;box-shadow:0 14px 36px rgba(2,6,23,.18);padding:clamp(14px,2vw,24px)!important}
.lb-panel-head{display:flex;justify-content:space-between;align-items:center;gap:16px;margin-bottom:20px}
.lb-periods{display:flex;gap:6px;padding:4px;border:1px solid #334155;background:#0f172a;border-radius:12px;flex-shrink:0}
.lb-periods a{border-radius:8px;white-space:nowrap}
.lb-podium{align-items:stretch}
.lb-podium-card{display:flex;flex-direction:column;justify-content:center;min-height:150px;border-radius:16px!important;transition:transform .15s ease,border-color .15s ease}
.lb-podium-card:hover{transform:translateY(-2px);border-color:rgba(94,234,212,.5)}
.lb-table-wrap{border:1px solid #334155;border-radius:14px;overflow:auto;background:rgba(2,6,23,.28)}
.lb-table{min-width:620px;border-collapse:separate;border-spacing:0}
.lb-table th{font-size:11px;text-transform:uppercase;letter-spacing:.08em;font-weight:800;padding:13px 16px;white-space:nowrap}
.lb-table td{padding:14px 16px;vertical-align:middle}
.lb-table tbody tr{transition:background .15s ease}
.lb-table tbody tr:hover{background:rgba(148,163,184,.07)}
.lb-stat{border:1px solid #263449;border-radius:14px;background:rgba(2,6,23,.38);padding:16px;min-width:0}
.lb-stat-label{font-size:11px;text-transform:uppercase;letter-spacing:.08em;color:#94a3b8;font-weight:800}
.lb-stat-value{font-size:clamp(1.45rem,2vw,1.9rem);font-weight:800;letter-spacing:-.03em;overflow-wrap:anywhere}
.lb-section-title{display:flex;align-items:center;gap:10px;font-size:1.15rem;font-weight:800;letter-spacing:-.02em}
.lb-section-title .lb-icon{display:grid;place-items:center;width:34px;height:34px;border-radius:10px;background:rgba(45,212,191,.1);border:1px solid rgba(45,212,191,.18)}
.lb-achievement{display:inline-flex;align-items:center;gap:5px;border:1px solid #334155;background:#1e293b;border-radius:999px;padding:6px 10px;font-size:12px;line-height:1.2}
@media(max-width:640px){.lb-page{padding:20px 12px!important}.lb-hero{display:block}.lb-hero h1{font-size:1.9rem!important}.lb-panel-head{align-items:flex-start;flex-direction:column}.lb-periods{width:100%}.lb-periods a{flex:1;text-align:center}.lb-podium-card{min-height:120px}.lb-stat{padding:12px}.lb-table th,.lb-table td{padding:12px 10px}}
</style></head>
<body class="bg-slate-900 text-white"><div class="ds-shell ds-unified-shell"><?php include 'partial_nav.php'; ?><main class="ds-main ds-unified-main"><div class="max-w-5xl mx-auto p-4 md:p-7 lb-page">
<header class="lb-hero"><div><span class="lb-kicker">✦ GAMIFICATION</span><h1 class="text-3xl md:text-4xl font-bold">Studio Leaderboard</h1><p class="text-slate-400 mt-2">Celebrate completed work, earn milestones, and track your standing in this studio.</p></div></header>
<section class="lb-panel mb-5">
 <div class="lb-panel-head"><div><h2 class="lb-section-title"><span class="lb-icon">🏆</span> Top Workers</h2><p class="text-sm text-slate-400 mt-2 max-w-2xl leading-relaxed">Only workers in this business are ranked. Missed deadlines subtract points; approved on-time completions add points, so scores may fall below zero.</p></div><div class="lb-periods"><a class="rounded-lg px-3 py-2 text-sm font-semibold <?= $period==='month'?'bg-teal-400 text-slate-950':'bg-slate-700 text-slate-200' ?>" href="leaderboard.php?period=month">This Month</a><a class="rounded-lg px-3 py-2 text-sm font-semibold <?= $period==='all'?'bg-teal-400 text-slate-950':'bg-slate-700 text-slate-200' ?>" href="leaderboard.php?period=all">All Time</a></div></div>
 <?php if (!$workerRows): ?><div class="rounded-xl border border-dashed border-slate-600 p-6 text-center text-slate-400">No employees have joined this business yet.</div><?php else: ?>
 <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-5 lb-podium">
 <?php foreach (array_slice($workerRows,0,3) as $i=>$r): $medals=['🥇','🥈','🥉']; ?><div class="lb-podium-card rounded-xl border <?= $i===0?'border-amber-300/50 bg-amber-300/10':'border-slate-700 bg-slate-900/60' ?> p-4 text-center"><div class="text-3xl mb-1"><?= $medals[$i] ?></div><div class="font-bold truncate"><?= lbEscape($r['username']) ?><?= (int)$r['user_id']===$uid?' · You':'' ?></div><div class="text-sm text-slate-400 mt-1"><?= (int)$r['projects_completed'] ?> projects completed</div><div class="font-bold mt-1 <?= (int)$r['points'] < 0 ? 'text-rose-300' : 'text-teal-300' ?>"><?= (int)$r['points'] ?> points</div></div><?php endforeach; ?>
 </div>
 <div class="lb-table-wrap"><table class="lb-table w-full text-sm"><thead class="bg-slate-900 text-slate-400"><tr><th class="text-left p-3">Rank</th><th class="text-left p-3">Worker</th><th class="text-right p-3">Completed</th><th class="text-right p-3">Points</th><th class="text-left p-3">Achievements</th></tr></thead><tbody><?php foreach ($workerRows as $i=>$r): $badges=lbBadgeCount((int)$r['projects_completed'], (int)($r['month_projects'] ?? 0)); ?><tr class="border-t border-slate-700 <?= (int)$r['user_id']===$uid?'bg-teal-400/10':'' ?>"><td class="p-3 font-bold <?= $i<3?'text-amber-300':'text-slate-400' ?>">#<?= $i+1 ?></td><td class="p-3 font-semibold"><?= lbEscape($r['username']) ?><?= (int)$r['user_id']===$uid?' <span class="text-teal-300">(You)</span>':'' ?></td><td class="p-3 text-right"><?= (int)$r['projects_completed'] ?></td><td class="p-3 text-right font-bold <?= (int)$r['points'] < 0 ? 'text-rose-300' : 'text-teal-300' ?>"><?= (int)$r['points'] ?></td><td class="p-3"><div class="flex flex-wrap gap-1"><?php if (!$badges): ?><span class="text-slate-500">—</span><?php else: foreach($badges as $b): ?><span title="<?= lbEscape($b[1]) ?>" class="rounded-full bg-slate-700 px-2 py-1 text-xs"><?= $b[0] ?> <?= lbEscape($b[1]) ?></span><?php endforeach; endif; ?></div></td></tr><?php endforeach; ?></tbody></table></div>
 <?php endif; ?>
</section>
<section class="lb-panel mb-6"><h2 class="lb-section-title mb-5"><span class="lb-icon">📈</span> Your Progress</h2><div class="grid grid-cols-2 md:grid-cols-4 gap-3"><div class="lb-stat"><p class="lb-stat-label">Your Rank</p><p class="lb-stat-value mt-2"><?= $myRank ? '#'.$myRank : '—' ?></p></div><div class="lb-stat"><p class="lb-stat-label">Projects Completed</p><p class="lb-stat-value mt-2"><?= $myProjects ?></p></div><div class="lb-stat"><p class="lb-stat-label">Net Points</p><p class="lb-stat-value mt-2 <?= $myPoints < 0 ? 'text-rose-300' : 'text-teal-300' ?>"><?= $myPoints ?></p></div><div class="lb-stat"><p class="lb-stat-label">This Month</p><p class="lb-stat-value mt-2"><?= $myMonthCount ?>/3</p><p class="text-xs text-slate-500">for Consistent Contributor</p></div></div>
 <div class="mt-4"><p class="font-semibold">Your achievements</p><div class="flex flex-wrap gap-2 mt-2"><?php $myBadges=lbBadgeCount($myProjects,$myMonthCount); if (!$myBadges): ?><span class="text-sm text-slate-400">Complete your first project to earn First Step 🚀</span><?php else: foreach($myBadges as $b): ?><span class="lb-achievement border-teal-300/20 bg-teal-400/10"><?= $b[0] ?> <?= lbEscape($b[1]) ?></span><?php endforeach; endif; ?></div>
 <?php if ($remaining>0): ?><p class="text-sm text-slate-400 mt-3">Next milestone: <?= $nextMilestone===1?'First Step':($nextMilestone===5?'Rising Star':'Project Champion') ?> — <?= $remaining ?> more completed project<?= $remaining===1?'':'s' ?>.</p><?php else: ?><p class="text-sm text-slate-400 mt-3">You've reached the main project milestones. Keep contributing!</p><?php endif; ?></div></section>

</div></main></div></body></html>

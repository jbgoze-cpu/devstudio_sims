-- Optional seed: add the existing Jose Marco worker account to CheeseBoss's studio.
-- Back up the database first. Select devstudio_sims before importing.
-- The account is matched by username. If the actual username differs, replace
-- 'Jose Marco' below with the exact username shown in the users table.
-- Safe to re-run: avoids duplicate employment and duplicate employee records.

START TRANSACTION;

SET @cheeseboss_id := (
  SELECT id FROM users
  WHERE LOWER(username) = LOWER('cheeseBoss') AND LOWER(role) = 'owner'
  ORDER BY id LIMIT 1
);

SET @jose_id := (
  SELECT id FROM users
  WHERE LOWER(username) IN (LOWER('Jose Marco'), LOWER('JoseMarco'), LOWER('Jose_Marco'))
    AND LOWER(role) = 'worker'
  ORDER BY id LIMIT 1
);

-- Create/activate the real account's employment link.
INSERT INTO business_employment (owner_id, worker_id, business_name, employment_role, status)
SELECT @cheeseboss_id, @jose_id, COALESCE(NULLIF(u.business_name,''),'CheeseBoss'), 'worker', 'hired'
FROM users u
WHERE u.id = @jose_id
  AND @cheeseboss_id IS NOT NULL
  AND NOT EXISTS (
    SELECT 1 FROM business_employment e
    WHERE e.owner_id = @cheeseboss_id AND e.worker_id = @jose_id AND e.status = 'hired'
  );

-- Add the corresponding simulated employee row so Jose also appears in Team Management.
INSERT INTO employees (business_owner_id, name, role, salary, morale, efficiency, status)
SELECT @cheeseboss_id, u.username, 'Software Developer', 4500, 0, 0, 'active'
FROM users u
WHERE u.id = @jose_id
  AND @cheeseboss_id IS NOT NULL
  AND NOT EXISTS (
    SELECT 1 FROM employees e
    WHERE e.business_owner_id = @cheeseboss_id AND LOWER(e.name) = LOWER(u.username)
  );

-- Notify CheeseBoss and Jose Marco if the account match succeeded.
INSERT INTO business_notifications (user_id, title, body, link_url, is_read)
SELECT @cheeseboss_id, 'Team member added', CONCAT(u.username, ' was added to your studio team.'), 'team.php', 0
FROM users u
WHERE u.id = @jose_id AND @cheeseboss_id IS NOT NULL
  AND EXISTS (SELECT 1 FROM business_employment e WHERE e.owner_id=@cheeseboss_id AND e.worker_id=@jose_id AND e.status='hired');

INSERT INTO business_notifications (user_id, title, body, link_url, is_read)
SELECT @jose_id, 'You joined CheeseBoss', 'You have been added to the CheeseBoss studio team.', 'demo.php', 0
WHERE @jose_id IS NOT NULL AND @cheeseboss_id IS NOT NULL
  AND EXISTS (SELECT 1 FROM business_employment e WHERE e.owner_id=@cheeseboss_id AND e.worker_id=@jose_id AND e.status='hired');

COMMIT;

-- Verification: if this returns no rows, the username did not match an existing worker account.
SELECT u.id, u.username, e.owner_id, owner.username AS studio_owner,
       e.employment_role, e.status
FROM business_employment e
JOIN users u ON u.id = e.worker_id
JOIN users owner ON owner.id = e.owner_id
WHERE LOWER(owner.username) = LOWER('cheeseBoss')
  AND LOWER(u.username) IN (LOWER('Jose Marco'), LOWER('JoseMarco'), LOWER('Jose_Marco'));

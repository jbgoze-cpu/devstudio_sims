<?php
session_start();
require_once 'db.php';
requireLogin();
verifyAppCsrfPost();
$me = currentUser();
$error = '';
$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $businessName = trim($_POST['business_name'] ?? '');
    $businessLocation = trim($_POST['business_location'] ?? '');
    $newPassword = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    if ($username === '' || strlen($username) > 80) $error = 'Username is required and must be 80 characters or fewer.';
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) $error = 'Enter a valid email address.';
    elseif ($newPassword !== '' && strlen($newPassword) < 8) $error = 'New password must be at least 8 characters.';
    elseif ($newPassword !== $confirmPassword) $error = 'New password and confirmation do not match.';
    else {
        $stmt = $conn->prepare('SELECT id FROM users WHERE (username=? OR email=?) AND id<>? LIMIT 1');
        $stmt->bind_param('ssi', $username, $email, $me['id']); $stmt->execute();
        if ($stmt->get_result()->num_rows) $error = 'That username or email is already used by another account.';
        else {
            if (($me['role'] ?? '') === 'owner') {
                $stmt = $conn->prepare('UPDATE users SET username=?, email=?, business_name=?, business_location=? WHERE id=?');
                $stmt->bind_param('ssssi', $username, $email, $businessName, $businessLocation, $me['id']);
            } else {
                $stmt = $conn->prepare('UPDATE users SET username=?, email=? WHERE id=?');
                $stmt->bind_param('ssi', $username, $email, $me['id']);
            }
            if ($stmt->execute()) {
                if ($newPassword !== '') { $hash = password_hash($newPassword, PASSWORD_DEFAULT); $pw = $conn->prepare('UPDATE users SET password_hash=? WHERE id=?'); $pw->bind_param('si', $hash, $me['id']); $pw->execute(); }
                $_SESSION['username'] = $username;
                $me = currentUser(); $success = 'Profile updated successfully.';
            } else $error = 'Could not save your profile. Please try again.';
        }
    }
}
function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Edit Profile | DEVSTUDIO SIMS</title><script src="https://cdn.tailwindcss.com"></script><link rel="stylesheet" href="assets/theme.css"></head><body class="bg-slate-900 text-white"><div class="ds-app-shell"><?php include 'partial_nav.php'; ?><main class="ds-main"><header class="mb-8"><div class="ds-eyebrow">ACCOUNT</div><h1 class="text-3xl font-bold">Edit Profile</h1><p class="text-slate-400 mt-2">Keep your account details up to date.</p></header>
<section class="ds-panel accent-process max-w-3xl">
<?php if ($error): ?><div class="ds-alert error mb-4"><?=h($error)?></div><?php endif; ?><?php if ($success): ?><div class="ds-alert success mb-4"><?=h($success)?></div><?php endif; ?>
<form method="post" class="space-y-5"><?= appCsrfField() ?><div><label for="username" class="block text-sm mb-2">Username</label><input id="username" name="username" maxlength="80" required value="<?=h($me['username'] ?? '')?>" class="ds-input w-full"></div><div><label for="email" class="block text-sm mb-2">Email</label><input id="email" type="email" name="email" required value="<?=h($me['email'] ?? '')?>" class="ds-input w-full"></div>
<?php if (($me['role'] ?? '') === 'owner'): ?><div class="border-t border-slate-700 pt-5"><h2 class="font-bold text-lg mb-4">Business Profile</h2><div class="space-y-4"><div><label for="business_name" class="block text-sm mb-2">Business Name</label><input id="business_name" name="business_name" maxlength="150" value="<?=h($me['business_name'] ?? '')?>" class="ds-input w-full"></div><div><label for="business_location" class="block text-sm mb-2">Business Location</label><input id="business_location" name="business_location" maxlength="255" value="<?=h($me['business_location'] ?? '')?>" class="ds-input w-full"></div></div></div><?php endif; ?>
<div class="border-t border-slate-700 pt-5"><h2 class="font-bold text-lg mb-1">Change Password</h2><p class="text-slate-400 text-sm mb-4">Leave both fields blank to keep your current password.</p><div class="space-y-4"><div><label for="new_password" class="block text-sm mb-2">New Password</label><input id="new_password" type="password" name="new_password" minlength="8" autocomplete="new-password" class="ds-input w-full"></div><div><label for="confirm_password" class="block text-sm mb-2">Confirm New Password</label><input id="confirm_password" type="password" name="confirm_password" minlength="8" autocomplete="new-password" class="ds-input w-full"></div></div></div><div class="flex flex-wrap gap-3"><button class="ds-btn primary" type="submit">Save Changes</button><a href="settings.php" class="ds-btn">Back to Settings</a></div></form></section></main></div></body></html>

<?php
session_start();
require_once 'db.php';
requireLogin();
require_once 'business_helpers.php';
$me = currentUser();
$uid = (int)$me['id'];
$otherId = filter_input(INPUT_GET, 'user_id', FILTER_VALIDATE_INT) ?: filter_input(INPUT_POST, 'user_id', FILTER_VALIDATE_INT);
if (!$otherId || $otherId === $uid) { http_response_code(400); exit('Choose a valid user to message.'); }
$conn->query("CREATE TABLE IF NOT EXISTS direct_messages (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  sender_id INT NOT NULL,
  recipient_id INT NOT NULL,
  message TEXT NOT NULL,
  sent_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_direct_pair (sender_id, recipient_id, sent_at),
  INDEX idx_direct_recipient (recipient_id, sent_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$q = $conn->prepare('SELECT id, username, role FROM users WHERE id=? LIMIT 1');
$q->bind_param('i', $otherId); $q->execute(); $other = $q->get_result()->fetch_assoc();
if (!$other) { http_response_code(404); exit('User not found.'); }
// Workers may initiate contact with owners before hiring. Other direct conversations
// are permitted only when either side is an owner, or the users already share a hired business.
$allowed = (($me['role'] ?? '') === 'worker' && ($other['role'] ?? '') === 'owner') || (($me['role'] ?? '') === 'owner' && ($other['role'] ?? '') === 'worker');
if (!$allowed) {
  $check = $conn->prepare("SELECT 1 FROM business_employment WHERE status='hired' AND ((owner_id=? AND worker_id=?) OR (owner_id=? AND worker_id=?)) LIMIT 1");
  $check->bind_param('iiii', $uid, $otherId, $otherId, $uid); $check->execute();
  $allowed = (bool)$check->get_result()->fetch_row();
}
if (!$allowed) { http_response_code(403); exit('You cannot message this user.'); }
if (empty($_SESSION['direct_chat_csrf'])) $_SESSION['direct_chat_csrf'] = bin2hex(random_bytes(32));
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!hash_equals((string)$_SESSION['direct_chat_csrf'], (string)($_POST['csrf'] ?? ''))) { http_response_code(400); exit('Session expired. Refresh the page and try again.'); }
  $body = trim((string)($_POST['message'] ?? ''));
  if ($body !== '') {
    $ins = $conn->prepare('INSERT INTO direct_messages (sender_id, recipient_id, message) VALUES (?,?,?)');
    $ins->bind_param('iis', $uid, $otherId, $body); $ins->execute();
    if (function_exists('businessNotify')) businessNotify($conn, $otherId, 'New private message', 'You received a new direct message from '.$me['username'].'.', 'direct_chat.php?user_id='.$uid);
  }
  header('Location: direct_chat.php?user_id='.$otherId); exit;
}
$q = $conn->prepare('SELECT m.message,m.sent_at,u.username,m.sender_id FROM direct_messages m JOIN users u ON u.id=m.sender_id WHERE (m.sender_id=? AND m.recipient_id=?) OR (m.sender_id=? AND m.recipient_id=?) ORDER BY m.sent_at ASC');
$q->bind_param('iiii', $uid, $otherId, $otherId, $uid); $q->execute(); $messages = $q->get_result()->fetch_all(MYSQLI_ASSOC);
function dc_h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
$back = (($me['role'] ?? '') === 'worker') ? 'worker_messages.php' : 'team.php';
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Direct Chat</title><script src="https://cdn.tailwindcss.com"></script><link rel="stylesheet" href="assets/theme.css"></head><body class="bg-slate-900 text-white"><main class="max-w-3xl mx-auto p-4 md:p-6"><a class="ds-btn" href="<?=dc_h($back)?>">← Back to Chatbox</a><header class="my-6"><p class="text-xs uppercase tracking-widest text-cyan-300">Private messages</p><h1 class="text-2xl md:text-3xl font-bold mt-1">Chat with <?=dc_h($other['username'])?></h1><p class="text-slate-400 mt-2">You can message each other without an employment connection.</p></header><section class="ds-panel space-y-4 min-h-40 mb-5"><?php if (!$messages): ?><p class="text-slate-400">No messages yet. Start the conversation below.</p><?php endif; ?><?php foreach ($messages as $m): ?><div class="border-b border-slate-700/70 pb-3"><p class="text-cyan-300 font-semibold"><?=dc_h($m['username'])?> <span class="text-xs text-slate-500 font-normal"><?=dc_h($m['sent_at'])?></span></p><p class="whitespace-pre-wrap break-words"><?=dc_h($m['message'])?></p></div><?php endforeach; ?></section><form method="post" class="ds-panel"><input type="hidden" name="csrf" value="<?=dc_h($_SESSION['direct_chat_csrf'])?>"><input type="hidden" name="user_id" value="<?=$otherId?>"><label for="message" class="block mb-2">Message</label><textarea id="message" name="message" required maxlength="3000" class="w-full bg-slate-800 rounded-lg p-3" rows="3" placeholder="Write a message..."></textarea><button class="ds-btn process mt-3" type="submit">Send Message</button></form></main></body></html>

<?php
session_start();
require_once 'db.php';
requireLogin();
require_once 'business_helpers.php';
$me = currentUser();
if (($me['role'] ?? '') !== 'worker') { header('Location: inbox.php'); exit; }
$uid = (int)$me['id'];
// Chatbox conversations are tied to the exact business the worker requested to join,
// or the business that has hired them. Do not show unrelated business owners here.
$stmt = $conn->prepare("SELECT e.id,e.business_name,e.employment_role,e.status,e.created_at,e.updated_at,o.username AS owner_name,o.id AS owner_id FROM business_employment e JOIN users o ON o.id=e.owner_id WHERE e.worker_id=? AND (e.status='hired' OR (e.status='pending' AND e.created_at >= DATE_SUB(NOW(), INTERVAL 3 DAY))) ORDER BY CASE WHEN e.status='pending' THEN 0 ELSE 1 END,e.updated_at DESC");
$stmt->bind_param('i',$uid); $stmt->execute(); $rows=$stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
function wm_h($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Chatbox</title><script src="https://cdn.tailwindcss.com"></script><link rel="stylesheet" href="assets/theme.css"></head><body class="bg-slate-900 text-white"><main class="max-w-4xl mx-auto p-4 md:p-6"><a class="ds-btn" href="demo.php">Back to Dashboard</a><header class="my-6"><p class="text-xs uppercase tracking-widest text-cyan-300">Workplace communication</p><h1 class="text-2xl md:text-3xl font-bold mt-1">Chatbox</h1><p class="text-slate-400 mt-2">Chat only with the owner/manager of the business you requested to join, or the business that hired you.</p></header>
<?php if(!$rows): ?><section class="ds-panel mb-5"><h2 class="text-lg font-semibold">No business conversation yet</h2><p class="text-slate-400 mt-2">Choose a business and send a request to join. Once your request is sent, this Chatbox will connect you with that specific business owner/manager while you wait for approval.</p><a class="ds-btn process inline-block mt-4" href="find_business.php">Find a Business</a></section><?php else: ?><section><h2 class="text-xl font-semibold mb-3">Your Business Conversations</h2><div class="grid gap-3"><?php foreach($rows as $row): $pending = $row['status'] === 'pending'; ?><article class="ds-panel flex flex-col sm:flex-row sm:items-center gap-4 justify-between"><div><h2 class="font-semibold text-lg"><?=wm_h($row['business_name'] ?: 'Business')?></h2><p class="text-slate-400 text-sm mt-1">Owner/Manager: <?=wm_h($row['owner_name'])?></p><p class="text-xs mt-2 <?= $pending ? 'text-amber-300' : 'text-emerald-300' ?>"><?= $pending ? 'Request pending — you can chat while waiting for approval' : 'Hired — active business conversation' ?></p></div><a class="ds-btn process text-center" href="inbox.php?employment_id=<?=(int)$row['id']?>">Open Chat →</a></article><?php endforeach; ?></div></section><?php endif; ?></main></body></html>

<?php
/* Shared role, audit-log, and notification helpers for DEVSTUDIO SIMS. */
if (!function_exists('businessEnsureAuditTables')) {
function businessEnsureAuditTables(mysqli $conn): void {
    if (!tableExists('business_activity_logs')) $conn->query("CREATE TABLE IF NOT EXISTS business_activity_logs (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      owner_id INT NOT NULL,
      actor_id INT NOT NULL,
      action VARCHAR(180) NOT NULL,
      details TEXT NOT NULL,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_business_activity_owner_date (owner_id, created_at),
      INDEX idx_business_activity_actor (actor_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    if (!tableExists('business_notifications')) $conn->query("CREATE TABLE IF NOT EXISTS business_notifications (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      title VARCHAR(180) NOT NULL,
      body TEXT NOT NULL,
      link_url VARCHAR(500) NOT NULL DEFAULT 'demo.php',
      is_read TINYINT(1) NOT NULL DEFAULT 0,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_business_notifications_user_date (user_id, created_at),
      INDEX idx_business_notifications_unread (user_id, is_read)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}
}
if (!function_exists('businessRoleForUser')) {
function businessRoleForUser(mysqli $conn, ?array $me): string {
    if (!$me) return 'guest';
    if (($me['role'] ?? '') === 'owner') return 'owner';
    if (!function_exists('tableExists') || !tableExists('business_employment')) return 'worker';
    $uid=(int)($me['id']??0);
    $stmt=$conn->prepare("SELECT employment_role FROM business_employment WHERE worker_id=? AND status='hired' ORDER BY updated_at DESC LIMIT 1");
    if(!$stmt)return 'worker';
    $stmt->bind_param('i',$uid);$stmt->execute();$row=$stmt->get_result()->fetch_assoc();$stmt->close();
    return (($row['employment_role']??'')==='manager')?'manager':'worker';
}
}
if (!function_exists('businessOwnerForUser')) {
function businessOwnerForUser(mysqli $conn, ?array $me): ?int {
    if (!$me) return null;
    if (($me['role']??'')==='owner') return (int)$me['id'];
    if (function_exists('currentBusinessOwnerId')) return (int)(currentBusinessOwnerId()??0) ?: null;
    if (!function_exists('tableExists') || !tableExists('business_employment')) return null;
    $uid=(int)($me['id']??0);
    $stmt=$conn->prepare("SELECT owner_id FROM business_employment WHERE worker_id=? AND status='hired' ORDER BY updated_at DESC LIMIT 1");
    if(!$stmt)return null;
    $stmt->bind_param('i',$uid);$stmt->execute();$row=$stmt->get_result()->fetch_assoc();$stmt->close();
    return $row?(int)$row['owner_id']:null;
}
}
if (!function_exists('businessEsc')) {
function businessEsc($value): string { return htmlspecialchars((string)$value,ENT_QUOTES,'UTF-8'); }
}
if (!function_exists('businessLog')) {
function businessLog(mysqli $conn, int $ownerId, int $actorId, string $action, string $details): bool {
    businessEnsureAuditTables($conn);
    $stmt=$conn->prepare("INSERT INTO business_activity_logs (owner_id,actor_id,action,details) VALUES (?,?,?,?)");
    if(!$stmt)return false;
    $stmt->bind_param('iiss',$ownerId,$actorId,$action,$details);$ok=$stmt->execute();$stmt->close();return $ok;
}
}
if (!function_exists('businessNotify')) {
function businessNotify(mysqli $conn, int $userId, string $title, string $body, string $linkUrl='demo.php'): bool {
    businessEnsureAuditTables($conn);
    if (!preg_match('/^[a-zA-Z0-9_./?=&%#-]{1,500}$/',$linkUrl) || str_starts_with($linkUrl,'//') || str_contains($linkUrl,':')) $linkUrl='demo.php';
    $stmt=$conn->prepare("INSERT INTO business_notifications (user_id,title,body,link_url) VALUES (?,?,?,?)");
    if(!$stmt)return false;
    $stmt->bind_param('isss',$userId,$title,$body,$linkUrl);$ok=$stmt->execute();$stmt->close();return $ok;
}
}
businessEnsureAuditTables($conn);

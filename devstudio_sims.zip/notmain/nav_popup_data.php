<?php
session_start();
require_once __DIR__ . '/db.php';
requireLogin();
require_once __DIR__ . '/business_helpers.php';
header('Content-Type: application/json; charset=utf-8');
$me = currentUser();
$role = businessRoleForUser($conn, $me);
$ownerId = businessOwnerForUser($conn, $me);
if (empty($_SESSION['nav_popup_csrf'])) $_SESSION['nav_popup_csrf'] = bin2hex(random_bytes(32));
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = (string)($_POST['csrf'] ?? '');
    if (!hash_equals((string)$_SESSION['nav_popup_csrf'], $token)) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Session expired. Refresh the page.']); exit; }
    if (($_POST['action'] ?? '') === 'read_all') {
        $stmt = $conn->prepare('UPDATE business_notifications SET is_read=1 WHERE user_id=? AND is_read=0');
        if ($stmt) { $stmt->bind_param('i', $me['id']); $stmt->execute(); $stmt->close(); }
        echo json_encode(['ok'=>true]); exit;
    }
    $id = (int)($_POST['notification_id'] ?? 0);
    if ($id > 0) {
        $stmt = $conn->prepare('UPDATE business_notifications SET is_read=1 WHERE id=? AND user_id=?');
        if ($stmt) { $stmt->bind_param('ii', $id, $me['id']); $stmt->execute(); $stmt->close(); }
    }
    echo json_encode(['ok'=>true]); exit;
}
$out = ['ok'=>true,'csrf'=>$_SESSION['nav_popup_csrf'],'notifications'=>[],'activity'=>[],'unread'=>0];
try {
    $stmt = $conn->prepare('SELECT id,title,body,link_url,is_read,created_at FROM business_notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 8');
    $stmt->bind_param('i', $me['id']); $stmt->execute(); $out['notifications'] = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt = $conn->prepare('SELECT COUNT(*) AS n FROM business_notifications WHERE user_id=? AND is_read=0');
    $stmt->bind_param('i', $me['id']); $stmt->execute(); $out['unread'] = (int)($stmt->get_result()->fetch_assoc()['n'] ?? 0);
} catch (Throwable $e) { /* notifications migration may not be installed yet */ }
if ($ownerId && in_array($role, ['owner','manager'], true)) {
    try {
        $stmt = $conn->prepare('SELECT l.action,l.details,l.created_at,u.username FROM business_activity_logs l JOIN users u ON u.id=l.actor_id WHERE l.owner_id=? ORDER BY l.created_at DESC LIMIT 8');
        $stmt->bind_param('i', $ownerId); $stmt->execute(); $out['activity'] = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    } catch (Throwable $e) { /* activity log migration may not be installed yet */ }
}
echo json_encode($out, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP);

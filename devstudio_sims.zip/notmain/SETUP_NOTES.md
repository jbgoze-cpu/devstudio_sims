# DEVSTUDIO SIMS — Setup and Quality Improvements

This package is the PHP/MySQL system for **DEVSTUDIO SIMS: A Gamified Software Development Business Management Using Analytics and Decision Modeling**. It is an educational simulation, not enterprise software. The financial entries are simulated; the system does not process real payments or payroll. Studio Owner registration asks for a business name, location, and starting simulated cash; the entered cash is saved as that studio's opening balance.

## Before installing
1. Back up `C:\xampp\htdocs\up-main` and export the `devstudio_sims` database in phpMyAdmin.
2. Extract this ZIP so the PHP files are directly inside `C:\xampp\htdocs\up-main`.
3. Start Apache and MySQL in XAMPP.
4. Confirm `db.php` uses the credentials for your local MySQL server.

## Database setup
Import only the migrations your current database still needs. Do not run an `ALTER TABLE` migration twice if the column already exists.

1. `schema_additions.sql` — creates/extends supporting tables for users, project milestones/team assignment, training, contracts, upgrades, and related system data. It expects the existing base tables used by the original system (including `projects`, `employees`, and `game_state`) to be present.
2. `business_core_migration.sql` — creates employment, private messaging, schedule, attendance, notification, and activity-log tables used by the included pages.
3. `project_business_migration.sql` — adds `projects.business_owner_id` and assigns legacy projects to the earliest registered Team Leader. Run once only if that column is not already present.
4. `employee_business_migration.sql` — adds `employees.business_owner_id`, assigns legacy employees to the earliest registered Team Leader, and enables per-studio employee privacy. Run once after `users` and `employees` exist.
5. `worker_training_migration.sql` — creates the skill-training catalogue and enrollment records.
6. `simulation_business_migration.sql` — documents the business simulation state, event, and achievement tables. `simulation_helpers.php` can create these tables automatically if the database account has permission, but importing the SQL is recommended.

If you are upgrading an existing database, inspect table/column names in phpMyAdmin first and skip migrations already applied. The project and employee ownership migrations intentionally require care because they modify existing data.

## Main system modules
- **Business Dashboard (`demo.php`)** — studio status, cash (owner/manager only), active/completed projects, morale, efficiency, decision points, and shortcuts.
- **Project Management (`project_management.php`, `new_project.php`, `manage_project.php`)** — projects, budget allocation, deadlines, deliverables, risk, milestones, and simulated employee assignment.
- **Team Management (`team.php`, `training.php`)** — simulated employee hiring, promotion, removal, employee skills, and training.
- **Decision Modeling (`decision_model.php`)** — structured scenario choices for project delays, budget shortfalls, team fatigue, and client scope changes. Branch rules can alter outcomes based on current morale, efficiency, cash reserve, and reputation. The selected choice, resulting changes, and learner reflection journal are saved.
- **Business Analytics (`analytics.php`)** — studio-specific cash flow for the last 30 days, simple cash projection, project status/progress/risk, reputation, decision activity, and achievements. Layout adapts to narrow screens; morale and efficiency are not shown as studio-wide metrics.
- **Gamification (`leaderboard.php`)** — decision points and achievement badges, with a leaderboard that does not display studio cash.
- **3D Studio View (`studio3d.php`)** — a visual studio scene based on available project, employee, cash, morale, and achievement data.
- **Activity Log / Notifications / Schedule / Inbox** — records available business activity and supports relevant team communications and scheduling when employment data is configured.

## Role and data boundaries
- Studio owner and assigned manager can apply decision outcomes and record simulated financial entries.
- Team members can view allowed studio information but cannot apply business decisions or record income/expenses.
- Studio cash is hidden from regular workers.
- Project and employee queries are scoped to the currently linked studio after the relevant ownership migrations are applied.
- The leaderboard shows simulated points and public studio performance indicators only; it does not reveal cash balances or personal email addresses.

## Quality verification before using the questionnaire
Run `QUALITY_TEST_PLAN.md` after migrations. Check each item manually in a browser and record Pass/Fail, tester, date, and evidence. PHP syntax checks alone do not establish that the app works against your actual database. In particular, test:
- two separate Team Leader accounts to confirm project, employee, decision, achievement, and activity records do not cross studios;
- decision options that cost more than available cash;
- persistence after logout/login and after restarting Apache/MySQL;
- worker permissions, file-submission boundaries, and private notifications;
- mobile and desktop layout at common viewport sizes.

The analytics cash projection is intentionally simple: it adds the last 30 days’ recorded net income/expenses to current simulated cash once. It is a learning estimate, not a reliable real-world forecast. Decision-tree results are predefined educational rules, not predictions of actual business outcomes.


### Worker feedback
Import `worker_feedback_migration.sql` once. Hired workers can submit a 1–5 rating and comments, optionally anonymously. Owners and managers can view feedback but cannot edit or delete submissions. Morale and efficiency indicators have been removed from the visible dashboards and decision choices.

### Optional synthetic project data
For a demo account that needs sample data to populate Project Management and Business Analytics, import `synthetic_demo_data.sql` after `project_business_migration.sql`. It adds three fictional sample projects only to the `cheeseBoss` owner account and skips matching project titles that already exist. It does not fabricate historical decision/finance records or change cash balances. Back up the database first.

### Project creation workflow
Studio owners/managers complete the project form, select **Review & Confirm Project**, review the title, description, budget, deadline, priority, and deliverables, then select **Confirm & Distribute Project**. The project is saved in the studio's shared project workspace, and the owner plus all currently hired teammates receive notifications. Teammates submit deliverables through Project Management; progress is based on matching submitted filenames against the required deliverables. A complete set moves the project to Completed.

### Optional sample team for CheeseBoss
If the `cheeseBoss` owner account already exists and you want sample employees to appear in Team Management, import `cheeseboss_sample_team.sql` once in phpMyAdmin after `employee_business_migration.sql`. It adds four sample team members only to that account, with fictional salaries and zeroed legacy morale/efficiency values. It will not duplicate those sample names if run again. If the account username differs, edit the `cheeseBoss` username in the SQL before importing. Back up the database first.

-- Worker feedback is append-only: management can read it but cannot edit or delete it.
CREATE TABLE IF NOT EXISTS worker_feedback (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 owner_id INT NOT NULL,
 worker_id INT NOT NULL,
 rating TINYINT UNSIGNED NOT NULL,
 comments TEXT NOT NULL,
 is_anonymous TINYINT(1) NOT NULL DEFAULT 0,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_feedback_owner_date (owner_id, created_at),
 INDEX idx_feedback_worker_date (worker_id, created_at),
 CONSTRAINT chk_worker_feedback_rating CHECK (rating BETWEEN 1 AND 5)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

# DEVSTUDIO SIMS — Quality Verification Plan

Use this checklist after importing the database migrations. Mark results only after actually running each test; do not assume a pass from code inspection alone.

## Functional suitability
- [ ] Owner can create a project with valid title, deadline, priority, deliverables, and budget.
- [ ] A budget larger than available cash is rejected without changing project or cash values.
- [ ] Worker can submit an allowed file to a project in their current business.
- [ ] Successful submission is archived and marks the project completed as specified.
- [ ] Unauthorized roles cannot create projects, change budgets, or access another business's project.

## Performance efficiency
- [ ] Record response times for dashboard, project list, analytics, and submission archive with 1, 25, and 100 test records.
- [ ] Confirm no repeated SQL error messages appear in PHP/MySQL logs.
- [ ] Confirm the layout remains usable at 1366x768 and 1920x1080 without horizontal overflow.

## Interaction capability
- [ ] Test navigation and forms on desktop and mobile widths.
- [ ] Confirm validation messages explain how to correct invalid input.
- [ ] Check the evaluation checklist, reload the page, and confirm saved browser state returns.
- [ ] Use Reset checklist and confirm all marks clear after confirmation.

## Reliability
- [ ] Submit a file, sign out, sign in again, and confirm the submission remains available to authorized users.
- [ ] Restart Apache/MySQL and confirm persisted project and submission data remain intact.
- [ ] Try a zero-byte file, oversized file, unsupported extension, and a file whose contents do not match its extension; all must be rejected.
- [ ] Test missing optional tables/migrations and confirm the application shows a useful setup notice or safely withholds data.

## Security and privacy
- [ ] Create two owner accounts and verify that project lists, review lists, and submission archives do not cross business boundaries.
- [ ] Verify a worker with no active employment cannot access an owner's projects.
- [ ] Attempt to access a submission by changing its numeric ID; only files belonging to the user's current business should be returned.
- [ ] Confirm uploads are served only through the authenticated view/download endpoints and the uploads directory cannot execute scripts.
- [ ] Review PHP and web-server logs for exposed credentials, SQL errors, or stack traces.

## Recording results
For every item, record Pass/Fail, tester, date, test data, and evidence (such as a screenshot or log entry). Report the real result even when a test fails; fix failures and repeat the test before assigning a higher quality score.


## Business simulation and decision modeling
- [ ] Apply each decision-tree scenario and confirm the cash, morale, efficiency, reputation, and points changes match the displayed outcome.
- [ ] Try an option that costs more than available studio cash; confirm it is rejected and neither cash nor metrics change.
- [ ] Record simulated income and expenses; confirm owner cash and the 30-day cash-flow analytics update. Confirm no real payment is processed.
- [ ] Confirm decisions and finance entries remain after logout/login and only appear for the same studio.
- [ ] Unlock an achievement and confirm its badge and points are saved without awarding it twice.
- [ ] Save a decision reflection, reload the page, and confirm the reflection remains linked to the same studio.
- [ ] Confirm the studio leaderboard ranks by points and does not display studio cash or private account information.
- [ ] Confirm workers cannot submit decision or finance actions and cannot view cash flow; owner/manager can manage decisions.
- [ ] Create two studios and confirm employee lists, project lists, simulation state, activity history, and achievements are separated by studio.
- [ ] Check charts/bars, scenario choices, and cards at desktop and mobile widths.

- [ ] Submit a state-changing form without its CSRF token (project creation, employee action, schedule, notification, or private message); the request should be rejected without changing data.

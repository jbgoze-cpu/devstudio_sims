DEVSTUDIO SIMS — analytics.php compatibility fix

This patch fixes the fatal error when requireWorkerBusinessMembership() is missing from the installed business_helpers.php. It adds a guarded fallback directly in analytics.php and keeps the hired-worker membership check.

Install: back up C:\xampp\htdocs\up-main\analytics.php, extract this ZIP, and copy up-main/analytics.php into C:\xampp\htdocs\up-main\analytics.php. This ZIP only contains analytics.php and a README; it does not replace the rest of your app.

Important: built from the most recent project archive available in this chat, which may not include changes made after that archive. PHP syntax was checked; not tested against your live database.

Compact layout update: reduced outer padding, card padding, gaps, and repeated section spacing to use the available Business Analytics screen more efficiently. No metric calculations or permissions were changed.

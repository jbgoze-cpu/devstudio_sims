<?php
session_start();
require_once "db.php";
require_once "business_helpers.php";

requireLogin();
verifyAppCsrfPost();

if (!columnExists('projects', 'required_deliverables')) {
    $conn->query("ALTER TABLE projects ADD COLUMN required_deliverables TEXT NULL");
}

/*======================================
    MANAGE SINGLE PROJECT
======================================*/

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);

$project = getProject($id);
$currentUser = currentUser();
$isTeamLeader = in_array(businessRoleForUser($conn, $currentUser), ['owner','manager'], true);

if (!$project) {
    $_SESSION['flash'] = [
        "type" => "error",
        "message" => "Project not found."
    ];
    header("Location: project_management.php");
    exit;
}

// Project details and management controls are reserved for Team Leaders.
if (!$isTeamLeader) {
    $_SESSION['flash'] = ["type" => "error", "message" => "Only studio owners and managers can view and manage project details."];
    header("Location: evaluation.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $action = $_POST['action'] ?? '';

    switch ($action) {

        case 'save_canvas':
            $user = currentUser();
            $canvasContent = trim($_POST['canvas_content'] ?? '');
            $conn->query("CREATE TABLE IF NOT EXISTS project_canvas (project_id INT PRIMARY KEY, content MEDIUMTEXT NOT NULL, updated_by INT NULL, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            $stmt = $conn->prepare("INSERT INTO project_canvas (project_id, content, updated_by) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE content=VALUES(content), updated_by=VALUES(updated_by), updated_at=CURRENT_TIMESTAMP");
            $uid = (int)($user['id'] ?? 0);
            $stmt->bind_param('isi', $id, $canvasContent, $uid);
            $stmt->execute();
            $_SESSION['flash'] = ["type" => "success", "message" => "Project Canvas saved."];
        break;

        case 'assign_team':

            $result = assignTeamToProject($id);

            $_SESSION['flash'] = $result['ok']
                ? ["type" => "success", "message" => "Team assigned. Risk level is now {$result['risk']}."]
                : ["type" => "error", "message" => $result['error']];

        break;

        case 'add_employee':

            $employeeId = (int)($_POST['employee_id'] ?? 0);

            if ($employeeId > 0 && tableExists('project_team')) {
                addEmployeeToProject($id, $employeeId);
                $_SESSION['flash'] = ["type" => "success", "message" => "Team member added to the project."];
            }

        break;

        case 'remove_employee':

            $employeeId = (int)($_POST['employee_id'] ?? 0);

            if ($employeeId > 0 && tableExists('project_team')) {
                removeEmployeeFromProject($id, $employeeId);
                $_SESSION['flash'] = ["type" => "warning", "message" => "Team member removed from the project."];
            }

        break;

        case 'delete':

            deleteProject($id);

            $_SESSION['flash'] = [
                "type" => "warning",
                "message" => "Project deleted."
            ];

            header("Location: project_management.php");
            exit;
    }

    header("Location: manage_project.php?id=" . $id);
    exit;
}

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

// Re-fetch project in case anything changed above
$project = getProject($id);

$game = getGameState();

$teamAssignEnabled = tableExists('project_team');
$requiredDeliverables = array_values(array_filter(array_map('trim', preg_split('/[,\n\r]+/', (string)($project['required_deliverables'] ?? '')))));
$submittedNames = [];
$conn->query("CREATE TABLE IF NOT EXISTS project_submissions (id INT AUTO_INCREMENT PRIMARY KEY, project_id INT NOT NULL, user_id INT NOT NULL, original_name VARCHAR(255) NOT NULL, stored_name VARCHAR(255) NOT NULL, submitted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, INDEX idx_project_submissions_project (project_id), INDEX idx_project_submissions_user (user_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$subStmt = $conn->prepare("SELECT original_name FROM project_submissions WHERE project_id=?");
$subStmt->bind_param('i', $id); $subStmt->execute();
foreach ($subStmt->get_result()->fetch_all(MYSQLI_ASSOC) as $subRow) $submittedNames[] = strtolower(preg_replace('/[^a-z0-9]+/i', ' ', pathinfo($subRow['original_name'], PATHINFO_FILENAME)));
$doneDeliverables = 0;
foreach ($requiredDeliverables as $deliverable) {
    $needle = strtolower(trim(preg_replace('/[^a-z0-9]+/i', ' ', $deliverable)));
    foreach ($submittedNames as $submittedName) {
        if ($needle !== '' && (strpos($submittedName, $needle) !== false || strpos($needle, $submittedName) !== false)) { $doneDeliverables++; break; }
    }
}
$autoProgress = count($requiredDeliverables) ? (int)round($doneDeliverables / count($requiredDeliverables) * 100) : 0;
$teamAssignEnabled = tableExists('project_team');

$assignedTeam = $teamAssignEnabled ? getProjectTeamMembers($id) : [];
$unassignedTeam = $teamAssignEnabled ? getUnassignedActiveEmployees($id) : [];
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Manage Project | DEVSTUDIO SIMS</title>

<script src="https://cdn.tailwindcss.com"></script>

<script src="https://unpkg.com/lucide@latest"></script>

<link rel="stylesheet" href="assets/theme.css">
<style>
  .project-panel{background:linear-gradient(145deg,rgba(30,41,59,.98),rgba(15,23,42,.96));border:1px solid rgba(148,163,184,.16);border-radius:1rem;box-shadow:0 12px 28px rgba(2,6,23,.18)}
  .project-stat{background:rgba(15,23,42,.58);border:1px solid rgba(148,163,184,.12);border-radius:.8rem;padding:1rem;min-width:0}
  .project-action{transition:background .18s ease,transform .18s ease}
  .project-action:hover{transform:translateY(-1px)}
  @media(max-width:640px){.project-heading{font-size:1.75rem;line-height:1.2}.project-panel{padding:1.1rem!important}.project-top{align-items:stretch;flex-direction:column}.project-back{width:100%;text-align:center}}
</style>

</head>

<body class="bg-slate-900 text-white">

<div class="ds-shell">

<?php include "partial_nav.php"; ?>

<div class="ds-main">

<div class="project-top flex justify-between items-center gap-5 mb-8">

<div>

<h1 class="project-heading text-4xl font-bold break-words">

<?= htmlspecialchars($project['title']) ?>

</h1>

<p class="text-slate-400 mt-2">

View project details, track submitted deliverables, and collaborate using the Project Canvas.

</p>

</div>

<a
href="project_management.php"
class="project-back bg-slate-700 hover:bg-slate-600 px-5 py-3 rounded-lg font-semibold transition">

Back

</a>

</div>

<?php if($flash): ?>

<div class="mb-6 rounded-lg p-4
<?= $flash['type']=="success" ? "bg-emerald-600" :
($flash['type']=="warning" ? "bg-yellow-600" : "bg-red-600") ?>">

<?= htmlspecialchars($flash['message']) ?>

</div>

<?php endif; ?>

<!-- ===================================
OVERVIEW
=================================== -->

<div class="project-panel p-8 mb-6">

<div class="flex justify-between items-start">

<p class="text-slate-300 max-w-2xl">

<?= htmlspecialchars($project['description']) ?>

</p>

<span class="px-3 py-1 rounded-full bg-blue-600 whitespace-nowrap">

<?= htmlspecialchars($project['status']) ?>

</span>

</div>

<div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 mt-7">

<div class="project-stat">

<div class="text-slate-400 text-sm mb-2">Progress</div>

<div class="font-bold text-cyan-400 text-2xl"><?= $autoProgress ?>%</div>

</div>

<div class="project-stat">

<div class="text-slate-400 text-sm mb-2">Budget</div>

<div class="font-bold text-green-400 text-2xl">₱<?= number_format($project['budget']) ?></div>

</div>

<div class="project-stat">

<div class="text-slate-400 text-sm mb-2">Deadline</div>

<div class="font-bold text-2xl"><?= $project['deadline'] ?> Days</div>

</div>

<div class="project-stat">

<div class="text-slate-400 text-sm mb-2">Priority</div>

<div class="font-bold text-yellow-400 text-2xl"><?= htmlspecialchars($project['priority']) ?></div>

</div>

<div class="project-stat">

<div class="text-slate-400 text-sm mb-2">Risk</div>

<div class="font-bold text-red-400 text-2xl"><?= htmlspecialchars($project['risk']) ?></div>

</div>

</div>

<div class="w-full bg-slate-700 rounded-full h-3 mt-8">

<div
class="bg-blue-500 h-3 rounded-full"
style="width:<?= $autoProgress ?>%">
</div>

</div>

</div>

<!-- ===================================
ACTIONS
=================================== -->

<div class="grid grid-cols-1 xl:grid-cols-2 gap-6">

<div class="project-panel p-8">

<h2 class="text-2xl font-bold mb-6">Project Actions</h2>

<div class="flex flex-col gap-4">

<div class="rounded-lg bg-slate-900/60 p-4 space-y-3">
<p class="font-semibold">Automatic Project Progress</p>
<p class="text-sm text-slate-300">Progress is based on required deliverables submitted by team members.</p>
<div class="text-cyan-300 font-bold text-2xl"><?= $autoProgress ?>%</div>
<div class="w-full h-2 bg-slate-700 rounded-full"><div class="h-2 bg-cyan-500 rounded-full" style="width:<?= $autoProgress ?>%"></div></div>
<p class="text-xs text-slate-400"><?= $doneDeliverables ?> of <?= count($requiredDeliverables) ?> required deliverables received.</p>
</div>

<form method="post"><?= appCsrfField() ?>

<input type="hidden" name="action" value="assign_team">

<button class="w-full bg-indigo-600 hover:bg-indigo-500 px-5 py-3 rounded-lg font-semibold flex items-center justify-center gap-2">

<i data-lucide="users"></i>

Assign Team

</button>

</form>

<p class="text-xs text-slate-400">

Assigning your current team boosts progress and sets a risk level based on their average efficiency (<?= teamStatistics()['efficiency'] ?>% currently).

</p>

</div>

</div>
</div>

<!-- ===================================
TEAM ASSIGNMENT
=================================== -->

<?php if($teamAssignEnabled): ?>

<div class="grid grid-cols-1 xl:grid-cols-2 gap-6 mt-6">

<div class="project-panel p-8">

<h2 class="text-2xl font-bold mb-6">Assigned Team</h2>

<?php if(count($assignedTeam)==0): ?>

<div class="text-slate-400">No one is assigned yet. Add teammates from the list on the right.</div>

<?php else: ?>

<div class="flex flex-col gap-3">
<?php foreach($assignedTeam as $emp): ?>
<div class="flex justify-between items-center border border-slate-700 rounded-lg p-3">
<div>
<div class="font-semibold"><?= htmlspecialchars($emp['name']) ?></div>
<div class="text-xs text-slate-400"><?= htmlspecialchars($emp['role']) ?> &middot; <?= $emp['efficiency'] ?>% efficiency</div>
</div>
<form method="post"><?= appCsrfField() ?>
<input type="hidden" name="action" value="remove_employee">
<input type="hidden" name="employee_id" value="<?= $emp['id'] ?>">
<button class="text-slate-500 hover:text-red-400"><i data-lucide="x" class="w-4 h-4"></i></button>
</form>
</div>
<?php endforeach; ?>
</div>

<?php endif; ?>

</div>

<div class="project-panel p-8">

<h2 class="text-2xl font-bold mb-6">Available Teammates</h2>

<?php if(count($unassignedTeam)==0): ?>

<div class="text-slate-400">Everyone active is already on this project.</div>

<?php else: ?>

<div class="flex flex-col gap-3">
<?php foreach($unassignedTeam as $emp): ?>
<div class="flex justify-between items-center border border-slate-700 rounded-lg p-3">
<div>
<div class="font-semibold"><?= htmlspecialchars($emp['name']) ?></div>
<div class="text-xs text-slate-400"><?= htmlspecialchars($emp['role']) ?> &middot; <?= $emp['efficiency'] ?>% efficiency</div>
</div>
<form method="post"><?= appCsrfField() ?>
<input type="hidden" name="action" value="add_employee">
<input type="hidden" name="employee_id" value="<?= $emp['id'] ?>">
<button class="bg-indigo-600 hover:bg-indigo-500 px-3 py-2 rounded-lg text-sm">Add</button>
</form>
</div>
<?php endforeach; ?>
</div>

<?php endif; ?>

</div>

</div>

<?php endif; ?>

<!-- ===================================
DANGER ZONE
=================================== -->

<div class="project-panel p-8 mt-6">

<h2 class="text-2xl font-bold mb-4 text-red-400">Danger Zone</h2>

<p class="text-slate-400 mb-6">

Deleting this project permanently removes it. This does not refund its budget.

</p>

<form method="post" onsubmit="return confirm('Delete this project permanently?')"><?= appCsrfField() ?>

<input type="hidden" name="action" value="delete">

<button class="bg-red-600 hover:bg-red-500 px-6 py-3 rounded-lg font-semibold flex items-center gap-2">

<i data-lucide="trash-2"></i>

Delete Project

</button>

</form>

</div>

<footer class="text-center text-slate-500 text-sm py-12">

DEVSTUDIO SIMS © <?= date("Y") ?>

</footer>

</div>

</div>

<script>

lucide.createIcons();

</script>

</body>

</html>

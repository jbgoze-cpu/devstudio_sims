-- ==========================================================
-- DEVSTUDIO SIMS — SCHEMA ADDITIONS
-- Run this once against your existing devstudio_sims database.
-- Requires MySQL 8.0.29+ or MariaDB 10.0.2+ for
-- "ADD COLUMN IF NOT EXISTS". If your server is older, drop
-- the "IF NOT EXISTS" and run the ALTER statements manually.
-- ==========================================================

-- ----------------------------------------------------------
-- PROJECTS: milestones + real per-project team assignment
-- ----------------------------------------------------------

CREATE TABLE IF NOT EXISTS project_milestones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    is_done TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    completed_at DATETIME NULL,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS project_team (
    id INT AUTO_INCREMENT PRIMARY KEY,
    project_id INT NOT NULL,
    employee_id INT NOT NULL,
    assigned_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_assignment (project_id, employee_id),
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
);

-- ----------------------------------------------------------
-- CLIENT CONTRACTS
-- ----------------------------------------------------------

CREATE TABLE IF NOT EXISTS contracts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    client_name VARCHAR(255) NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    reward_cash INT NOT NULL DEFAULT 0,
    required_deadline INT NOT NULL DEFAULT 14,
    difficulty ENUM('Easy','Standard','Hard','Elite') NOT NULL DEFAULT 'Standard',
    status ENUM('offered','accepted','declined','completed') NOT NULL DEFAULT 'offered',
    project_id INT NULL,
    offered_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    resolved_at DATETIME NULL,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE SET NULL
);

-- ----------------------------------------------------------
-- TEAM: skills, training, leveling
-- ----------------------------------------------------------

CREATE TABLE IF NOT EXISTS skills (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS employee_skills (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    skill_id INT NOT NULL,
    level INT NOT NULL DEFAULT 1,
    UNIQUE KEY unique_employee_skill (employee_id, skill_id),
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    FOREIGN KEY (skill_id) REFERENCES skills(id) ON DELETE CASCADE
);

ALTER TABLE employees
    ADD COLUMN IF NOT EXISTS level INT NOT NULL DEFAULT 1,
    ADD COLUMN IF NOT EXISTS xp INT NOT NULL DEFAULT 0;

-- ----------------------------------------------------------
-- FINANCE: loans, investors, upgrades
-- ----------------------------------------------------------

CREATE TABLE IF NOT EXISTS loans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    principal INT NOT NULL,
    balance INT NOT NULL,
    interest_rate DECIMAL(5,2) NOT NULL,
    status ENUM('active','paid') NOT NULL DEFAULT 'active',
    taken_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    paid_at DATETIME NULL
);

CREATE TABLE IF NOT EXISTS investors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    investment_amount INT NOT NULL,
    equity_percent DECIMAL(5,2) NOT NULL,
    invested_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS upgrades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    description VARCHAR(255),
    category ENUM('marketing','office','tools') NOT NULL DEFAULT 'office',
    cost INT NOT NULL,
    effect_morale INT NOT NULL DEFAULT 0,
    effect_efficiency INT NOT NULL DEFAULT 0,
    effect_cash_bonus INT NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS purchased_upgrades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    upgrade_id INT NOT NULL,
    purchased_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (upgrade_id) REFERENCES upgrades(id) ON DELETE CASCADE
);

ALTER TABLE game_state
    ADD COLUMN IF NOT EXISTS equity_given DECIMAL(5,2) NOT NULL DEFAULT 0;

-- ----------------------------------------------------------
-- ACCOUNTS
-- ----------------------------------------------------------

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('owner','worker') NOT NULL DEFAULT 'worker',
    business_name VARCHAR(150) NULL,
    business_location VARCHAR(255) NULL,
    business_cash DECIMAL(12,2) NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_login_at DATETIME NULL
);

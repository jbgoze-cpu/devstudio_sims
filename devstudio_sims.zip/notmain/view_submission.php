<?php
session_start();
require_once 'db.php';
requireLogin();
$user = currentUser();
if (!$user || !in_array(($user['role'] ?? ''), ['owner', 'worker'], true)) {
    http_response_code(403);
    exit('Please sign in with a valid workspace account to view submissions.');
}
$id = (int)($_GET['id'] ?? 0);
$stmt = $conn->prepare('SELECT original_name, stored_name, project_id FROM project_submissions WHERE id=? LIMIT 1');
$stmt->bind_param('i', $id);
$stmt->execute();
$submission = $stmt->get_result()->fetch_assoc();
if (!$submission || !getProject((int)$submission['project_id'])) {
    http_response_code(404);
    exit('Submission not found for your team.');
}
$path = __DIR__ . '/uploads/submissions/' . basename($submission['stored_name']);
if (!is_file($path)) {
    http_response_code(404);
    exit('The submitted file is no longer available.');
}
$ext = strtolower(pathinfo($submission['original_name'], PATHINFO_EXTENSION));
$inlineTypes = ['pdf' => 'application/pdf', 'png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'gif' => 'image/gif', 'webp' => 'image/webp', 'txt' => 'text/plain'];
if (!isset($inlineTypes[$ext])) {
    header('Location: download_submission.php?id=' . $id);
    exit;
}
header('X-Content-Type-Options: nosniff');
header('Content-Type: ' . $inlineTypes[$ext]);
header('Content-Disposition: inline; filename="' . str_replace(['"', "\r", "\n"], '', basename($submission['original_name'])) . '"');
header('Content-Length: ' . filesize($path));
readfile($path);
exit;

-- DEVSTUDIO SIMS: account employment, private messaging, scheduling, and attendance.
-- Select devstudio_sims and import after schema_additions.sql has created users.
-- Back up the database before running migrations on an existing installation.
CREATE TABLE IF NOT EXISTS business_employment (
  id INT AUTO_INCREMENT PRIMARY KEY,
  owner_id INT NOT NULL,
  worker_id INT NOT NULL,
  business_name VARCHAR(150) NULL,
  employment_role ENUM('worker','manager') NOT NULL DEFAULT 'worker',
  status ENUM('pending','hired','declined','fired') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_employment_owner_status (owner_id,status),
  INDEX idx_employment_worker_status (worker_id,status),
  INDEX idx_employment_owner_worker (owner_id,worker_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS business_messages (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  employment_id INT NOT NULL,
  sender_id INT NOT NULL,
  message TEXT NOT NULL,
  sent_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_business_messages_employment (employment_id,sent_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Direct messages are available before a worker is hired into a business.
CREATE TABLE IF NOT EXISTS direct_messages (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  sender_id INT NOT NULL,
  recipient_id INT NOT NULL,
  message TEXT NOT NULL,
  sent_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_direct_pair (sender_id, recipient_id, sent_at),
  INDEX idx_direct_recipient (recipient_id, sent_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS business_work_schedules (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  employment_id INT NOT NULL,
  work_date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  notes VARCHAR(500) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_schedule_shift (employment_id,work_date,start_time),
  INDEX idx_schedule_date (work_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS business_attendance (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  schedule_id BIGINT UNSIGNED NOT NULL,
  status ENUM('present','late','absent','excused') NOT NULL DEFAULT 'present',
  marked_by INT NOT NULL,
  marked_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_attendance_schedule (schedule_id),
  INDEX idx_attendance_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS business_activity_logs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  owner_id INT NOT NULL,
  actor_id INT NOT NULL,
  action VARCHAR(180) NOT NULL,
  details TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_business_activity_owner_date (owner_id,created_at),
  INDEX idx_business_activity_actor (actor_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS business_notifications (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  title VARCHAR(180) NOT NULL,
  body TEXT NOT NULL,
  link_url VARCHAR(500) NOT NULL DEFAULT 'demo.php',
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_business_notifications_user_date (user_id,created_at),
  INDEX idx_business_notifications_unread (user_id,is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

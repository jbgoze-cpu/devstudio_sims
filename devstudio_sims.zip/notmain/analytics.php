<?php
session_start();
require_once 'db.php';
require_once 'business_helpers.php';
require_once 'simulation_helpers.php';
requireLogin();
// Compatibility fallback for installations where business_helpers.php is an older version.
if (!function_exists('requireWorkerBusinessMembership')) {
    function requireWorkerBusinessMembership(mysqli $conn, ?array $me): void {
        if (!$me || (($me['role'] ?? '') !== 'worker')) {
            return;
        }
        // Workers must have an active/hired business membership before viewing this page.
        $tableCheck = $conn->query("SHOW TABLES LIKE 'business_employment'");
        $hasEmploymentTable = ($tableCheck instanceof mysqli_result) && ($tableCheck->num_rows > 0);
        if ($tableCheck instanceof mysqli_result) {
            $tableCheck->free();
        }
        if (!$hasEmploymentTable) {
            header('Location: find_business.php?notice=join_required');
            exit;
        }
        $uid = (int)($me['id'] ?? 0);
        $stmt = $conn->prepare("SELECT id FROM business_employment WHERE worker_id=? AND status='hired' LIMIT 1");
        if (!$stmt) {
            error_log('Analytics membership check failed: ' . $conn->error);
            http_response_code(500);
            exit('Unable to verify business membership. Please try again later.');
        }
        $stmt->bind_param('i', $uid);
        $stmt->execute();
        $membership = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$membership) {
            header('Location: find_business.php?notice=join_required');
            exit;
        }
    }
}
requireWorkerBusinessMembership($conn, currentUser());

$me=currentUser(); $uid=(int)($me['id']??0); $businessRole=businessRoleForUser($conn,$me); $canSeeFinance=in_array($businessRole,['owner','manager'],true);
$ownerId=(int)(function_exists('currentBusinessOwnerId')?(currentBusinessOwnerId()??0):0);
$state=$ownerId>0?simState($ownerId):null;
$cash=($ownerId>0 && $canSeeFinance)?simCash($ownerId):0;
$projects=[]; if($ownerId>0 && function_exists('getProjects')) { $projects=getProjects(); if(!is_array($projects))$projects=[]; }
$employees=($ownerId>0 && function_exists('getEmployees'))?getEmployees():[]; if(!is_array($employees))$employees=[]; $employeeCount=count($employees);
$total=count($projects); $completed=0; $active=0; $atRisk=0; $progressTotal=0;
// Check the optional submissions table safely. mysqli::query() returns false on
// SQL errors, so only access num_rows when we have a valid result object.
$submissionsTableCheck = $conn->query("SHOW TABLES LIKE 'project_submissions'");
$hasSubmissionsTable = ($submissionsTableCheck instanceof mysqli_result)
    && ($submissionsTableCheck->num_rows > 0);
if ($submissionsTableCheck instanceof mysqli_result) {
    $submissionsTableCheck->free();
} elseif ($submissionsTableCheck === false) {
    error_log('Business Analytics: unable to check project_submissions table: ' . $conn->error);
}
// Recalculate from submitted deliverables just like Project Management, so the
// analytics dashboard does not display stale progress/status values.
foreach($projects as &$p){
 $pid=(int)($p['id']??0);
 $currentStatus=strtolower(trim((string)($p['status']??'')));
 // Preserve missed-deadline state and independently enforce it for the portfolio.
 $deadlineTs=0;
 if(!empty($p['deadline_at'])) $deadlineTs=strtotime((string)$p['deadline_at']) ?: 0;
 elseif(!empty($p['deadline_started_at']) && isset($p['deadline'])) $deadlineTs=(strtotime((string)$p['deadline_started_at']) ?: 0)+((int)$p['deadline']*86400);
 if($deadlineTs>0 && $deadlineTs<time() && !in_array($currentStatus,['completed','complete','missed deadline','failed'],true)) {
  $hasOnTimeSubmission=false;
  if($hasSubmissionsTable){
   $dueText=date('Y-m-d H:i:s',$deadlineTs);
   $ontime=$conn->prepare('SELECT 1 FROM project_submissions WHERE project_id=? AND submitted_at<=? LIMIT 1');
   if($ontime){$ontime->bind_param('is',$pid,$dueText);$ontime->execute();$hasOnTimeSubmission=(bool)$ontime->get_result()->fetch_row();$ontime->close();}
  }
  if(!$hasOnTimeSubmission){
   $p['status']='Missed Deadline'; $p['progress']=100;
   if(isset($p['business_owner_id'])){$fail=$conn->prepare("UPDATE projects SET status='Missed Deadline', progress=100 WHERE id=? AND business_owner_id=?");if($fail){$fail->bind_param('ii',$pid,$p['business_owner_id']);$fail->execute();$fail->close();}}
   $currentStatus='missed deadline';
  }
 }
 if(in_array($currentStatus,['missed deadline','failed'],true)){ $p['status']='Missed Deadline'; $p['progress']=100; }
 $deliverables=array_values(array_filter(array_map('trim',preg_split('/[,\n\r]+/',(string)($p['required_deliverables']??'')))));
 if(in_array(strtolower(trim((string)($p['status']??''))),['completed','complete','missed deadline','failed'],true)){$p['progress']=100;}
 elseif($deliverables && $pid>0 && $hasSubmissionsTable){
  $sub=$conn->prepare('SELECT original_name FROM project_submissions WHERE project_id=?');$sub->bind_param('i',$pid);$sub->execute();$names=[];
  foreach($sub->get_result()->fetch_all(MYSQLI_ASSOC) as $row){$names[]=strtolower(trim(preg_replace('/[^a-z0-9]+/i',' ',pathinfo($row['original_name'],PATHINFO_FILENAME))));}$sub->close();
  $done=0;foreach($deliverables as $deliverable){$needle=strtolower(trim(preg_replace('/[^a-z0-9]+/i',' ',$deliverable)));if($needle==='')continue;foreach($names as $name){if($name!==''&&(strpos($name,$needle)!==false||strpos($needle,$name)!==false)){$done++;break;}}}
  $p['progress']=(int)round(($done/count($deliverables))*100);
  $p['status']=$p['progress']>=100?'Completed':'In Progress';
  if(isset($p['business_owner_id'])){$up=$conn->prepare('UPDATE projects SET progress=?, status=? WHERE id=? AND business_owner_id=?');$up->bind_param('isii',$p['progress'],$p['status'],$pid,$p['business_owner_id']);$up->execute();$up->close();}
 }
 $status=strtolower(trim((string)($p['status']??'')));if(in_array($status,['completed','complete'],true))$completed++;elseif(!in_array($status,['missed deadline','failed'],true))$active++;
 $progress=max(0,min(100,(int)($p['progress']??0)));$progressTotal+=$progress;$risk=strtolower((string)($p['risk']??''));if(in_array($risk,['high','critical','danger'],true))$atRisk++;
}
unset($p);
// Paginate the Project Portfolio so large studios do not create a very long page.
$portfolioPerPage = 6;
$portfolioTotalPages = max(1, (int)ceil(count($projects) / $portfolioPerPage));
$portfolioPage = isset($_GET['portfolio_page']) ? max(1, (int)$_GET['portfolio_page']) : 1;
$portfolioPage = min($portfolioPage, $portfolioTotalPages);
$portfolioOffset = ($portfolioPage - 1) * $portfolioPerPage;
$portfolioProjects = array_slice($projects, $portfolioOffset, $portfolioPerPage);
$income=0.0;$expenses=0.0;$decisionGains=0.0;$decisionCosts=0.0;$decisionCount=0;$lastEvents=[];$achievements=[];
if($ownerId>0){
 $stmt=$conn->prepare("SELECT COALESCE(SUM(CASE WHEN event_type='income' THEN GREATEST(cash_delta,0) ELSE 0 END),0) income_total, COALESCE(SUM(CASE WHEN event_type='expense' THEN ABS(LEAST(cash_delta,0)) ELSE 0 END),0) expense_total, COALESCE(SUM(CASE WHEN event_type='decision' AND cash_delta>0 THEN cash_delta ELSE 0 END),0) decision_gains, COALESCE(SUM(CASE WHEN event_type='decision' AND cash_delta<0 THEN -cash_delta ELSE 0 END),0) decision_costs, SUM(CASE WHEN event_type='decision' THEN 1 ELSE 0 END) decisions FROM simulation_business_events WHERE owner_id=? AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
 $stmt->bind_param('i',$ownerId);$stmt->execute();$flow=$stmt->get_result()->fetch_assoc();$stmt->close();
 if($flow){$income=(float)$flow['income_total'];$expenses=(float)$flow['expense_total'];$decisionGains=(float)$flow['decision_gains'];$decisionCosts=(float)$flow['decision_costs'];$decisionCount=(int)$flow['decisions'];}
 $stmt=$conn->prepare("SELECT * FROM simulation_business_events WHERE owner_id=? ORDER BY id DESC LIMIT 8");$stmt->bind_param('i',$ownerId);$stmt->execute();$lastEvents=$stmt->get_result()->fetch_all(MYSQLI_ASSOC);$stmt->close();
 if(!$canSeeFinance)$lastEvents=array_values(array_filter($lastEvents,fn($e)=>in_array($e['event_type'],['decision','achievement'],true)));
 $stmt=$conn->prepare("SELECT * FROM simulation_business_achievements WHERE owner_id=? ORDER BY unlocked_at DESC");$stmt->bind_param('i',$ownerId);$stmt->execute();$achievements=$stmt->get_result()->fetch_all(MYSQLI_ASSOC);$stmt->close();
}
$net=$income+$decisionGains-$expenses-$decisionCosts; $forecast=$cash+$net;
$maxFlow=max(1,$income,$expenses,$decisionGains,$decisionCosts);
// Exportable, business-scoped report. CSV export uses the same calculated metrics shown below.
if (isset($_GET['export']) && $_GET['export']==='csv') {
    if (!$canSeeFinance) { http_response_code(403); exit('Financial reports are available to the owner or manager only.'); }
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="devstudio-business-report-'.date('Y-m-d').'.csv"');
    $out=fopen('php://output','w');
    fputcsv($out,['DEVSTUDIO SIMS Business Analytics Report']);
    fputcsv($out,['Generated',date('Y-m-d H:i:s')]);
    fputcsv($out,['Reporting period','Last 30 days']);
    fputcsv($out,['Metric','Value']);
    fputcsv($out,['Current Budget',number_format($cash,2,'.','')]);
    fputcsv($out,['Recorded Revenue',number_format($income,2,'.','')]);
    fputcsv($out,['Recorded Expenses',number_format($expenses,2,'.','')]);
    fputcsv($out,['Scenario Gains',number_format($decisionGains,2,'.','')]);
    fputcsv($out,['Scenario Costs',number_format($decisionCosts,2,'.','')]);
    fputcsv($out,['Net Cash Movement (30 days)',number_format($net,2,'.','')]);
    fputcsv($out,['Total Projects',$total]); fputcsv($out,['Active Projects',$active]);
    fputcsv($out,['Completed Projects',$completed]); fputcsv($out,['At-risk Projects',$atRisk]);
    fputcsv($out,[]); fputcsv($out,['Project','Status','Progress','Risk','Budget']);
    foreach($projects as $rp){ fputcsv($out,[(string)($rp['title']??$rp['project_name']??$rp['name']??'Untitled project'),(string)($rp['status']??'Not started'),(int)($rp['progress']??0),(string)($rp['risk']??'Unrated'),number_format((float)($rp['budget']??0),2,'.','')]); }
    fclose($out); exit;
}
$completionRate=$total>0?(int)round(($completed/$total)*100):0;
$pendingReview=0; $overdueProjects=0;
foreach($projects as $pr){$st=strtolower(trim((string)($pr['status']??''))); if(in_array($st,['pending review','submitted','under review'],true))$pendingReview++; if(in_array($st,['missed deadline','failed'],true))$overdueProjects++;}
$insights=[];
if($canSeeFinance && $net<0)$insights[]=['warning','Cash flow was negative over the last 30 days. Review recorded expenses and scenario costs.'];
if($canSeeFinance && $cash<=0)$insights[]=['warning','Budget is at or below zero. Review planned spending before taking on additional costs.'];
if($atRisk>0)$insights[]=['warning',$atRisk.' project(s) are marked high or critical risk. Review blockers and deadlines.'];
if($overdueProjects>0)$insights[]=['warning',$overdueProjects.' project(s) are marked missed deadline or failed. Review recovery actions.'];
if($pendingReview>0)$insights[]=['info',$pendingReview.' project(s) appear to be awaiting review. Open Project Management to review submissions.'];
if(!$insights)$insights[]=['good','No immediate alerts were identified from the available finance and project status data. Keep project statuses and transactions up to date.'];
$chartMax=max(1,$income,$expenses,$decisionGains,$decisionCosts);

function anEscape($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function anStatusClass($s){$s=strtolower((string)$s);if(str_contains($s,'missed deadline')||str_contains($s,'failed'))return 'text-rose-100 bg-rose-600/25 border border-rose-400/60';if(str_contains($s,'complete'))return 'text-emerald-300 bg-emerald-500/10';if(str_contains($s,'progress')||str_contains($s,'ongoing'))return 'text-cyan-300 bg-cyan-500/10';return 'text-slate-300 bg-slate-700';}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Business Analytics | DEVSTUDIO SIMS</title><script src="https://cdn.tailwindcss.com"></script><script src="https://unpkg.com/lucide@latest"></script><link rel="stylesheet" href="assets/theme.css"><style>.an-card{background:rgba(15,23,42,.82);border:1px solid rgba(148,163,184,.18);border-radius:12px;padding:10px}.an-muted{color:#94a3b8}.an-bar{height:8px;background:#334155;border-radius:999px;overflow:hidden}.an-bar span{display:block;height:100%;border-radius:999px}.an-section-title{font-size:1.05rem;font-weight:750}.an-chart-row{display:grid;grid-template-columns:110px minmax(0,1fr) 100px;gap:6px;align-items:center;margin-top:6px;font-size:12px}.an-chart-track{height:9px;background:#334155;border-radius:999px;overflow:hidden}.an-chart-track span{height:100%;display:block;border-radius:999px}.an-insight{border-radius:9px;padding:7px 9px;font-size:12px;line-height:1.35}.an-insight.warning{background:rgba(251,113,133,.09);border:1px solid rgba(251,113,133,.25)}.an-insight.info{background:rgba(45,212,191,.08);border:1px solid rgba(45,212,191,.2)}.an-insight.good{background:rgba(52,211,153,.08);border:1px solid rgba(52,211,153,.2)}.an-portfolio-list{grid-auto-rows:minmax(112px,auto)}.an-project-item{min-height:112px;box-sizing:border-box}.an-project-placeholder{visibility:hidden;pointer-events:none}@media(min-width:1280px){.an-card{padding:10px}.an-section-title{font-size:1rem}}@media(max-width:700px){.an-chart-row{grid-template-columns:85px minmax(0,1fr) 82px}.analytics-grid{grid-template-columns:minmax(0,1fr)!important}}</style></head><body class="bg-slate-900 text-white"><div class="ds-shell ds-unified-shell"><?php include 'partial_nav.php'; ?><main class="ds-main ds-unified-main min-w-0"><div class="max-w-[1600px] mx-auto p-3 md:p-4">
<header class="flex flex-wrap justify-between items-center gap-3 mb-4"><div><p class="ds-eyebrow">PERFORMANCE ANALYTICS</p><h1 class="text-2xl md:text-3xl font-bold">Business Analytics</h1><p class="an-muted text-sm mt-1">A simple overview of your budget, team, projects, and important alerts.</p></div><div class="flex flex-wrap gap-2"><?php if($canSeeFinance): ?><a href="?export=csv" class="rounded-lg border border-slate-600 px-3 py-2 text-sm hover:bg-slate-800">Export CSV ↓</a><?php endif; ?><a href="decision_model.php" class="rounded-lg bg-teal-400 text-slate-950 font-bold px-3 py-2 text-sm">Decision Modeling →</a></div></header>
<?php if($ownerId<1): ?><section class="an-card"><h2 class="text-xl font-bold">No active studio</h2><p class="an-muted mt-2">This account is not linked to a studio. Sign in with a Team Leader account or join a business to view its simulation data.</p></section><?php else: ?>
<div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-2 gap-2 mb-2">
 <?php if($canSeeFinance): ?><div class="an-card"><p class="an-muted text-sm">Budget</p><p class="text-2xl font-bold mt-2">₱<?= number_format($cash,2) ?></p><p class="text-xs an-muted mt-1">Live balance after applied scenario decisions and recorded finance events.</p></div><?php endif; ?>
 <div class="an-card"><p class="an-muted text-sm">Employees</p><p class="text-2xl font-bold mt-2"><?= $employeeCount ?></p><p class="text-xs an-muted mt-1">Active simulated staff</p></div>
</div>
<?php if($canSeeFinance): ?><section class="an-card mb-3"><div class="flex flex-wrap justify-between items-center gap-2"><div><h2 class="an-section-title">Financial Performance · Last 30 Days</h2><p class="an-muted text-xs mt-1">Recorded transactions and scenario effects are shown separately; estimates are not counted as revenue.</p></div><span class="text-xs an-muted">Amounts in PHP</span></div>
<div class="grid md:grid-cols-2 gap-x-8 gap-y-1 mt-2">
<?php foreach([['Recorded income',$income,'#34d399'],['Recorded expenses',$expenses,'#fb7185'],['Scenario gains',$decisionGains,'#2dd4bf'],['Scenario costs',$decisionCosts,'#f97316']] as $bar): ?><div class="an-chart-row"><span><?= anEscape($bar[0]) ?></span><div class="an-chart-track"><span style="width:<?= min(100,((float)$bar[1]/$chartMax)*100) ?>%;background:<?= $bar[2] ?>"></span></div><strong class="text-right">₱<?= number_format((float)$bar[1],0) ?></strong></div><?php endforeach; ?>
</div></section><?php endif; ?>
<section class="grid analytics-grid xl:grid-cols-2 gap-2 mb-2">
<div class="an-card"><div class="flex items-center justify-between gap-2"><h2 class="an-section-title">Smart Business Insights</h2><span class="text-xs an-muted">Based on current records</span></div><div class="grid sm:grid-cols-2 gap-2 mt-3"><?php foreach($insights as $ins): ?><div class="an-insight <?= anEscape($ins[0]) ?>"><strong class="block mb-1"><?= $ins[0]==='warning'?'Needs attention':($ins[0]==='good'?'Status':'Suggested action') ?></strong><?= anEscape($ins[1]) ?></div><?php endforeach; ?></div></div>
<div class="an-card"><div class="flex items-center justify-between gap-2"><h2 class="an-section-title">Project Performance</h2><a href="project_management.php" class="text-teal-300 text-xs">Manage →</a></div><div class="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-3"><div class="rounded-lg bg-slate-800 p-2"><p class="an-muted text-xs">Completion</p><p class="text-xl font-bold"><?= $completionRate ?>%</p></div><div class="rounded-lg bg-slate-800 p-2"><p class="an-muted text-xs">Pending review</p><p class="text-xl font-bold"><?= $pendingReview ?></p></div><div class="rounded-lg bg-slate-800 p-2"><p class="an-muted text-xs">Overdue/failed</p><p class="text-xl font-bold <?= $overdueProjects?'text-rose-300':'' ?>"><?= $overdueProjects ?></p></div><div class="rounded-lg bg-slate-800 p-2"><p class="an-muted text-xs">High risk</p><p class="text-xl font-bold <?= $atRisk?'text-amber-300':'' ?>"><?= $atRisk ?></p></div></div><div class="an-bar mt-2"><span style="width:<?= $completionRate ?>%;background:#34d399"></span></div><p class="an-muted text-xs mt-2"><?= $completed ?> completed out of <?= $total ?> projects. Completion rate uses the current project status records.</p></div>
</section>
<div class="grid analytics-grid grid-cols-1 gap-2 mb-2">
 <section id="project-portfolio" class="an-card min-w-0"><div class="flex items-start justify-between gap-3"><div><h2 class="text-xl font-bold">Project Portfolio</h2><p class="an-muted text-sm mt-1">Status and delivery progress for this studio.</p></div><a href="project_management.php" class="text-teal-300 text-sm">Manage projects →</a></div>
 <div class="grid grid-cols-1 sm:grid-cols-3 gap-2 mt-2 mb-2"><div class="rounded-lg bg-slate-800 p-3"><p class="an-muted text-xs">Total</p><p class="text-2xl font-bold"><?= $total ?></p></div><div class="rounded-lg bg-slate-800 p-3"><p class="an-muted text-xs">Active</p><p class="text-2xl font-bold"><?= $active ?></p></div><div class="rounded-lg bg-slate-800 p-3"><p class="an-muted text-xs">Completed</p><p class="text-2xl font-bold"><?= $completed ?></p></div></div>
 <?php if(!$projects): ?><p class="an-muted text-sm py-3">No projects yet. Create a project to begin tracking delivery and risk.</p><?php else: ?><div class="an-portfolio-list grid grid-cols-1 lg:grid-cols-2 gap-x-4 gap-y-2"><?php foreach($portfolioProjects as $p): $pct=max(0,min(100,(int)($p['progress']??0))); $title=$p['title']??$p['project_name']??$p['name']??'Untitled project'; ?><div class="an-project-item border-b border-slate-700/70 pb-2"><div class="flex flex-wrap items-center justify-between gap-2"><p class="font-semibold break-words min-w-0"><?= anEscape($title) ?></p><span class="shrink-0 text-xs px-2 py-1 rounded-full <?= anStatusClass($p['status']??'') ?>"><?= in_array(strtolower(trim((string)($p['status']??''))),['missed deadline','failed'],true) ? 'Failed' : anEscape($p['status']??'Not started') ?></span></div><div class="flex justify-between text-xs an-muted mt-2 mb-1"><span>Progress</span><span><?= $pct ?>%</span></div><div class="an-bar"><span style="width:<?= $pct ?>%;background:<?= in_array(strtolower(trim((string)($p['status']??''))),['missed deadline','failed'],true)?'#f43f5e':'#2dd4bf' ?>"></span></div><div class="flex flex-wrap justify-between gap-2 text-xs an-muted mt-2"><span>Risk: <?= anEscape($p['risk']??'Unrated') ?></span><span>Budget: ₱<?= number_format((float)($p['budget']??0),0) ?></span></div></div><?php endforeach; ?><?php for($slot=count($portfolioProjects);$slot<$portfolioPerPage;$slot++): ?><div class="an-project-item an-project-placeholder" aria-hidden="true"></div><?php endfor; ?></div>
 <nav class="mt-2 pt-2 border-t border-slate-700 flex flex-wrap items-center justify-between gap-3" aria-label="Project portfolio pages"><p class="text-xs an-muted">Showing <?= $portfolioOffset+1 ?>–<?= min($portfolioOffset+count($portfolioProjects),$total) ?> of <?= $total ?> projects · Page <?= $portfolioPage ?> of <?= $portfolioTotalPages ?></p><div class="flex items-center gap-2"><?php if($portfolioPage>1): ?><a href="?portfolio_page=<?= $portfolioPage-1 ?>#project-portfolio" class="rounded-lg border border-slate-600 px-3 py-2 text-sm hover:bg-slate-700">← Previous</a><?php else: ?><span class="rounded-lg border border-slate-700 px-3 py-2 text-sm text-slate-600" aria-disabled="true">← Previous</span><?php endif; ?><?php if($portfolioPage<$portfolioTotalPages): ?><a href="?portfolio_page=<?= $portfolioPage+1 ?>#project-portfolio" class="rounded-lg bg-teal-400 px-3 py-2 text-sm font-bold text-slate-950 hover:bg-teal-300">Next →</a><?php else: ?><span class="rounded-lg border border-slate-700 px-3 py-2 text-sm text-slate-600" aria-disabled="true">Next →</span><?php endif; ?></div></nav><?php endif; ?>
 <div class="mt-2 rounded-lg bg-slate-800/80 p-3 text-sm an-muted"><?= $atRisk ?> project(s) currently marked with high or critical risk.</div>
 </section>
</div>
<div class="an-card flex flex-wrap items-center justify-between gap-4">
 <div><h2 class="text-xl font-bold">Recent Decision and Finance History</h2><p class="an-muted text-sm mt-1">Open the latest recorded simulation decisions and finance events in a pop-up.</p></div>
 <button type="button" id="openHistoryModal" class="rounded-lg bg-teal-400 hover:bg-teal-300 text-slate-950 font-bold px-4 py-3">View History →</button>
</div>
<div id="historyModal" class="fixed inset-0 z-50 hidden items-center justify-center bg-slate-950/80 p-4" role="dialog" aria-modal="true" aria-labelledby="historyModalTitle">
 <div class="w-full max-w-5xl max-h-[85vh] overflow-hidden rounded-2xl border border-slate-700 bg-slate-900 shadow-2xl">
  <div class="flex items-start justify-between gap-4 border-b border-slate-700 p-5"><div><h2 id="historyModalTitle" class="text-xl font-bold">Recent Decision and Finance History</h2><p class="an-muted text-sm mt-1">A traceable record of the latest simulation actions.</p></div><button type="button" id="closeHistoryModal" aria-label="Close history" class="rounded-lg bg-slate-800 px-3 py-2 text-slate-200 hover:bg-slate-700">✕</button></div>
  <div class="max-h-[65vh] overflow-auto p-5">
  <?php if(!$lastEvents): ?><p class="an-muted text-sm py-4">No decisions or financial entries have been recorded yet.</p><?php else: ?><div class="overflow-x-auto"><table class="w-full text-sm text-left"><thead class="sticky top-0 bg-slate-900"><tr class="text-slate-400 border-b border-slate-700"><th class="py-3 pr-3">Event</th><th class="py-3 pr-3">Details</th><?php if($canSeeFinance): ?><th class="py-3 pr-3 text-right">Cash impact</th><?php endif; ?><th class="py-3 text-right">Date</th></tr></thead><tbody><?php foreach($lastEvents as $e): ?><tr class="border-b border-slate-800 align-top"><td class="py-3 pr-3 font-medium"><?= anEscape($e['title']) ?><span class="block text-xs an-muted mt-1"><?= anEscape(ucfirst($e['event_type'])) ?></span></td><td class="py-3 pr-3 an-muted max-w-md"><?= anEscape($e['details']) ?></td><?php if($canSeeFinance): ?><td class="py-3 pr-3 text-right whitespace-nowrap <?= (float)$e['cash_delta']>=0?'text-emerald-300':'text-rose-300' ?>"><?= (float)$e['cash_delta']>=0?'+':'−' ?>₱<?= number_format(abs((float)$e['cash_delta']),2) ?></td><?php endif; ?><td class="py-3 text-right whitespace-nowrap an-muted"><?= anEscape(date('M j, Y',strtotime($e['created_at']))) ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
  </div>
 </div>
</div>
<script>
(function(){
 const modal=document.getElementById('historyModal'), open=document.getElementById('openHistoryModal'), close=document.getElementById('closeHistoryModal');
 if(!modal||!open||!close)return;
 function show(){modal.classList.remove('hidden');modal.classList.add('flex');document.body.style.overflow='hidden';close.focus();}
 function hide(){modal.classList.add('hidden');modal.classList.remove('flex');document.body.style.overflow='';open.focus();}
 open.addEventListener('click',show);close.addEventListener('click',hide);
 modal.addEventListener('click',function(e){if(e.target===modal)hide();});
 document.addEventListener('keydown',function(e){if(e.key==='Escape'&&!modal.classList.contains('hidden'))hide();});
})();
</script>
<?php endif; ?></div></main></div><script>if(window.lucide)lucide.createIcons();</script></body></html>

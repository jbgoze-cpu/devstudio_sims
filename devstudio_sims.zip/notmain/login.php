<?php
session_start();
require_once "db.php";

requireTables(['users']);
verifyAppCsrfPost();

if (!empty($_SESSION['user_id'])) {
    header("Location: demo.php");
    exit;
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $result = attemptLogin(
        $_POST['identifier'] ?? '',
        $_POST['password'] ?? ''
    );

    if ($result['ok']) {

        session_regenerate_id(true);

        $_SESSION['user_id'] = $result['user']['id'];
        $_SESSION['username'] = $result['user']['username'];

        $redirect = $_SESSION['redirect_after_login'] ?? 'demo.php';
        unset($_SESSION['redirect_after_login']);

        // Allow only local PHP page redirects.
        if (!is_string($redirect) || $redirect === '' || str_contains($redirect, '://') || str_starts_with($redirect, '//')) {
            $redirect = 'demo.php';
        }
        header("Location: " . $redirect);
        exit;

    } else {

        $error = $result['error'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Log In | DEVSTUDIO SIMS</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="assets/theme.css">
</head>
<body class="bg-slate-900 text-white">

<div class="max-w-md mx-auto py-24 px-6">

<div class="text-center mb-8">
<div class="ds-eyebrow">DEVSTUDIO SIMS</div>
<h1 class="text-3xl font-bold">Log In</h1>
<p class="text-slate-400 mt-2">Sign in to keep managing the studio.</p>
</div>

<div class="ds-panel accent-process">

<?php if($error): ?>
<div class="ds-panel accent-alert mb-5"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="post" class="space-y-4"><?= appCsrfField() ?>

<div>
<label class="block mb-2 text-sm text-slate-400">Username or Email</label>
<input type="text" name="identifier" required autofocus
class="w-full bg-slate-700 rounded-lg p-3">
</div>

<div>
<label class="block mb-2 text-sm text-slate-400">Password</label>
<input type="password" name="password" required
class="w-full bg-slate-700 rounded-lg p-3">
</div>

<button class="ds-btn process w-full justify-center">Log In</button>

</form>

</div>

<p class="text-center text-slate-400 text-sm mt-6">
No account yet? <a href="register.php" class="text-cyan-400 hover:underline">Create one</a>
</p>

<p class="text-center text-slate-500 text-xs mt-2">
<a href="index.php" class="hover:text-slate-300">Back to overview</a>
</p>

</div>

</body>
</html>

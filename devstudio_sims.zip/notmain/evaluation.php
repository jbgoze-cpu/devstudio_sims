<?php
session_start();
require_once 'db.php';
require_once 'business_helpers.php';
require_once 'worker_score_helpers.php';
requireLogin();
$user = currentUser();
$role = businessRoleForUser($conn, $user);
$ownerId = (int)(function_exists('businessOwnerForUser') ? (businessOwnerForUser($conn, $user) ?? 0) : 0);
if (!in_array($role, ['owner','manager'], true) || $ownerId < 1) {
    http_response_code(403);
    exit('Worker participation is available to the business owner or manager.');
}
syncWorkerProjectScoreEvents($conn, $ownerId);
$workers = [];
$stmt = $conn->prepare("SELECT be.worker_id, be.employment_role, u.username
    FROM business_employment be JOIN users u ON u.id=be.worker_id
    WHERE be.owner_id=? AND be.status='hired' ORDER BY u.username");
if ($stmt) {
    $stmt->bind_param('i', $ownerId); $stmt->execute();
    $workers = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
}
$hasSubmissions = false;
$check = $conn->query("SHOW TABLES LIKE 'project_submissions'");
if ($check && $check->num_rows > 0) $hasSubmissions = true;
$submittedIds = [];
if ($hasSubmissions && $workers) {
    $ids = array_map(fn($w) => (int)$w['worker_id'], $workers);
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $types = str_repeat('i', count($ids));
    $sql = "SELECT DISTINCT user_id FROM project_submissions WHERE user_id IN ($placeholders)";
    $q = $conn->prepare($sql);
    if ($q) {
        $q->bind_param($types, ...$ids); $q->execute();
        foreach ($q->get_result()->fetch_all(MYSQLI_ASSOC) as $r) $submittedIds[(int)$r['user_id']] = true;
        $q->close();
    }
}
$workerSubmissionCounts = [];
$workerMissedCounts = [];
$scoreEventsByWorker = [];
$scoreTimeline = [];
foreach ($workers as $worker) {
    $wid = (int)$worker['worker_id'];
    $workerSubmissionCounts[$wid] = 0;
    $workerMissedCounts[$wid] = 0;
    $scoreEventsByWorker[$wid] = [];
}
if ($workers) {
    $ids = array_map(fn($w) => (int)$w['worker_id'], $workers);
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $types = str_repeat('i', count($ids));
    $q = $conn->prepare("SELECT user_id, event_type, points_change, event_at FROM worker_project_score_events WHERE owner_id=? AND user_id IN ($placeholders) ORDER BY event_at, id");
    if ($q) {
        $bindTypes = 'i'.$types; $bindValues = array_merge([$ownerId], $ids); $q->bind_param($bindTypes, ...$bindValues); $q->execute();
        foreach ($q->get_result()->fetch_all(MYSQLI_ASSOC) as $event) {
            $wid = (int)$event['user_id'];
            if (!isset($scoreEventsByWorker[$wid])) continue;
            $scoreEventsByWorker[$wid][] = $event;
            if ($event['event_type'] === 'missed_deadline') $workerMissedCounts[$wid]++;
            if ($event['event_type'] === 'on_time_completion') $workerSubmissionCounts[$wid]++;
            $scoreTimeline[(string)$event['event_at']] = true;
        }
        $q->close();
    }
}
$timelineLabels = array_keys($scoreTimeline);
$lineSeries = [];
foreach ($workers as $worker) {
    $wid = (int)$worker['worker_id'];
    $events = $scoreEventsByWorker[$wid] ?? [];
    $eventIndex = 0; $running = 0; $values = [];
    foreach ($timelineLabels as $timestamp) {
        while ($eventIndex < count($events) && (string)$events[$eventIndex]['event_at'] <= $timestamp) {
            $running += (int)$events[$eventIndex]['points_change'];
            $eventIndex++;
        }
        $values[] = $running;
    }
    $lineSeries[] = ['label'=>(string)$worker['username'], 'data'=>$values];
}
$total = count($workers);
$submitted = count(array_filter($workers, fn($w) => isset($submittedIds[(int)$w['worker_id']])));
$notSubmitted = $total - $submitted;
function evEsc($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Worker Participation | DEVSTUDIO SIMS</title><script src="https://cdn.tailwindcss.com"></script><link rel="stylesheet" href="assets/theme.css"></head>
<body class="bg-slate-900 text-white"><div class="ds-shell ds-unified-shell"><?php include 'partial_nav.php'; ?><main class="ds-main ds-unified-main"><div class="max-w-6xl mx-auto p-5 md:p-8">
<header class="mb-8"><p class="text-sm text-teal-300 font-semibold mb-2">TEAM ACTIVITY</p><h1 class="text-3xl md:text-4xl font-bold">Worker Participation</h1><p class="text-slate-400 mt-2 max-w-3xl">Track each hired worker’s project outcomes. Missed deadlines subtract points; approved on-time completions add points.</p></header>
<section class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
<article class="rounded-xl border border-slate-700 bg-slate-800 p-5"><p class="text-sm text-slate-400">Hired workers</p><p class="text-3xl font-bold mt-2"><?= $total ?></p></article>
<article class="rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-5"><p class="text-sm text-emerald-200">Submitted documents</p><p class="text-3xl font-bold mt-2"><?= $submitted ?></p></article>
<article class="rounded-xl border border-amber-500/30 bg-amber-500/10 p-5"><p class="text-sm text-amber-200">No submission recorded</p><p class="text-3xl font-bold mt-2"><?= $notSubmitted ?></p></article>
</section>
<section class="rounded-xl border border-slate-700 bg-slate-800 p-5 md:p-6 mb-8"><div class="flex flex-col md:flex-row md:items-start md:justify-between gap-4 mb-5"><div><h2 class="text-xl font-bold mb-1">Worker Progress Chart</h2><p class="text-sm text-slate-400">Switch between a bar chart comparing workers and a line chart showing cumulative submissions over time.</p></div><label class="text-sm text-slate-300">Chart type <select id="chartType" class="ml-2 rounded-lg bg-slate-900 border border-slate-600 px-3 py-2 text-white"><option value="bar">Bar graph — by worker</option><option value="line">Line graph — progress over time</option></select></label></div>
<div class="relative w-full" style="height:360px"><canvas id="workerProgressChart" aria-label="Worker document submission progress chart"></canvas></div>
<p id="chartHelp" class="text-xs text-slate-400 mt-4">Bar graph compares the number of documents submitted by each currently hired worker.</p>
<p class="text-xs text-slate-500 mt-2">A green bar is counted after the Owner/Manager approves an on-time submission. A red bar is counted once for every assigned worker when a project closes for a missed deadline.</p></section>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const workerLabels = <?= json_encode(array_map(fn($w) => (string)($w['username'] ?? 'Worker'), $workers), JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
const onTimeCounts = <?= json_encode(array_values(array_map(fn($w) => (int)($workerSubmissionCounts[(int)$w['worker_id']] ?? 0), $workers))) ?>;
const missedCounts = <?= json_encode(array_values(array_map(fn($w) => (int)($workerMissedCounts[(int)$w['worker_id']] ?? 0), $workers))) ?>;
const timelineLabels = <?= json_encode($timelineLabels, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
const lineSeries = <?= json_encode($lineSeries, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>;
const ctx = document.getElementById('workerProgressChart');
const typeSelect = document.getElementById('chartType');
const chartHelp = document.getElementById('chartHelp');
let progressChart;
function renderProgressChart(type) {
  if (progressChart) progressChart.destroy();
  let data;
  if (type === 'line') {
    chartHelp.textContent = 'Cumulative net points over time for each worker: the line drops by 1 for each missed deadline and rises by 1 for each approved on-time completion.';
    data = { labels: timelineLabels, datasets: lineSeries.map((series, i) => ({ label: series.label, data: series.data, borderWidth: 2, tension: 0.2, fill: false, pointRadius: 3 })) };
    if (!timelineLabels.length) chartHelp.textContent = 'No deadline misses or approved on-time completions have been recorded yet.';
    progressChart = new Chart(ctx, { type: 'line', data, options: chartOptions('Net points') });
  } else {
    chartHelp.textContent = 'Each worker has two bars: red shows missed deadlines; green shows approved on-time project completions.';
    data = { labels: workerLabels, datasets: [
      { label: 'Missed deadline', data: missedCounts, backgroundColor: 'rgba(248,113,113,.82)', borderColor: '#f87171', borderWidth: 1 },
      { label: 'Passed on time', data: onTimeCounts, backgroundColor: 'rgba(52,211,153,.82)', borderColor: '#34d399', borderWidth: 1 }
    ] };
    progressChart = new Chart(ctx, { type: 'bar', data, options: {...chartOptions('Project outcomes'), scales: {...chartOptions('Project outcomes').scales, x: {...chartOptions('Project outcomes').scales.x, stacked: false}, y: {...chartOptions('Project outcomes').scales.y, beginAtZero: true, ticks: { precision: 0, color: '#cbd5e1' }}}} });
  }
}
function chartOptions(yTitle) { return { responsive: true, maintainAspectRatio: false, interaction: { intersect: false, mode: 'index' }, plugins: { legend: { labels: { color: '#e2e8f0' } }, tooltip: { enabled: true } }, scales: { x: { ticks: { color: '#cbd5e1' }, grid: { color: 'rgba(148,163,184,.12)' } }, y: { beginAtZero: false, ticks: { precision: 0, color: '#cbd5e1' }, grid: { color: 'rgba(148,163,184,.12)' }, title: { display: true, text: yTitle, color: '#cbd5e1' } } } }; }
typeSelect.addEventListener('change', () => renderProgressChart(typeSelect.value));
renderProgressChart('bar');
</script>

</div></main></div></body></html>

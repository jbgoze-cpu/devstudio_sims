<?php
session_start();
require_once 'db.php';
requireLogin();
$_SESSION['flash'] = [
  'type' => 'info',
  'message' => 'Random legacy events are disabled. Use Decision Modeling to choose a scenario and review its consequences.'
];
header('Location: decision_model.php');
exit;

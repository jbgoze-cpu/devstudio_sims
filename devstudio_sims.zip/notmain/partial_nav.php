<?php
require_once __DIR__ . '/business_helpers.php';
$__current = basename($_SERVER['SCRIPT_NAME']);
$__me = currentUser();
$__businessRole = businessRoleForUser($conn, $__me);
$__isOwnerAccount = (($__me['role'] ?? '') === 'owner') || ($__businessRole === 'owner');
// Workers can find a business until an owner approves and hires them.
// Studio shortcuts stay locked for worker accounts until they join a business.
$__isWorkerAccount = (($__me['role'] ?? '') === 'worker');
$__workerHasBusiness = false;
$__showFindBusiness = $__isWorkerAccount && !empty($__me['id']);
if ($__isWorkerAccount && !empty($__me['id']) && $conn instanceof mysqli && function_exists('tableExists') && tableExists('business_employment')) {
    $__workerId = (int)$__me['id'];
    $__hiredStmt = $conn->prepare("SELECT id FROM business_employment WHERE worker_id=? AND status='hired' LIMIT 1");
    if ($__hiredStmt) {
        $__hiredStmt->bind_param('i', $__workerId);
        $__hiredStmt->execute();
        $__workerHasBusiness = (bool)$__hiredStmt->get_result()->fetch_assoc();
        $__showFindBusiness = !$__workerHasBusiness;
        $__hiredStmt->close();
    }
}
function navActive($file, $current) { return $file === $current ? 'active' : ''; }
$__navItems = [
 ['demo.php','Business Dashboard'], ['project_management.php','Project Management'], ['team.php','Team Management'],
 ['leaderboard.php','Studio Leaderboard'],
 ['settings.php','Settings']
];
// Until hired into a business, worker accounts only see Find a Business and general account links.
// These shortcuts unlock automatically after business_employment.status becomes 'hired'.
if ($__isWorkerAccount && !$__workerHasBusiness) {
    $__navItems = array_values(array_filter($__navItems, function ($item) {
        return !in_array($item[0], ['demo.php', 'project_management.php', 'team.php', 'leaderboard.php'], true);
    }));
}
// Workers can browse businesses until they are hired by one.
if ($__showFindBusiness) { array_splice($__navItems, 3, 0, [['find_business.php','Find a Business']]); }
// Chatbox is available to workers and to the owner/manager side of the business.
if ($__isWorkerAccount) {
    $__navItems[] = ['worker_messages.php','Chatbox'];
} elseif (in_array($__businessRole, ['owner','manager'], true)) {
    $__navItems[] = ['business_messages.php','Chatbox'];
}
// Project Review is also hidden from worker accounts.
if ($__businessRole !== 'worker') {
    array_splice($__navItems, 4, 0, [['evaluation.php','Project Review']]);
}
// Decision Modeling, Business Analytics, and 3D Studio View are hidden from worker accounts.
// Owners and managers retain access to these navigation links.
if ($__businessRole !== 'worker') {
    array_splice($__navItems, 3, 0, [
        ['decision_model.php','Decision Modeling'],
        ['analytics.php','Business Analytics'],
        ['studio3d.php','3D Studio View']
    ]);
}
// Skill Training is available to workers and non-owner roles, but hidden from Owner accounts.
if (!$__isOwnerAccount) { $__navItems[] = ['training.php','Skill Training']; }
$__canSeeActivity = in_array($__businessRole, ['owner','manager'], true);
?>
<nav class="ds-mobile-shortcuts" aria-label="Main navigation">
  <details class="ds-mobile-dropdown"><summary aria-label="Open navigation menu" title="Menu"><span class="ds-mobile-menu-icon">☰</span></summary>
    <div class="ds-mobile-menu-links">
      <?php foreach ($__navItems as $__item): ?><a href="<?= htmlspecialchars($__item[0], ENT_QUOTES, 'UTF-8') ?>" class="<?= navActive($__item[0], $__current) ?>"><?= htmlspecialchars($__item[1], ENT_QUOTES, 'UTF-8') ?></a><?php endforeach; ?>
      <button type="button" class="ds-popup-open" data-popup="notifications">Notifications <span class="ds-unread-count" aria-label="unread notifications"></span></button>
      <?php if ($__canSeeActivity): ?><button type="button" class="ds-popup-open" data-popup="activity">Activity Log</button><?php endif; ?>
      <a href="feedback.php" class="<?= navActive('feedback.php', $__current) ?>">Worker Feedback</a>
    </div>
  </details>
</nav>
<div class="ds-rail hidden md:flex md:flex-col md:justify-between"><div>
  <div class="ds-rail-brand">DEVSTUDIO<span>_</span>SIMS</div>
  <?php foreach ($__navItems as $__item): ?><a href="<?= htmlspecialchars($__item[0], ENT_QUOTES, 'UTF-8') ?>" class="<?= navActive($__item[0], $__current) ?>"><?= htmlspecialchars($__item[1], ENT_QUOTES, 'UTF-8') ?></a><?php endforeach; ?>
  <div class="ds-rail-section">UPDATES</div>
  <button type="button" class="ds-popup-open ds-rail-popup" data-popup="notifications"><span>Notifications</span><span class="ds-unread-count" aria-label="unread notifications"></span></button>
  <?php if ($__canSeeActivity): ?><button type="button" class="ds-popup-open ds-rail-popup" data-popup="activity">Activity Log</button><?php endif; ?>
  <a href="feedback.php" class="<?= navActive('feedback.php', $__current) ?>">Worker Feedback</a>
  <div class="ds-rail-section">ACCOUNT</div>
  <?php if ($__me): ?><div class="px-4 py-2 text-xs text-slate-400"><?= htmlspecialchars($__me['username'] ?? 'User', ENT_QUOTES, 'UTF-8') ?></div><a href="logout.php">Log Out</a><?php endif; ?>
</div></div>
<div id="ds-nav-popup" class="ds-popup-overlay" hidden role="dialog" aria-modal="true" aria-labelledby="ds-popup-title">
  <section class="ds-popup-card"><header class="ds-popup-header"><div><p class="ds-eyebrow" id="ds-popup-eyebrow">UPDATES</p><h2 id="ds-popup-title">Notifications</h2></div><button type="button" id="ds-popup-close" class="ds-popup-close" aria-label="Close popup">×</button></header>
    <div id="ds-popup-content" class="ds-popup-content"><p class="text-slate-400">Loading…</p></div>
  </section>
</div>
<style>
.ds-popup-open{cursor:pointer;text-align:left}.ds-rail-popup{display:flex;align-items:center;justify-content:space-between;width:100%;padding:10px 16px;color:#cbd5e1;background:transparent;border:0;font:inherit;font-size:13px}.ds-rail-popup:hover,.ds-popup-open:hover{color:#5eead4;background:rgba(45,212,191,.08)}.ds-unread-count:not(:empty){display:inline-flex;align-items:center;justify-content:center;min-width:19px;height:19px;padding:0 5px;border-radius:999px;background:#f97316;color:#fff;font-size:11px;font-weight:700;margin-left:8px}.ds-popup-overlay{position:fixed;inset:0;z-index:10000;background:rgba(2,6,23,.72);display:flex;align-items:center;justify-content:center;padding:18px}.ds-popup-overlay[hidden]{display:none}.ds-popup-card{width:min(620px,100%);max-height:min(80vh,760px);overflow:hidden;background:#111827;border:1px solid #334155;border-radius:16px;box-shadow:0 24px 80px #0009;display:flex;flex-direction:column}.ds-popup-header{display:flex;justify-content:space-between;align-items:center;padding:18px 20px;border-bottom:1px solid #334155}.ds-popup-header h2{font-size:22px;font-weight:700;color:#f8fafc}.ds-popup-close{font-size:30px;line-height:1;color:#94a3b8;padding:0 6px}.ds-popup-content{padding:14px 20px 20px;overflow:auto}.ds-popup-item{padding:13px 0;border-bottom:1px solid #293548}.ds-popup-item:last-child{border-bottom:0}.ds-popup-meta{font-size:11px;color:#94a3b8;margin-top:5px}.ds-popup-action{font-size:12px;color:#5eead4;margin-top:7px}.ds-popup-mark{font-size:12px;color:#5eead4;margin-left:10px}.ds-mobile-menu-links .ds-popup-open{display:block;width:100%;padding:10px 14px;color:#cbd5e1;background:transparent;border:0;font:inherit;text-align:left}
</style>
<script>
(function(){
 const overlay=document.getElementById('ds-nav-popup'), title=document.getElementById('ds-popup-title'), eyebrow=document.getElementById('ds-popup-eyebrow'), content=document.getElementById('ds-popup-content'), close=document.getElementById('ds-popup-close');
 if(!overlay||!content)return; let csrf='';
 const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const date=v=>esc(v||'');
 async function load(){content.innerHTML='<p class="text-slate-400">Loading…</p>';try{const r=await fetch('nav_popup_data.php',{credentials:'same-origin'});const d=await r.json();csrf=d.csrf||'';document.querySelectorAll('.ds-unread-count').forEach(el=>el.textContent=d.unread?d.unread:'' );if(overlay.dataset.kind==='notifications'){content.innerHTML=(d.notifications.some(n=>Number(n.is_read)===0)?'<div class="flex justify-end mb-2"><button type="button" id="ds-read-all" class="rounded-lg bg-teal-400 px-3 py-2 text-xs font-bold text-slate-950 hover:bg-teal-300">Read All</button></div>':'')+(d.notifications.length?d.notifications.map(n=>`<article class="ds-popup-item"><div class="flex items-start justify-between gap-3"><strong>${esc(n.title)} ${Number(n.is_read)===0?'<span class="ds-tag">NEW</span>':''}</strong>${Number(n.is_read)===0?`<button class="ds-popup-mark" data-read="${Number(n.id)}" type="button">Mark read</button>`:''}</div><p class="text-slate-300 mt-1">${esc(n.body)}</p><p class="ds-popup-meta">${date(n.created_at)}</p>${n.link_url?`<a class="ds-popup-action block" href="${safeUrl(n.link_url)}">Open related item →</a>`:''}</article>`).join(''):'<p class="text-slate-400 py-4">You’re all caught up. No notifications yet.</p>');}else{content.innerHTML=d.activity.length?d.activity.map(a=>`<article class="ds-popup-item"><div class="flex justify-between gap-3"><strong>${esc(a.action)}</strong><span class="ds-popup-meta">${date(a.created_at)}</span></div><p class="text-slate-300 mt-1">${esc(a.details)}</p><p class="ds-popup-meta">By ${esc(a.username)}</p></article>`).join(''):'<p class="text-slate-400 py-4">No recorded activity yet.</p>';}}catch(e){content.innerHTML='<p class="text-rose-300 py-4">Could not load updates. Please refresh and try again.</p>';}}
 function safeUrl(v){v=String(v||'demo.php');return /^[a-zA-Z0-9_./?=&%#-]{1,500}$/.test(v)&&!v.startsWith('//')&&!v.includes(':')?esc(v):'demo.php';}
 document.querySelectorAll('[data-popup]').forEach(b=>b.addEventListener('click',()=>{overlay.dataset.kind=b.dataset.popup;title.textContent=b.dataset.popup==='activity'?'Activity Log':'Notifications';eyebrow.textContent=b.dataset.popup==='activity'?'SECURITY & PERMISSIONS':'INBOX';overlay.hidden=false;load();}));
 close.addEventListener('click',()=>overlay.hidden=true);overlay.addEventListener('click',e=>{if(e.target===overlay)overlay.hidden=true;});document.addEventListener('keydown',e=>{if(e.key==='Escape')overlay.hidden=true;});
 content.addEventListener('click',async e=>{const all=e.target.closest('#ds-read-all');const b=e.target.closest('[data-read]');if(!all&&!b)return;const form=new URLSearchParams(all?{csrf,action:'read_all'}:{csrf,notification_id:b.dataset.read});try{const r=await fetch('nav_popup_data.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:form,credentials:'same-origin'});if(r.ok)await load();}catch(e){}});
})();
</script>
<script>(function(){try{var t=localStorage.getItem('devstudio-theme')||'dark';document.documentElement.dataset.theme=t;document.body.dataset.theme=t;}catch(e){}})();</script>

<?php
session_start();
require_once "db.php";

if (!empty($_SESSION['user_id'])) {
    header("Location: demo.php");
    exit;
}

if (empty($_SESSION['register_csrf'])) $_SESSION['register_csrf'] = bin2hex(random_bytes(32));
$error = null;
$oldRole = $_POST['role'] ?? 'worker';
$storedRole = in_array($oldRole, ['owner','worker'], true) ? $oldRole : 'worker';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals((string)$_SESSION['register_csrf'], (string)($_POST['csrf'] ?? ''))) {
        $error = 'Your form expired. Refresh the page and try again.';
    } else {
        $result = registerUser(
            $_POST['username'] ?? '',
            $_POST['email'] ?? '',
            $_POST['password'] ?? '',
            $_POST['confirm_password'] ?? '',
            $storedRole,
            $_POST['business_name'] ?? '',
            $_POST['business_cash'] ?? '',
            $_POST['business_location'] ?? ''
        );

        if ($result['ok']) {
            header("Location: login.php?registered=1");
            exit;
        }
        $error = $result['error'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Create Account | DEVSTUDIO SIMS</title>
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="assets/theme.css">
<style>.owner-fields{display:grid;gap:1rem}.owner-fields[hidden]{display:none}</style>
</head>
<body class="bg-slate-900 text-white">
<main class="max-w-xl mx-auto py-12 px-6">
    <div class="text-center mb-8">
        <div class="ds-eyebrow">DEVSTUDIO SIMS</div>
        <h1 class="text-3xl font-bold">Create Account</h1>
        <p class="text-slate-400 mt-2">Set up a simulated software studio or join a team.</p>
    </div>

    <section class="ds-panel accent-process">
        <?php if ($error): ?>
            <div class="ds-panel accent-alert mb-5"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>

        <form method="post" class="space-y-4" novalidate>
            <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['register_csrf'], ENT_QUOTES, 'UTF-8') ?>">
            <div>
                <label class="block mb-2 text-sm text-slate-300" for="username">Username</label>
                <input id="username" name="username" required maxlength="50" autocomplete="username" value="<?= htmlspecialchars($_POST['username'] ?? '', ENT_QUOTES, 'UTF-8') ?>" class="w-full bg-slate-700 rounded-lg p-3">
            </div>
            <div>
                <label class="block mb-2 text-sm text-slate-300" for="email">Email</label>
                <input id="email" type="email" name="email" required maxlength="150" autocomplete="email" value="<?= htmlspecialchars($_POST['email'] ?? '', ENT_QUOTES, 'UTF-8') ?>" class="w-full bg-slate-700 rounded-lg p-3">
            </div>
            <div>
                <label class="block mb-2 text-sm text-slate-300" for="role">Account type</label>
                <select id="role" name="role" class="w-full bg-slate-700 rounded-lg p-3" required>
                    <option value="worker" <?= $storedRole === 'worker' ? 'selected' : '' ?>>Worker / Team Member</option>
                    <option value="owner" <?= $storedRole === 'owner' ? 'selected' : '' ?>>Studio Owner</option>
                </select>
            </div>

            <fieldset id="owner-fields" class="owner-fields rounded-xl border border-teal-400/30 bg-teal-400/5 p-4" <?= $storedRole === 'owner' ? '' : 'hidden' ?>>
                <legend class="px-2 text-teal-200 font-semibold">Studio Setup</legend>
                <p class="text-sm text-slate-400">These values are for the simulation only, not real money or payroll.</p>
                <div>
                    <label class="block mb-2 text-sm text-slate-300" for="business_name">Studio / Business Name</label>
                    <input id="business_name" name="business_name" maxlength="150" value="<?= htmlspecialchars($_POST['business_name'] ?? '', ENT_QUOTES, 'UTF-8') ?>" class="w-full bg-slate-700 rounded-lg p-3" <?= $storedRole === 'owner' ? 'required' : '' ?>>
                </div>
                <div>
                    <label class="block mb-2 text-sm text-slate-300" for="business_location">Studio Location</label>
                    <input id="business_location" name="business_location" maxlength="255" value="<?= htmlspecialchars($_POST['business_location'] ?? '', ENT_QUOTES, 'UTF-8') ?>" placeholder="e.g. Calamba City, Laguna" class="w-full bg-slate-700 rounded-lg p-3" <?= $storedRole === 'owner' ? 'required' : '' ?>>
                </div>
                <div>
                    <label class="block mb-2 text-sm text-slate-300" for="business_cash">Starting Budget (₱)</label>
                    <input id="business_cash" type="number" name="business_cash" min="0" max="1000000000" step="0.01" value="<?= htmlspecialchars($_POST['business_cash'] ?? '', ENT_QUOTES, 'UTF-8') ?>" placeholder="Enter starting simulated cash" class="w-full bg-slate-700 rounded-lg p-3" <?= $storedRole === 'owner' ? 'required' : '' ?>>
                    <p class="text-xs text-slate-500 mt-1">Your entered amount becomes the studio's starting balance.</p>
                </div>
            </fieldset>

            <div>
                <label class="block mb-2 text-sm text-slate-300" for="password">Password</label>
                <input id="password" type="password" name="password" minlength="6" required autocomplete="new-password" class="w-full bg-slate-700 rounded-lg p-3">
            </div>
            <div>
                <label class="block mb-2 text-sm text-slate-300" for="confirm_password">Confirm password</label>
                <input id="confirm_password" type="password" name="confirm_password" minlength="6" required autocomplete="new-password" class="w-full bg-slate-700 rounded-lg p-3">
            </div>
            <button class="ds-btn process w-full justify-center">Create Account</button>
        </form>
    </section>
    <p class="text-center text-slate-400 text-sm mt-6">Already have an account? <a href="login.php" class="text-cyan-400 hover:underline">Log in</a></p>
    <p class="text-center text-slate-500 text-xs mt-2"><a href="index.php" class="hover:text-slate-300">Back to overview</a></p>
</main>
<script>
const roleSelect=document.getElementById('role');
const ownerFields=document.getElementById('owner-fields');
const ownerInputs=['business_name','business_location','business_cash'].map(id=>document.getElementById(id));
function toggleOwnerFields(){
  const isOwner=roleSelect.value==='owner';
  ownerFields.hidden=!isOwner;
  ownerInputs.forEach(input=>{input.required=isOwner;input.disabled=!isOwner;});
}
roleSelect.addEventListener('change',toggleOwnerFields);
toggleOwnerFields();
</script>
</body>
</html>
